import React, { useState, useEffect } from 'react';
import {
  UserRole,
  MainView,
  PatientProfile,
  Doctor,
  Appointment,
  Medicine,
  MedicalRecord,
  ChatMessage,
  ReportedSymptom,
  DigitalPrescription,
  VaccineRecord,
  ConsentRequest,
  AuditLogEntry,
  NotificationItem,
} from './types';
import {
  initialPatient,
  initialDoctors,
  initialUpcomingAppointment,
  initialMedicines,
  initialMedicalRecords,
  initialChatMessages,
  initialSymptoms,
  initialPrescription,
  initialVaccines,
  initialConsentRequests,
  initialAuditLogs,
  initialNotifications,
  specialtiesData,
} from './data/mockData';

// Navigation Components
import { TopNavbar } from './components/TopNavbar';
import { PatientSidebar } from './components/PatientSidebar';
import { DoctorSidebar } from './components/DoctorSidebar';
import { HospitalSidebar } from './components/HospitalSidebar';
import { BottomNav } from './components/BottomNav';

// Route URL Helpers
export const getViewFromPath = (pathname: string): MainView => {
  const cleanPath = (pathname || '').toLowerCase().replace(/\/+$/, '');
  
  if (!cleanPath || cleanPath === '/' || cleanPath === '/dashboard' || cleanPath === '/patient-dashboard' || cleanPath === '/home') {
    return 'home';
  }
  if (cleanPath === '/find-specialists' || cleanPath === '/specialties' || cleanPath === '/specialist' || cleanPath === '/specialists') {
    return 'specialties';
  }
  if (cleanPath === '/doctors' || cleanPath === '/doctor-discovery') {
    return 'doctor-discovery';
  }
  if (cleanPath === '/med-sarthi' || cleanPath === '/sarthi') {
    return 'med-sarthi';
  }
  if (cleanPath === '/medical-records' || cleanPath === '/records') {
    return 'medical-records';
  }
  if (cleanPath === '/report-viewer') {
    return 'report-viewer';
  }
  if (cleanPath === '/prescriptions') {
    return 'prescriptions';
  }
  if (cleanPath === '/medicine-reminders' || cleanPath === '/reminders') {
    return 'medicine-reminders';
  }
  if (cleanPath === '/vaccinations' || cleanPath === '/vaccines') {
    return 'vaccinations';
  }
  if (cleanPath === '/pre-consultation') {
    return 'pre-consultation';
  }
  if (cleanPath === '/consent-management' || cleanPath === '/consent') {
    return 'consent-management';
  }
  if (cleanPath === '/audit-log' || cleanPath === '/security') {
    return 'audit-log';
  }
  if (cleanPath === '/notifications') {
    return 'notifications';
  }
  if (cleanPath === '/profile' || cleanPath === '/patient-profile') {
    return 'patient-profile';
  }
  if (cleanPath === '/doctor-profile') {
    return 'doctor-profile';
  }
  if (cleanPath === '/appointment-booking') {
    return 'appointment-booking';
  }
  if (cleanPath === '/doctor/dashboard' || cleanPath === '/doctor-dashboard') {
    return 'doctor-dashboard';
  }
  if (cleanPath === '/doctor/patients' || cleanPath === '/doctor-patient-view') {
    return 'doctor-patient-view';
  }
  if (cleanPath === '/doctor/consultation' || cleanPath === '/doctor-consultation') {
    return 'doctor-consultation';
  }
  if (cleanPath === '/doctor/prescription' || cleanPath === '/doctor-rx-builder') {
    return 'doctor-rx-builder';
  }
  if (cleanPath === '/hospital/dashboard' || cleanPath === '/hospital-dashboard') {
    return 'hospital-dashboard';
  }
  if (cleanPath === '/hospital/analytics' || cleanPath === '/hospital-analytics') {
    return 'hospital-analytics';
  }
  if (cleanPath === '/landing') {
    return 'landing';
  }
  if (cleanPath === '/auth' || cleanPath === '/login') {
    return 'auth';
  }
  return 'home';
};

export const getPathFromView = (view: MainView): string => {
  switch (view) {
    case 'home':
    case 'patient-dashboard':
      return '/dashboard';
    case 'specialties':
      return '/find-specialists';
    case 'doctor-discovery':
      return '/doctors';
    case 'med-sarthi':
      return '/med-sarthi';
    case 'medical-records':
      return '/medical-records';
    case 'report-viewer':
      return '/report-viewer';
    case 'prescriptions':
      return '/prescriptions';
    case 'medicine-reminders':
      return '/medicine-reminders';
    case 'vaccinations':
      return '/vaccinations';
    case 'pre-consultation':
      return '/pre-consultation';
    case 'consent-management':
      return '/consent-management';
    case 'audit-log':
      return '/audit-log';
    case 'notifications':
      return '/notifications';
    case 'patient-profile':
      return '/profile';
    case 'doctor-profile':
      return '/doctor-profile';
    case 'appointment-booking':
      return '/appointment-booking';
    case 'doctor-dashboard':
      return '/doctor/dashboard';
    case 'doctor-patient-view':
      return '/doctor/patients';
    case 'doctor-consultation':
      return '/doctor/consultation';
    case 'doctor-rx-builder':
      return '/doctor/prescription';
    case 'hospital-dashboard':
      return '/hospital/dashboard';
    case 'hospital-analytics':
      return '/hospital/analytics';
    case 'landing':
      return '/landing';
    case 'auth':
      return '/auth';
    default:
      return '/dashboard';
  }
};

const getRoleFromPath = (pathname: string): UserRole => {
  const cleanPath = (pathname || '').toLowerCase();
  if (cleanPath.startsWith('/doctor')) return 'doctor';
  if (cleanPath.startsWith('/hospital')) return 'hospital';
  return 'patient';
};

// Modals
import { EmergencyModal } from './components/EmergencyModal';
import { UploadDocumentModal } from './components/UploadDocumentModal';
import { AddMedicineModal } from './components/AddMedicineModal';

// Screens
import { LandingPage } from './screens/LandingPage';
import { AuthScreen } from './screens/AuthScreen';
import { HomeScreen } from './screens/HomeScreen';
import { MedSarthiScreen } from './screens/MedSarthiScreen';
import { SpecialtyScreen } from './screens/SpecialtyScreen';
import { DoctorDiscoveryScreen } from './screens/DoctorDiscoveryScreen';
import { DoctorProfileScreen } from './screens/DoctorProfileScreen';
import { PreConsultationScreen } from './screens/PreConsultationScreen';
import { MedicalRecordsScreen } from './screens/MedicalRecordsScreen';
import { ReportViewerScreen } from './screens/ReportViewerScreen';
import { PrescriptionScreen } from './screens/PrescriptionScreen';
import { MedicineRemindersScreen } from './screens/MedicineRemindersScreen';
import { VaccinationScreen } from './screens/VaccinationScreen';
import { ConsentScreen } from './screens/ConsentScreen';
import { AuditLogScreen } from './screens/AuditLogScreen';
import { PatientProfileScreen } from './screens/PatientProfileScreen';
import { DoctorDashboardScreen } from './screens/DoctorDashboardScreen';
import { DoctorPatientViewScreen } from './screens/DoctorPatientViewScreen';
import { DoctorConsultationScreen } from './screens/DoctorConsultationScreen';
import { DoctorRxBuilderScreen } from './screens/DoctorRxBuilderScreen';
import { HospitalDashboardScreen } from './screens/HospitalDashboardScreen';
import { HospitalAnalyticsScreen } from './screens/HospitalAnalyticsScreen';
import { NotificationsScreen } from './screens/NotificationsScreen';

export default function App() {
  // Initial Route & Role resolution from current Browser URL
  const initialView = typeof window !== 'undefined' ? getViewFromPath(window.location.pathname) : 'home';
  const initialRole = typeof window !== 'undefined' ? getRoleFromPath(window.location.pathname) : 'patient';

  // Navigation & Role State
  const [currentView, setCurrentView] = useState<MainView>(initialView);
  const [currentRole, setCurrentRole] = useState<UserRole>(initialRole);

  // Core Data State
  const [patient, setPatient] = useState<PatientProfile>(initialPatient);
  const [doctors] = useState<Doctor[]>(initialDoctors);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor>(initialDoctors[0]);
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('Gastroenterology');
  const [upcomingAppointment, setUpcomingAppointment] = useState<Appointment>(initialUpcomingAppointment);
  const [medicines, setMedicines] = useState<Medicine[]>(initialMedicines);
  const [records, setRecords] = useState<MedicalRecord[]>(initialMedicalRecords);
  const [selectedRecord, setSelectedRecord] = useState<MedicalRecord>(initialMedicalRecords[0]);
  const [prescription, setPrescription] = useState<DigitalPrescription>(initialPrescription);
  const [vaccines, setVaccines] = useState<VaccineRecord[]>(initialVaccines);
  const [consentRequests, setConsentRequests] = useState<ConsentRequest[]>(initialConsentRequests);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(initialAuditLogs);
  const [notifications, setNotifications] = useState<NotificationItem[]>(initialNotifications);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(initialChatMessages);
  const [reportedSymptoms, setReportedSymptoms] = useState<ReportedSymptom[]>(initialSymptoms);

  // Modals State
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);
  const [isUploadDocOpen, setIsUploadDocOpen] = useState(false);
  const [isAddMedOpen, setIsAddMedOpen] = useState(false);

  // Navigation Helper with Role and Browser URL synchronization
  const handleNavigate = (view: MainView, updateHistory = true) => {
    const targetView = view === 'patient-dashboard' ? 'home' : view;
    setCurrentView(targetView);

    // Switch role contextual view if needed
    let targetRole = currentRole;
    if (
      targetView === 'doctor-dashboard' ||
      targetView === 'doctor-patient-view' ||
      targetView === 'doctor-consultation' ||
      targetView === 'doctor-rx-builder'
    ) {
      targetRole = 'doctor';
      setCurrentRole('doctor');
    } else if (targetView === 'hospital-dashboard' || targetView === 'hospital-analytics') {
      targetRole = 'hospital';
      setCurrentRole('hospital');
    } else if (targetView !== 'landing' && targetView !== 'auth') {
      if (
        currentRole !== 'patient' &&
        (targetView === 'home' ||
          targetView === 'med-sarthi' ||
          targetView === 'medical-records' ||
          targetView === 'specialties' ||
          targetView === 'doctor-discovery' ||
          targetView === 'pre-consultation' ||
          targetView === 'prescriptions' ||
          targetView === 'medicine-reminders' ||
          targetView === 'vaccinations' ||
          targetView === 'consent-management' ||
          targetView === 'audit-log' ||
          targetView === 'notifications' ||
          targetView === 'patient-profile')
      ) {
        targetRole = 'patient';
        setCurrentRole('patient');
      }
    }

    // Update browser URL state without page reload
    if (updateHistory && typeof window !== 'undefined') {
      const targetPath = getPathFromView(targetView);
      if (window.location.pathname !== targetPath) {
        window.history.pushState({ view: targetView, role: targetRole }, '', targetPath);
      }
    }
  };

  // Browser History and Popstate synchronization (supports Back/Forward buttons and direct refreshes)
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handlePopState = () => {
      const view = getViewFromPath(window.location.pathname);
      const role = getRoleFromPath(window.location.pathname);
      setCurrentRole(role);
      handleNavigate(view, false);
    };

    window.addEventListener('popstate', handlePopState);

    // Normalize initial root URL to /dashboard if on empty path or root
    const currentPath = window.location.pathname;
    const resolvedView = getViewFromPath(currentPath);
    const expectedPath = getPathFromView(resolvedView);
    if (currentPath === '/' || currentPath === '') {
      window.history.replaceState({ view: resolvedView, role: currentRole }, '', expectedPath);
    }

    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  const handleRoleChange = (newRole: UserRole) => {
    setCurrentRole(newRole);
    if (newRole === 'patient') handleNavigate('home');
    else if (newRole === 'doctor') handleNavigate('doctor-dashboard');
    else if (newRole === 'hospital') handleNavigate('hospital-dashboard');
  };

  // Medicine Toggles
  const handleToggleMed = (id: string) => {
    setMedicines((prev) =>
      prev.map((m) => (m.id === id ? { ...m, taken: !m.taken } : m))
    );
  };

  const handleAddMedicine = (newMed: Medicine) => {
    setMedicines((prev) => [newMed, ...prev]);
  };

  const handleAddAllPrescriptionToReminders = () => {
    const newItems: Medicine[] = prescription.medications.map((pm, i) => ({
      id: `rx-med-${Date.now()}-${i}`,
      name: pm.name,
      dosage: pm.dosage,
      frequency: pm.frequency,
      scheduledTime: i === 0 ? '08:00 AM' : i === 1 ? '01:00 PM' : '09:00 PM',
      instructions: pm.timing,
      duration: pm.duration,
      taken: false,
      refillDaysRemaining: 14,
    }));
    setMedicines((prev) => [...newItems, ...prev]);
  };

  // Document Upload
  const handleUploadSuccess = (newRec: Partial<MedicalRecord>) => {
    const fullRec: MedicalRecord = {
      id: newRec.id || `rec-${Date.now()}`,
      title: newRec.title || 'Diagnostic Report',
      category: newRec.category || 'Lab Reports',
      facility: newRec.facility || 'Apollo Diagnostics',
      uploadDate: newRec.uploadDate || 'Today',
      fileUrl: '#',
      fileSize: '1.8 MB',
      isAiSummarized: true,
      aiSummary: newRec.aiSummary || {
        summary: 'Parameters evaluated are largely within optimal biological thresholds.',
        keyFindings: ['Biomarkers verified within clinical standards.'],
        biomarkers: [],
        recommendations: 'Maintain standard hydration and lifestyle routine.',
      },
    };
    setRecords((prev) => [fullRec, ...prev]);
  };

  // Consent Handlers
  const handleApproveConsent = (id: string) => {
    setConsentRequests((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status: 'approved' } : c))
    );
    setAuditLogs((prev) => [
      {
        id: `aud-${Date.now()}`,
        timestamp: 'Just now',
        accessorName: 'Dr. Sarah Jenkins',
        role: 'doctor',
        organization: 'Apollo Hospitals',
        action: 'Granted Access',
        recordName: 'Encrypted Medical Health Records',
        status: 'success',
      },
      ...prev,
    ]);
  };

  const handleDenyConsent = (id: string) => {
    setConsentRequests((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status: 'denied' } : c))
    );
  };

  const handleRevokeConsent = (id: string) => {
    setConsentRequests((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status: 'revoked' } : c))
    );
  };

  // Chat message sending with clinical triage engine
  const handleSendMessage = (text: string) => {
    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, userMsg]);

    setTimeout(() => {
      const lower = text.toLowerCase();
      let replyText =
        'Thank you for providing those details. I have analyzed your symptom progression.';
      let bullets: string[] | undefined = undefined;

      if (lower.includes('stomach') || lower.includes('pain') || lower.includes('burning') || lower.includes('acid')) {
        replyText =
          'Your clinical description aligns with symptoms of Upper GI Dyspepsia or Mild Acute Gastritis. Let us book a gastroenterologist review to assess diet and medication.';
        bullets = [
          'Estimated Urgency: Standard OPD (Non-Emergency)',
          'Recommended Specialist: Gastroenterology / GI Specialist',
          'Immediate Advice: Avoid acidic foods, caffeine, and eat light meals',
        ];
        setReportedSymptoms((prev) => [
          ...prev,
          {
            name: 'Epigastric post-prandial discomfort',
            duration: '3 days',
            severity: 'Moderate',
            status: 'verified',
          },
        ]);
      } else {
        replyText =
          'I have recorded these clinical symptoms into your Pre-Consultation briefing for the doctor.';
        bullets = [
          'Triage Status: Active Clinical Log',
          'Vitals Assessment: Stable',
        ];
      }

      const aiMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'ai',
        text: replyText,
        bulletPoints: bullets,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setChatMessages((prev) => [...prev, aiMsg]);
    }, 1000);
  };

  // Doctor Prescription Issued Handler
  const handlePrescriptionIssued = (rxData: any) => {
    setPrescription({
      id: `RX-${Math.floor(100000 + Math.random() * 900000)}`,
      doctorName: 'Dr. Sarah Jenkins',
      doctorQualifications: 'MD, DM (Gastroenterology)',
      doctorRegNumber: 'KMC-88192',
      hospitalName: 'Apollo Hospitals, Bannerghatta Hub',
      date: 'Today, Oct 24, 2026',
      patientName: patient.name,
      patientAge: patient.age,
      patientGender: patient.gender,
      patientId: patient.medicalId,
      diagnosis: 'Acute Gastritis & Epigastric Dyspepsia',
      medications: rxData.medications,
      doctorNotes: rxData.doctorNotes,
      followUpDate: 'Nov 07, 2026',
    });
  };

  // Full Screen Layouts (Landing Page & Auth Screen)
  if (currentView === 'landing') {
    return (
      <LandingPage
        onGetStarted={() => handleNavigate('auth')}
        onLogin={() => handleNavigate('auth')}
      />
    );
  }

  if (currentView === 'auth') {
    return (
      <AuthScreen
        onAuthSuccess={(role) => {
          setCurrentRole(role);
          if (role === 'patient') handleNavigate('home');
          else if (role === 'doctor') handleNavigate('doctor-dashboard');
          else if (role === 'hospital') handleNavigate('hospital-dashboard');
        }}
        onBackToLanding={() => handleNavigate('landing')}
      />
    );
  }

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 selection:bg-blue-600 selection:text-white pb-20 lg:pb-0">
      {/* Top Universal Navbar */}
      <TopNavbar
        currentRole={currentRole}
        currentView={currentView}
        patient={patient}
        onRoleChange={handleRoleChange}
        onNavigate={handleNavigate}
        onOpenEmergency={() => setIsEmergencyOpen(true)}
        unreadNotificationCount={unreadCount}
        unreadNotifsCount={unreadCount}
      />

      {/* Main Workspace Layout (Sidebar + Content Container) */}
      <div className="flex-1 flex max-w-[1600px] w-full mx-auto">
        {/* Role-Specific Desktop Sidebars */}
        <aside className="hidden lg:block w-64 shrink-0 p-4 sticky top-[73px] h-[calc(100vh-73px)] overflow-y-auto">
          {currentRole === 'patient' && (
            <PatientSidebar currentView={currentView} onNavigate={handleNavigate} />
          )}
          {currentRole === 'doctor' && (
            <DoctorSidebar currentView={currentView} onNavigate={handleNavigate} />
          )}
          {currentRole === 'hospital' && (
            <HospitalSidebar currentView={currentView} onNavigate={handleNavigate} />
          )}
        </aside>

        {/* Dynamic Center Stage Content View */}
        <main className="flex-1 min-w-0 py-4 lg:py-6 overflow-y-auto">
          {/* Patient Views */}
          {(currentView === 'home' || currentView === 'patient-dashboard') && (
            <HomeScreen
              patient={patient}
              upcomingAppointment={upcomingAppointment}
              medicines={medicines}
              recentRecords={records}
              onNavigate={handleNavigate}
              onOpenEmergency={() => setIsEmergencyOpen(true)}
              onOpenUploadDoc={() => setIsUploadDocOpen(true)}
              onOpenAddMed={() => setIsAddMedOpen(true)}
              onToggleMed={handleToggleMed}
            />
          )}

          {currentView === 'med-sarthi' && (
            <MedSarthiScreen
              chatMessages={chatMessages}
              reportedSymptoms={reportedSymptoms}
              onSendMessage={handleSendMessage}
              onNavigate={handleNavigate}
              onOpenEmergency={() => setIsEmergencyOpen(true)}
            />
          )}

          {currentView === 'specialties' && (
            <SpecialtyScreen
              specialties={specialtiesData}
              onSelectSpecialty={(spec) => {
                setSelectedSpecialty(spec);
                handleNavigate('doctor-discovery');
              }}
              onNavigate={handleNavigate}
            />
          )}

          {currentView === 'doctor-discovery' && (
            <DoctorDiscoveryScreen
              doctors={doctors}
              selectedSpecialtyFilter={selectedSpecialty}
              onSelectDoctor={(doc) => {
                setSelectedDoctor(doc);
                handleNavigate('doctor-profile');
              }}
              onNavigate={handleNavigate}
            />
          )}

          {currentView === 'doctor-profile' && (
            <DoctorProfileScreen
              doctor={selectedDoctor}
              onBookAppointment={(bookingData) => {
                setUpcomingAppointment({
                  doctorName: selectedDoctor.name,
                  doctorAvatar: selectedDoctor.avatarUrl,
                  specialty: selectedDoctor.specialty,
                  hospitalName: selectedDoctor.hospitalName,
                  date: bookingData.date,
                  time: bookingData.time,
                  type: bookingData.mode === 'telehealth' ? 'Video Telehealth' : 'In-Person OPD',
                  status: 'confirmed',
                });
                handleNavigate('pre-consultation');
              }}
              onBack={() => handleNavigate('doctor-discovery')}
            />
          )}

          {currentView === 'pre-consultation' && (
            <PreConsultationScreen
              doctor={selectedDoctor}
              records={records}
              onCompleteIntake={(intakeData) => {
                handleNavigate('home');
              }}
              onBack={() => handleNavigate('home')}
            />
          )}

          {currentView === 'medical-records' && (
            <MedicalRecordsScreen
              records={records}
              onViewRecord={(rec) => {
                setSelectedRecord(rec);
                handleNavigate('report-viewer');
              }}
              onOpenUpload={() => setIsUploadDocOpen(true)}
              onNavigate={handleNavigate}
            />
          )}

          {currentView === 'report-viewer' && (
            <ReportViewerScreen
              record={selectedRecord}
              onBack={() => handleNavigate('medical-records')}
              onNavigate={handleNavigate}
            />
          )}

          {currentView === 'prescriptions' && (
            <PrescriptionScreen
              prescription={prescription}
              onNavigate={handleNavigate}
              onAddAllToReminders={handleAddAllPrescriptionToReminders}
            />
          )}

          {currentView === 'medicine-reminders' && (
            <MedicineRemindersScreen
              medicines={medicines}
              onToggleMed={handleToggleMed}
              onOpenAddMed={() => setIsAddMedOpen(true)}
              onNavigate={handleNavigate}
            />
          )}

          {currentView === 'vaccinations' && (
            <VaccinationScreen
              vaccines={vaccines}
              onOpenAddVaccine={() => alert('Vaccination record sync with CoWIN gateway initiated.')}
              onNavigate={handleNavigate}
            />
          )}

          {currentView === 'consent-management' && (
            <ConsentScreen
              consentRequests={consentRequests}
              onApproveConsent={handleApproveConsent}
              onDenyConsent={handleDenyConsent}
              onRevokeConsent={handleRevokeConsent}
              onNavigate={handleNavigate}
            />
          )}

          {currentView === 'audit-log' && (
            <AuditLogScreen
              auditLogs={auditLogs}
              onBack={() => handleNavigate('consent-management')}
              onNavigate={handleNavigate}
            />
          )}

          {currentView === 'patient-profile' && (
            <PatientProfileScreen
              patient={patient}
              onUpdateProfile={(updated) => setPatient((prev) => ({ ...prev, ...updated }))}
              onNavigate={handleNavigate}
            />
          )}

          {/* Doctor Portal Views */}
          {currentView === 'doctor-dashboard' && (
            <DoctorDashboardScreen
              onNavigate={handleNavigate}
              onSelectPatient={(pId) => {}}
            />
          )}

          {currentView === 'doctor-patient-view' && (
            <DoctorPatientViewScreen
              patient={patient}
              records={records}
              onNavigate={handleNavigate}
              onBack={() => handleNavigate('doctor-dashboard')}
            />
          )}

          {currentView === 'doctor-consultation' && (
            <DoctorConsultationScreen
              onNavigate={handleNavigate}
              onCompleteConsultation={() => handleNavigate('doctor-rx-builder')}
            />
          )}

          {currentView === 'doctor-rx-builder' && (
            <DoctorRxBuilderScreen
              onBack={() => handleNavigate('doctor-dashboard')}
              onNavigate={handleNavigate}
              onPrescriptionIssued={handlePrescriptionIssued}
            />
          )}

          {/* Hospital Admin Views */}
          {currentView === 'hospital-dashboard' && (
            <HospitalDashboardScreen onNavigate={handleNavigate} />
          )}

          {currentView === 'hospital-analytics' && (
            <HospitalAnalyticsScreen
              onBack={() => handleNavigate('hospital-dashboard')}
              onNavigate={handleNavigate}
            />
          )}

          {/* Notifications View */}
          {currentView === 'notifications' && (
            <NotificationsScreen
              notifications={notifications}
              onMarkAllRead={() =>
                setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })))
              }
              onNavigate={handleNavigate}
            />
          )}
        </main>
      </div>

      {/* Mobile Sticky Bottom Navigation */}
      <BottomNav
        currentView={currentView}
        currentRole={currentRole}
        onNavigate={handleNavigate}
      />

      {/* Universal Modals */}
      <EmergencyModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
        patient={patient}
      />

      <UploadDocumentModal
        isOpen={isUploadDocOpen}
        onClose={() => setIsUploadDocOpen(false)}
        onUploadSuccess={handleUploadSuccess}
      />

      <AddMedicineModal
        isOpen={isAddMedOpen}
        onClose={() => setIsAddMedOpen(false)}
        onAddMedicine={handleAddMedicine}
      />
    </div>
  );
}
