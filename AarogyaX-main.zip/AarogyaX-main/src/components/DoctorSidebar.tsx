import React from 'react';
import {
  LayoutDashboard,
  Users,
  Stethoscope,
  FileSignature,
  Video,
  ClipboardList,
  FolderHeart,
  Settings,
  ShieldCheck,
  CalendarCheck,
} from 'lucide-react';
import { MainView } from '../types';

interface DoctorSidebarProps {
  currentView: MainView;
  onNavigate: (view: MainView) => void;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export const DoctorSidebar: React.FC<DoctorSidebarProps> = ({
  currentView,
  onNavigate,
  isOpenMobile,
  onCloseMobile,
}) => {
  const navItems = [
    {
      id: 'doctor-dashboard' as MainView,
      label: 'Doctor Dashboard',
      icon: LayoutDashboard,
      badge: 'Today: 8',
    },
    {
      id: 'doctor-dashboard' as MainView,
      label: "Today's Patient Queue",
      icon: Users,
      badge: '3 Waiting',
    },
    {
      id: 'doctor-patient-view' as MainView,
      label: 'Patient Clinical EHR',
      icon: Stethoscope,
      badge: 'Rahul Sharma',
    },
    {
      id: 'doctor-consultation' as MainView,
      label: 'Consultation Workspace',
      icon: ClipboardList,
      badge: 'Active Room',
      isSpecial: true,
    },
    {
      id: 'doctor-rx-builder' as MainView,
      label: 'Digital Rx Builder',
      icon: FileSignature,
      badge: 'Rx Generator',
    },
    {
      id: 'medical-records' as MainView,
      label: 'Verified Lab Vault',
      icon: FolderHeart,
      badge: '',
    },
  ];

  const handleItemClick = (view: MainView) => {
    onNavigate(view);
    if (onCloseMobile) onCloseMobile();
  };

  return (
    <>
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      <aside
        className={`fixed lg:sticky top-16 left-0 z-40 w-64 h-[calc(100vh-4rem)] bg-white border-r border-slate-200 overflow-y-auto transition-transform duration-200 ease-in-out ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="p-4 space-y-6">
          {/* Doctor Info Card */}
          <div className="p-3 bg-gradient-to-br from-teal-50 to-emerald-50/50 rounded-2xl border border-teal-100 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                SJ
              </div>
              <div>
                <p className="text-xs font-bold text-slate-800">Dr. Sarah Jenkins</p>
                <p className="text-[10px] text-teal-700 font-medium">Sr. Gastroenterologist</p>
              </div>
            </div>
            <span className="w-2 h-2 rounded-full bg-emerald-500 ring-4 ring-emerald-100" title="On Duty" />
          </div>

          {/* Navigation Section */}
          <div className="space-y-1">
            <p className="px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Clinical EHR Workflow
            </p>
            {navItems.map((item, idx) => {
              const Icon = item.icon;
              const isActive = currentView === item.id && (item.id !== 'doctor-dashboard' || idx === 0);

              return (
                <button
                  key={`${item.id}-${idx}`}
                  onClick={() => handleItemClick(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? item.isSpecial
                        ? 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-sm shadow-teal-500/25'
                        : 'bg-teal-50 text-teal-800 border border-teal-200 font-bold'
                      : item.isSpecial
                      ? 'bg-teal-50/60 text-teal-800 border border-teal-100 hover:bg-teal-100/50'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon
                      className={`w-4 h-4 ${
                        isActive
                          ? item.isSpecial
                            ? 'text-white'
                            : 'text-teal-600'
                          : 'text-slate-400'
                      }`}
                    />
                    <span>{item.label}</span>
                  </div>

                  {item.badge && (
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        isActive
                          ? item.isSpecial
                            ? 'bg-white/20 text-white'
                            : 'bg-teal-200 text-teal-800'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Doctor Telemetry Box */}
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5 text-xs text-slate-600">
            <div className="flex justify-between items-center text-[11px]">
              <span>OPD Session:</span>
              <span className="font-bold text-slate-800">Morning + Afternoon</span>
            </div>
            <div className="flex justify-between items-center text-[11px]">
              <span>Average Wait Time:</span>
              <span className="font-bold text-emerald-600">12 Mins</span>
            </div>
            <div className="flex justify-between items-center text-[11px]">
              <span>Prescriptions Signed:</span>
              <span className="font-bold text-slate-800">14 Today</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
