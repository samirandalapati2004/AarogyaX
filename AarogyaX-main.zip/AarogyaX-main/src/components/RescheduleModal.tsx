import React, { useState } from 'react';
import { Appointment } from '../types';

interface RescheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointment: Appointment;
  onRescheduleSuccess: (newDate: string, newTime: string) => void;
}

export const RescheduleModal: React.FC<RescheduleModalProps> = ({
  isOpen,
  onClose,
  appointment,
  onRescheduleSuccess,
}) => {
  const [selectedDate, setSelectedDate] = useState('Friday, Oct 27');
  const [selectedTime, setSelectedTime] = useState('03:30 PM');

  if (!isOpen) return null;

  const dates = ['Tomorrow, Oct 24', 'Friday, Oct 27', 'Monday, Oct 30', 'Tuesday, Oct 31'];
  const times = ['09:30 AM', '10:30 AM', '02:00 PM', '03:30 PM', '05:15 PM'];

  const handleConfirm = () => {
    onRescheduleSuccess(selectedDate, selectedTime);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border-2 border-[#141414] max-w-md w-full overflow-hidden shadow-[8px_8px_0px_#141414]">
        <div className="bg-[#141414] text-white p-4 border-b border-[#141414] flex items-center justify-between font-mono-tech">
          <div>
            <h3 className="font-bold text-sm uppercase">Reschedule Consultation</h3>
            <p className="text-[10px] text-white/70">{appointment.doctorName} // {appointment.doctorSpecialty}</p>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-white/20 text-white cursor-pointer">
            <span className="material-symbols-outlined text-base">close</span>
          </button>
        </div>

        <div className="p-6 space-y-4 font-mono-tech text-xs">
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-[#5A5A58] uppercase">Select Target Date</label>
            <div className="grid grid-cols-2 gap-2">
              {dates.map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setSelectedDate(d)}
                  className={`p-2.5 border uppercase text-center transition-colors cursor-pointer ${
                    selectedDate === d
                      ? 'bg-[#141414] text-white border-[#141414] font-bold'
                      : 'bg-white text-[#141414] border-[#141414] hover:bg-[#F0EFED]'
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-[#5A5A58] uppercase">Select Time Slot</label>
            <div className="grid grid-cols-3 gap-2">
              {times.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setSelectedTime(t)}
                  className={`p-2 border text-center transition-colors cursor-pointer ${
                    selectedTime === t
                      ? 'bg-[#2A5CFF] text-white border-[#141414] font-bold'
                      : 'bg-white text-[#141414] border-[#141414] hover:bg-[#F0EFED]'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-3 flex justify-between items-center">
            <button
              type="button"
              onClick={onClose}
              className="font-bold text-[#5A5A58] hover:text-[#141414] cursor-pointer uppercase"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleConfirm}
              className="px-5 py-2.5 bg-[#2A5CFF] hover:bg-[#1742DB] text-white font-bold border border-[#141414] shadow-[2px_2px_0px_#141414] cursor-pointer uppercase tracking-wider active:translate-x-0.5 active:translate-y-0.5"
            >
              Update Slot &gt;
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
