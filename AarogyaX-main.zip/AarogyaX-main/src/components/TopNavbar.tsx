import React, { useState } from 'react';
import {
  Activity,
  Bell,
  Search,
  AlertCircle,
  ShieldCheck,
  User,
  Stethoscope,
  Building2,
  Globe,
  CheckCircle2,
  Menu,
  X,
  Sparkles,
} from 'lucide-react';
import { MainView, UserRole, PatientProfile } from '../types';

interface TopNavbarProps {
  currentView: MainView;
  currentRole: UserRole;
  patient?: PatientProfile;
  unreadNotifsCount?: number;
  unreadNotificationCount?: number;
  onNavigate: (view: MainView) => void;
  onRoleChange: (role: UserRole) => void;
  onOpenEmergency: () => void;
  onToggleSidebar?: () => void;
  isSidebarOpen?: boolean;
}

export const TopNavbar: React.FC<TopNavbarProps> = ({
  currentView,
  currentRole,
  patient,
  unreadNotifsCount,
  unreadNotificationCount,
  onNavigate,
  onRoleChange,
  onOpenEmergency,
  onToggleSidebar,
  isSidebarOpen,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);
  const unreadCount = unreadNotifsCount ?? unreadNotificationCount ?? 0;

  const handleRoleSelect = (role: UserRole) => {
    onRoleChange(role);
    setIsRoleDropdownOpen(false);
    if (role === 'patient') onNavigate('home');
    else if (role === 'doctor') onNavigate('doctor-dashboard');
    else if (role === 'hospital') onNavigate('hospital-dashboard');
  };

  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      if (searchQuery.toLowerCase().includes('special') || searchQuery.toLowerCase().includes('dept')) {
        onNavigate('specialties');
      } else {
        onNavigate('doctor-discovery');
      }
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top Banner / Role Switcher Strip */}
      <div className="bg-slate-900 text-slate-200 px-4 py-1.5 text-xs flex items-center justify-between">
        <div className="flex items-center gap-2 overflow-x-auto hide-scrollbar py-0.5">
          <span className="text-slate-400 font-medium hidden sm:inline text-[11px]">ACTIVE ECOSYSTEM:</span>
          
          <button
            onClick={() => onNavigate('landing')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all flex items-center gap-1.5 cursor-pointer text-[11px] ${
              currentView === 'landing'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'hover:bg-slate-800 text-slate-300'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Public Showcase</span>
          </button>

          <button
            onClick={() => handleRoleSelect('patient')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all flex items-center gap-1.5 cursor-pointer text-[11px] ${
              currentRole === 'patient' && currentView !== 'landing'
                ? 'bg-blue-600 text-white shadow-xs font-semibold'
                : 'hover:bg-slate-800 text-slate-300'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Patient Portal</span>
          </button>

          <button
            onClick={() => handleRoleSelect('doctor')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all flex items-center gap-1.5 cursor-pointer text-[11px] ${
              currentRole === 'doctor' && currentView !== 'landing'
                ? 'bg-teal-600 text-white shadow-xs font-semibold'
                : 'hover:bg-slate-800 text-slate-300'
            }`}
          >
            <Stethoscope className="w-3.5 h-3.5" />
            <span>Doctor Clinical EHR</span>
          </button>

          <button
            onClick={() => handleRoleSelect('hospital')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all flex items-center gap-1.5 cursor-pointer text-[11px] ${
              currentRole === 'hospital' && currentView !== 'landing'
                ? 'bg-indigo-600 text-white shadow-xs font-semibold'
                : 'hover:bg-slate-800 text-slate-300'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Hospital Administration</span>
          </button>
        </div>

        <div className="hidden lg:flex items-center gap-3 text-[11px] text-slate-400">
          <div className="flex items-center gap-1 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>ABHA Compliant (AES-256)</span>
          </div>
          <span className="text-slate-600">|</span>
          <span className="text-slate-300 font-mono text-[10px]">ID: {patient?.medicalId || 'AX-1029384'}</span>
        </div>
      </div>

      {/* Main App Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Left: Mobile Menu Toggle & Brand */}
        <div className="flex items-center gap-3">
          {onToggleSidebar && (
            <button
              onClick={onToggleSidebar}
              className="p-2 rounded-lg text-slate-600 hover:bg-slate-100 lg:hidden cursor-pointer"
              aria-label="Toggle Navigation"
            >
              {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          )}

          <div
            onClick={() => onNavigate(currentRole === 'patient' ? 'home' : currentRole === 'doctor' ? 'doctor-dashboard' : 'hospital-dashboard')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex items-center justify-center shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
              <Activity className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-lg font-bold tracking-tight text-slate-900 group-hover:text-blue-600 transition-colors">
                  Aarogya<span className="text-blue-600">X</span>
                </span>
                <span className="px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider bg-blue-50 text-blue-700 rounded border border-blue-200">
                  AI HEALTH
                </span>
              </div>
              <p className="text-[10px] text-slate-500 hidden sm:block font-medium">
                From Symptoms to Treatment — One Connected Journey
              </p>
            </div>
          </div>
        </div>

        {/* Center: Search Bar */}
        <div className="hidden md:flex flex-1 max-w-md mx-4">
          <div className="relative w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleSearchKeyDown}
              placeholder="Search doctors, symptoms, lab reports, medications (Press Enter)..."
              className="w-full pl-10 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all placeholder:text-slate-400"
            />
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Find Specialists Button */}
          <button
            id="top-nav-find-specialist"
            onClick={() => onNavigate('specialties')}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 hover:text-blue-600 shadow-xs cursor-pointer transition-all"
            title="Find Specialists by Department"
          >
            <Stethoscope className="w-3.5 h-3.5 text-blue-600" />
            <span>Find Specialists</span>
          </button>

          {/* Quick AI Med Sarthi Pill */}
          <button
            onClick={() => onNavigate('med-sarthi')}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-gradient-to-r from-blue-50 to-teal-50 text-blue-700 border border-blue-200/80 hover:bg-blue-100/60 shadow-xs cursor-pointer transition-all hover:scale-102"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Med Sarthi AI</span>
          </button>

          {/* Emergency SOS Button */}
          <button
            onClick={onOpenEmergency}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold shadow-sm shadow-red-500/25 transition-all active:scale-95 cursor-pointer"
            title="Emergency Medical Alert"
          >
            <AlertCircle className="w-4 h-4 animate-bounce" />
            <span className="hidden sm:inline">EMERGENCY SOS</span>
            <span className="sm:hidden">SOS</span>
          </button>

          {/* Notifications */}
          <button
            onClick={() => onNavigate('notifications')}
            className="relative p-2 rounded-xl text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer"
            title="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center ring-2 ring-white">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Profile Pill */}
          <div
            onClick={() => onNavigate('patient-profile')}
            className="flex items-center gap-2.5 p-1 pl-2 pr-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl cursor-pointer transition-colors"
          >
            <img
              src={patient?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'}
              alt={patient?.name || 'User Profile'}
              className="w-7 h-7 rounded-lg object-cover ring-1 ring-blue-500/30"
            />
            <div className="hidden xl:block text-left">
              <p className="text-xs font-semibold text-slate-800 leading-tight">{patient?.name || 'Rahul Sharma'}</p>
              <p className="text-[10px] text-slate-500 font-mono">{patient?.bloodGroup || 'O+ Positive'}</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
