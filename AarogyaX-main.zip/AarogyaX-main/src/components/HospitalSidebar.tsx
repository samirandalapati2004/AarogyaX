import React from 'react';
import {
  Building2,
  BarChart3,
  Users,
  ShieldCheck,
  BedDouble,
  FileSpreadsheet,
  Activity,
  Layers,
} from 'lucide-react';
import { MainView } from '../types';

interface HospitalSidebarProps {
  currentView: MainView;
  onNavigate: (view: MainView) => void;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export const HospitalSidebar: React.FC<HospitalSidebarProps> = ({
  currentView,
  onNavigate,
  isOpenMobile,
  onCloseMobile,
}) => {
  const navItems = [
    {
      id: 'hospital-dashboard' as MainView,
      label: 'Hospital Overview',
      icon: Building2,
      badge: 'Apollo Network',
    },
    {
      id: 'hospital-dashboard' as MainView,
      label: 'Departments & OPD',
      icon: Layers,
      badge: '6 Units',
    },
    {
      id: 'hospital-dashboard' as MainView,
      label: 'Doctor Credentialing',
      icon: ShieldCheck,
      badge: '1 Pending',
    },
    {
      id: 'hospital-analytics' as MainView,
      label: 'Analytics & Trends',
      icon: BarChart3,
      badge: 'Real-time',
      isSpecial: true,
    },
  ];

  const handleItemClick = (view: MainView) => {
    onNavigate(view);
    if (onCloseMobile) onCloseMobile();
  };

  return (
    <>
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      <aside
        className={`fixed lg:sticky top-16 left-0 z-40 w-64 h-[calc(100vh-4rem)] bg-white border-r border-slate-200 overflow-y-auto transition-transform duration-200 ease-in-out ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="p-4 space-y-6">
          {/* Hospital Info Card */}
          <div className="p-3 bg-gradient-to-br from-indigo-50 to-blue-50/50 rounded-2xl border border-indigo-100 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                AH
              </div>
              <div>
                <p className="text-xs font-bold text-slate-800">Apollo Hospitals</p>
                <p className="text-[10px] text-indigo-700 font-medium">Main Bannerghatta Hub</p>
              </div>
            </div>
            <span className="w-2 h-2 rounded-full bg-emerald-500 ring-4 ring-emerald-100" title="Operational" />
          </div>

          {/* Navigation Section */}
          <div className="space-y-1">
            <p className="px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Hospital Operations
            </p>
            {navItems.map((item, idx) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;

              return (
                <button
                  key={`${item.id}-${idx}`}
                  onClick={() => handleItemClick(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? item.isSpecial
                        ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white shadow-sm shadow-indigo-500/25'
                        : 'bg-indigo-50 text-indigo-800 border border-indigo-200 font-bold'
                      : item.isSpecial
                      ? 'bg-indigo-50/70 text-indigo-800 border border-indigo-100 hover:bg-indigo-100/50'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon
                      className={`w-4 h-4 ${
                        isActive
                          ? item.isSpecial
                            ? 'text-white'
                            : 'text-indigo-600'
                          : 'text-slate-400'
                      }`}
                    />
                    <span>{item.label}</span>
                  </div>

                  {item.badge && (
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        isActive
                          ? item.isSpecial
                            ? 'bg-white/20 text-white'
                            : 'bg-indigo-200 text-indigo-800'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Hospital Bed & OPD Capacity Metric */}
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
            <div className="flex justify-between items-center text-slate-600">
              <span className="font-medium">Total OPD Patients Today</span>
              <span className="font-bold text-slate-900">312</span>
            </div>
            <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
              <div className="bg-indigo-600 h-full rounded-full w-[78%]"></div>
            </div>
            <div className="flex justify-between items-center text-[10px] text-slate-500">
              <span>78% Capacity</span>
              <span>60 Active Doctors</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
