import React from 'react';
import { MedicalRecord } from '../types';

interface RecordDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  record: MedicalRecord | null;
}

export const RecordDetailModal: React.FC<RecordDetailModalProps> = ({ isOpen, onClose, record }) => {
  if (!isOpen || !record) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border-2 border-[#141414] max-w-xl w-full overflow-hidden shadow-[8px_8px_0px_#141414]">
        {/* Header */}
        <div className="bg-[#141414] text-white p-4 border-b border-[#141414] flex items-center justify-between font-mono-tech">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 border border-white/40 bg-white/10 flex items-center justify-center font-bold text-xs">
              DOC
            </div>
            <div>
              <h3 className="font-bold text-sm uppercase">{record.title}</h3>
              <p className="text-[10px] text-white/70">{record.facility} // {record.uploadDate}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-white/20 text-white cursor-pointer">
            <span className="material-symbols-outlined text-base">close</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* AI Summary Banner if present */}
          {record.isAiSummarized && (
            <div className="bg-[#F0EFED] border border-[#141414] p-4">
              <div className="flex items-start gap-3">
                <div className="w-7 h-7 bg-[#2A5CFF] text-white flex items-center justify-center font-mono-tech text-[10px] font-bold shrink-0">
                  AI
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono-tech text-xs font-bold text-[#141414] uppercase">
                      Med Sarthi AI Clinical Synthesis
                    </span>
                    <span className="tech-tag-accent text-[8px] py-0 px-1">VERIFIED</span>
                  </div>
                  <p className="text-xs text-[#5A5A58] leading-relaxed font-mono-tech">
                    {record.aiSummaryText || 'Diagnostic evaluation demonstrates stable cardiac output and normal systemic parameters with no acute abnormalities.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Key Biomarkers & Findings */}
          {record.keyFindings && record.keyFindings.length > 0 && (
            <div className="space-y-2">
              <span className="text-[10px] font-mono-tech font-bold text-[#5A5A58] uppercase tracking-wider">
                Key Biomarkers & Test Findings
              </span>
              <div className="space-y-1.5 font-mono-tech text-xs">
                {record.keyFindings.map((finding, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-2.5 bg-white border border-[#141414]"
                  >
                    <div>
                      <p className="font-bold text-[#141414] uppercase">{finding.label}</p>
                      <p className="text-[11px] text-[#5A5A58]">{finding.value}</p>
                    </div>
                    <span
                      className={`tech-tag text-[9px] ${
                        finding.status === 'normal'
                          ? 'bg-[#F0EFED] text-[#079455]'
                          : finding.status === 'elevated'
                          ? 'bg-[#FEE4E2] text-[#D92D20]'
                          : 'bg-[#F0EFED] text-[#141414]'
                      }`}
                    >
                      {finding.status.toUpperCase()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Document Metadata */}
          <div className="bg-[#F0EFED] border border-[#141414]/20 p-4 font-mono-tech text-xs space-y-1.5 text-[#5A5A58]">
            <div className="flex justify-between">
              <span>CATEGORY:</span>
              <span className="font-bold text-[#141414]">{record.category}</span>
            </div>
            {record.doctorName && (
              <div className="flex justify-between">
                <span>VERIFIED PHYSICIAN:</span>
                <span className="font-bold text-[#141414]">{record.doctorName}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span>DIAGNOSTIC FACILITY:</span>
              <span className="font-bold text-[#141414]">{record.facility}</span>
            </div>
            <div className="flex justify-between">
              <span>DOCUMENT SIZE:</span>
              <span className="text-[#141414]">{record.fileSize || '2.4 MB'}</span>
            </div>
            <div className="flex justify-between">
              <span>ENCRYPTION:</span>
              <span className="text-[#079455] font-bold">AES-256 VAULT PROTECTED</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#F0EFED] px-6 py-3 border-t border-[#141414] flex justify-between items-center font-mono-tech text-xs">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-white border border-[#141414] text-[#141414] font-bold hover:bg-[#141414] hover:text-white transition-colors cursor-pointer uppercase"
          >
            Close
          </button>
          <button
            onClick={() => {
              alert('Document downloaded securely from encrypted clinical vault.');
            }}
            className="px-4 py-1.5 bg-[#141414] text-white border border-[#141414] font-bold hover:bg-[#2A5CFF] transition-colors cursor-pointer uppercase flex items-center gap-1"
          >
            <span className="material-symbols-outlined text-sm">download</span>
            Download PDF
          </button>
        </div>
      </div>
    </div>
  );
};
