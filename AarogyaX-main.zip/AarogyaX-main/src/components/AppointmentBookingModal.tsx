import React, { useState } from 'react';
import { Doctor, Appointment } from '../types';

interface AppointmentBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  doctor: Doctor | null;
  onBookSuccess: (newAppointment: Appointment) => void;
}

export const AppointmentBookingModal: React.FC<AppointmentBookingModalProps> = ({
  isOpen,
  onClose,
  doctor,
  onBookSuccess,
}) => {
  const [selectedDay, setSelectedDay] = useState('Today');
  const [selectedSlot, setSelectedSlot] = useState(doctor?.timeSlots[0] || '11:15 AM');
  const [consultType, setConsultType] = useState<'Video Call' | 'In-Person'>('In-Person');
  const [reason, setReason] = useState('Gastrointestinal discomfort, persistent abdominal pain');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen || !doctor) return null;

  const handleConfirm = () => {
    const newAppt: Appointment = {
      id: `appt-${Date.now()}`,
      doctorId: doctor.id,
      doctorName: doctor.name,
      doctorSpecialty: doctor.title,
      doctorHospital: doctor.hospital,
      doctorAvatarUrl: doctor.avatarUrl,
      date: selectedDay === 'Today' ? 'Today' : `${selectedDay}, Oct 25`,
      time: selectedSlot,
      status: 'Confirmed',
      type: consultType,
      notes: reason,
    };
    setIsSuccess(true);
    setTimeout(() => {
      onBookSuccess(newAppt);
      setIsSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border-2 border-[#141414] max-w-lg w-full overflow-hidden shadow-[8px_8px_0px_#141414]">
        {/* Header */}
        <div className="bg-[#141414] text-white p-4 border-b border-[#141414] flex items-center justify-between font-mono-tech">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 border border-white/40 bg-[#F0EFED] overflow-hidden shrink-0">
              <img src={doctor.avatarUrl} alt={doctor.name} className="w-full h-full object-cover grayscale contrast-125" />
            </div>
            <div>
              <h3 className="font-bold text-sm uppercase">{doctor.name}</h3>
              <p className="text-[10px] text-white/70">{doctor.title} // {doctor.hospital}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-white/20 text-white cursor-pointer">
            <span className="material-symbols-outlined text-base">close</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {isSuccess ? (
            <div className="py-8 text-center space-y-3">
              <div className="w-12 h-12 bg-[#079455] text-white mx-auto flex items-center justify-center">
                <span className="material-symbols-outlined text-2xl">check_circle</span>
              </div>
              <h4 className="text-base font-bold font-mono-tech uppercase text-[#141414]">Appointment Confirmed</h4>
              <p className="text-xs text-[#5A5A58] font-mono-tech">
                Consultation scheduled with {doctor.name} for <b>{selectedDay} at {selectedSlot}</b>.
              </p>
            </div>
          ) : (
            <>
              {/* Consultation Type */}
              <div className="space-y-2">
                <label className="text-[10px] font-mono-tech font-bold text-[#5A5A58] uppercase tracking-wider">
                  01 // Consultation Mode
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setConsultType('In-Person')}
                    className={`p-3 border font-mono-tech text-xs transition-colors cursor-pointer text-left ${
                      consultType === 'In-Person'
                        ? 'bg-[#141414] text-white border-[#141414]'
                        : 'bg-white text-[#141414] border-[#141414] hover:bg-[#F0EFED]'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className="material-symbols-outlined text-base">local_hospital</span>
                      <span className="font-bold uppercase">In-Person Visit</span>
                    </div>
                    <p className="text-[10px] opacity-75">{doctor.hospital}</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setConsultType('Video Call')}
                    className={`p-3 border font-mono-tech text-xs transition-colors cursor-pointer text-left ${
                      consultType === 'Video Call'
                        ? 'bg-[#141414] text-white border-[#141414]'
                        : 'bg-white text-[#141414] border-[#141414] hover:bg-[#F0EFED]'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className="material-symbols-outlined text-base">videocam</span>
                      <span className="font-bold uppercase">HD Video Call</span>
                    </div>
                    <p className="text-[10px] opacity-75">Encrypted Stream</p>
                  </button>
                </div>
              </div>

              {/* Day Selection */}
              <div className="space-y-2">
                <label className="text-[10px] font-mono-tech font-bold text-[#5A5A58] uppercase tracking-wider">
                  02 // Available Date
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['Today', 'Tomorrow', 'Fri, Oct 27'].map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setSelectedDay(d)}
                      className={`py-2 border font-mono-tech text-xs uppercase cursor-pointer transition-colors ${
                        selectedDay === d
                          ? 'bg-[#141414] text-white border-[#141414] font-bold'
                          : 'bg-white text-[#141414] border-[#141414] hover:bg-[#F0EFED]'
                      }`}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>

              {/* Time Slots */}
              <div className="space-y-2">
                <label className="text-[10px] font-mono-tech font-bold text-[#5A5A58] uppercase tracking-wider">
                  03 // Slot Selection
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {doctor.timeSlots.map((slot) => (
                    <button
                      key={slot}
                      type="button"
                      onClick={() => setSelectedSlot(slot)}
                      className={`py-2 border font-mono-tech text-xs uppercase cursor-pointer transition-colors ${
                        selectedSlot === slot
                          ? 'bg-[#2A5CFF] text-white border-[#141414] font-bold'
                          : 'bg-white text-[#141414] border-[#141414] hover:bg-[#F0EFED]'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              {/* Clinical Chief Complaint */}
              <div className="space-y-1">
                <label className="text-[10px] font-mono-tech font-bold text-[#5A5A58] uppercase tracking-wider">
                  04 // Chief Complaint / Notes
                </label>
                <textarea
                  rows={2}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full text-xs font-mono-tech p-2.5 bg-white border border-[#141414] focus:outline-none focus:ring-2 focus:ring-[#2A5CFF]"
                />
              </div>

              {/* Fee & Action */}
              <div className="bg-[#F0EFED] p-3 border border-[#141414] flex justify-between items-center font-mono-tech text-xs">
                <div>
                  <span className="text-[#5A5A58] text-[10px] block uppercase">Consultation Fee</span>
                  <span className="text-base font-bold text-[#141414]">${doctor.consultationFee}</span>
                </div>
                <button
                  type="button"
                  onClick={handleConfirm}
                  className="px-5 py-2.5 bg-[#2A5CFF] hover:bg-[#1742DB] text-white font-mono-tech font-bold text-xs border border-[#141414] uppercase tracking-wider shadow-[2px_2px_0px_#141414] cursor-pointer active:translate-x-0.5 active:translate-y-0.5"
                >
                  Confirm & Schedule &gt;
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
