import React, { useState } from 'react';
import { MedicalRecord } from '../types';

interface UploadDocModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadSuccess: (record: MedicalRecord) => void;
}

export const UploadDocModal: React.FC<UploadDocModalProps> = ({ isOpen, onClose, onUploadSuccess }) => {
  const [docTitle, setDocTitle] = useState('');
  const [docCategory, setDocCategory] = useState<'Lab Reports' | 'Prescriptions' | 'Vaccinations' | 'Scans'>('Lab Reports');
  const [facility, setFacility] = useState('Apollo Diagnostics Centre');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedFileName, setSelectedFileName] = useState('');

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFileName(file.name);
      if (!docTitle) {
        setDocTitle(file.name.replace(/\.[^/.]+$/, ''));
      }
    }
  };

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle) return;

    setIsAnalyzing(true);
    setTimeout(() => {
      const newRec: MedicalRecord = {
        id: `rec-${Date.now()}`,
        title: docTitle,
        category: docCategory,
        facility: facility || 'Verified Clinic',
        doctorName: 'Dr. Diagnostic AI',
        uploadDate: 'Today, Oct 24, 2023',
        statusBadge: 'AI SUMMARIZED',
        badgeType: 'ai-summarized',
        isAiSummarized: true,
        aiSummaryText: `Automated Med Sarthi ingestion verified for ${docTitle}. All critical test parameters parsed and indexed for longitudinal tracking.`,
        fileSize: '2.4 MB',
        fileType: 'PDF Document',
        keyFindings: [
          { label: 'Ingestion Status', value: 'Validated & Encrypted', status: 'normal' },
          { label: 'Longitudinal Sync', value: 'Updated to Vault', status: 'stable' },
        ],
      };
      setIsAnalyzing(false);
      onUploadSuccess(newRec);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border-2 border-[#141414] max-w-lg w-full overflow-hidden shadow-[8px_8px_0px_#141414]">
        {/* Header */}
        <div className="bg-[#141414] text-white p-4 border-b border-[#141414] flex items-center justify-between font-mono-tech">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 border border-white/40 bg-white/10 flex items-center justify-center">
              <span className="material-symbols-outlined text-lg text-white">upload_file</span>
            </div>
            <div>
              <h3 className="font-bold text-sm uppercase">Upload Medical Document</h3>
              <p className="text-[10px] text-white/70">INGESTION // ENCRYPTION PIPELINE</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-white/20 text-white cursor-pointer">
            <span className="material-symbols-outlined text-base">close</span>
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleUpload} className="p-6 space-y-4 font-mono-tech text-xs">
          {/* File Dropzone */}
          <div className="border border-dashed border-[#141414] p-6 text-center bg-[#F0EFED] hover:bg-white transition-colors cursor-pointer relative">
            <input
              type="file"
              accept=".pdf,.png,.jpg,.jpeg,.dcm"
              onChange={handleFileChange}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
            <div className="w-10 h-10 border border-[#141414] bg-white text-[#141414] flex items-center justify-center mx-auto mb-2">
              <span className="material-symbols-outlined text-xl">cloud_upload</span>
            </div>
            {selectedFileName ? (
              <p className="font-bold text-[#2A5CFF]">{selectedFileName}</p>
            ) : (
              <>
                <p className="font-bold text-[#141414] uppercase">Select or Drag File to Ingest</p>
                <p className="text-[10px] text-[#5A5A58] mt-0.5">PDF, DICOM, JPG up to 25MB // AES-256 Encrypted</p>
              </>
            )}
          </div>

          {/* Document Title */}
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-[#5A5A58] uppercase">Document Title</label>
            <input
              type="text"
              required
              value={docTitle}
              onChange={(e) => setDocTitle(e.target.value)}
              placeholder="e.g. Upper GI Endoscopy Report"
              className="w-full p-2.5 bg-white border border-[#141414] focus:ring-2 focus:ring-[#2A5CFF] focus:outline-none"
            />
          </div>

          {/* Category */}
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-[#5A5A58] uppercase">Record Classification</label>
            <select
              value={docCategory}
              onChange={(e) => setDocCategory(e.target.value as any)}
              className="w-full p-2.5 bg-white border border-[#141414] focus:ring-2 focus:ring-[#2A5CFF] focus:outline-none uppercase"
            >
              <option value="Lab Reports">Lab Reports</option>
              <option value="Prescriptions">Prescriptions</option>
              <option value="Scans">Scans & Radiology</option>
              <option value="Vaccinations">Vaccinations</option>
            </select>
          </div>

          {/* Facility */}
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-[#5A5A58] uppercase">Diagnostic Facility / Clinic</label>
            <input
              type="text"
              value={facility}
              onChange={(e) => setFacility(e.target.value)}
              placeholder="e.g. Apollo Diagnostics"
              className="w-full p-2.5 bg-white border border-[#141414] focus:ring-2 focus:ring-[#2A5CFF] focus:outline-none"
            />
          </div>

          {/* AI Parsing Note */}
          <div className="bg-[#F0EFED] p-3 border border-[#141414] flex items-center gap-2 text-[11px] text-[#141414]">
            <span className="material-symbols-outlined text-[#2A5CFF] text-base" data-weight="fill">smart_toy</span>
            <span>Med Sarthi AI will automatically parse biomarkers & update longitudinal health graphs.</span>
          </div>

          {/* Actions */}
          <div className="pt-2 flex justify-between items-center">
            <button
              type="button"
              onClick={onClose}
              className="font-bold text-[#5A5A58] hover:text-[#141414] cursor-pointer uppercase"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isAnalyzing}
              className="px-5 py-2.5 bg-[#2A5CFF] hover:bg-[#1742DB] text-white font-bold border border-[#141414] shadow-[2px_2px_0px_#141414] transition-all active:translate-x-0.5 active:translate-y-0.5 disabled:opacity-50 cursor-pointer flex items-center gap-2 uppercase tracking-wider"
            >
              {isAnalyzing ? (
                <>
                  <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  Processing Ingestion...
                </>
              ) : (
                'Upload & Ingest >'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
