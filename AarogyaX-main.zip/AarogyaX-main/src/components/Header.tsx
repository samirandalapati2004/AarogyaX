import React from 'react';
import { PatientProfile, NavigationTab } from '../types';

interface HeaderProps {
  patient: PatientProfile;
  currentTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  onOpenEmergency: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  patient,
  currentTab,
  onTabChange,
  onOpenEmergency,
}) => {
  return (
    <>
      {/* Desktop TopAppBar */}
      <header className="bg-white border-b border-[#141414] justify-between items-center w-full px-6 py-3 hidden md:flex sticky top-0 z-40">
        <div
          className="flex items-center gap-3 cursor-pointer group"
          onClick={() => onTabChange('home')}
        >
          <div className="w-9 h-9 border border-[#141414] overflow-hidden bg-[#F0EFED] shrink-0">
            <img
              className="w-full h-full object-cover grayscale contrast-125 group-hover:grayscale-0 transition-all"
              alt={patient.name}
              src={patient.avatarUrl}
            />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="text-base font-black tracking-tight text-[#141414] uppercase">
                AarogyaX
              </span>
              <span className="tech-tag text-[9px] py-0 px-1.5 bg-[#F0EFED]">v2.4_PRO</span>
            </div>
            <span className="font-mono-tech text-[10px] text-[#5A5A58] uppercase">
              ID: {patient.medicalId} // HEALTH_CORE
            </span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <div className="flex items-center gap-8">
          <button
            onClick={() => onTabChange('home')}
            className={`text-xs uppercase font-bold tracking-wider transition-colors cursor-pointer py-1 font-mono-tech ${
              currentTab === 'home'
                ? 'text-[#2A5CFF] border-b-2 border-[#2A5CFF]'
                : 'text-[#5A5A58] hover:text-[#141414]'
            }`}
          >
            [01] Dashboard
          </button>
          <button
            onClick={() => onTabChange('schedule')}
            className={`text-xs uppercase font-bold tracking-wider transition-colors cursor-pointer py-1 font-mono-tech ${
              currentTab === 'schedule'
                ? 'text-[#2A5CFF] border-b-2 border-[#2A5CFF]'
                : 'text-[#5A5A58] hover:text-[#141414]'
            }`}
          >
            [02] Schedule
          </button>
          <button
            onClick={() => onTabChange('sarthi')}
            className={`text-xs uppercase font-bold tracking-wider transition-colors cursor-pointer py-1 flex items-center gap-1.5 font-mono-tech ${
              currentTab === 'sarthi'
                ? 'text-[#2A5CFF] border-b-2 border-[#2A5CFF]'
                : 'text-[#5A5A58] hover:text-[#2A5CFF]'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-[#2A5CFF] animate-pulse"></span>
            [03] Med Sarthi
          </button>
          <button
            onClick={() => onTabChange('records')}
            className={`text-xs uppercase font-bold tracking-wider transition-colors cursor-pointer py-1 font-mono-tech ${
              currentTab === 'records'
                ? 'text-[#2A5CFF] border-b-2 border-[#2A5CFF]'
                : 'text-[#5A5A58] hover:text-[#141414]'
            }`}
          >
            [04] Records Vault
          </button>
          <button
            onClick={() => onTabChange('profile')}
            className={`text-xs uppercase font-bold tracking-wider transition-colors cursor-pointer py-1 font-mono-tech ${
              currentTab === 'profile'
                ? 'text-[#2A5CFF] border-b-2 border-[#2A5CFF]'
                : 'text-[#5A5A58] hover:text-[#141414]'
            }`}
          >
            [05] Profile
          </button>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden lg:flex flex-col text-right font-mono-tech text-[10px] text-[#5A5A58]">
            <span className="font-bold text-[#141414]">{patient.name.toUpperCase()}</span>
            <span>STATUS: STABLE_NORMAL</span>
          </div>

          <button
            onClick={onOpenEmergency}
            className="bg-[#D92D20] hover:bg-[#B42318] text-white text-xs font-mono-tech font-bold px-3.5 py-1.5 border border-[#141414] flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer uppercase tracking-wider shadow-[2px_2px_0px_#141414]"
          >
            <span className="material-symbols-outlined text-base">emergency</span>
            EMERGENCY_SOS
          </button>
        </div>
      </header>

      {/* Mobile Header */}
      <header className="md:hidden flex justify-between items-center px-4 py-3 bg-white sticky top-0 z-40 border-b border-[#141414]">
        <div
          className="flex items-center gap-2.5 cursor-pointer"
          onClick={() => onTabChange('profile')}
        >
          <div className="w-8 h-8 border border-[#141414] overflow-hidden bg-[#F0EFED]">
            <img
              className="w-full h-full object-cover"
              alt={patient.name}
              src={patient.avatarUrl}
            />
          </div>
          <div>
            <h1 className="text-xs font-bold text-[#141414] uppercase tracking-tight">{patient.name}</h1>
            <p className="font-mono-tech text-[9px] text-[#5A5A58] uppercase">ID: {patient.medicalId}</p>
          </div>
        </div>

        <button
          onClick={onOpenEmergency}
          aria-label="Emergency SOS"
          className="px-2.5 py-1 bg-[#D92D20] text-white text-[10px] font-mono-tech font-bold border border-[#141414] flex items-center gap-1 active:scale-95 shadow-[1px_1px_0px_#141414]"
        >
          <span className="material-symbols-outlined text-sm font-bold">sos</span>
          <span>SOS</span>
        </button>
      </header>
    </>
  );
};
