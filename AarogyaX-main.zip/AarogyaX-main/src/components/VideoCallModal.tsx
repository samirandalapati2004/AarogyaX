import React, { useState } from 'react';
import { Appointment } from '../types';

interface VideoCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointment: Appointment;
}

export const VideoCallModal: React.FC<VideoCallModalProps> = ({ isOpen, onClose, appointment }) => {
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [chatMessages, setChatMessages] = useState<{ sender: string; text: string; time: string }[]>([
    { sender: 'Dr. Anjali Desai', text: 'Hello Rahul! Reviewing your latest ECG and MRI report now.', time: '10:30 AM' },
    { sender: 'Rahul Sharma', text: 'Good morning Doctor. Everything looks stable with the blood pressure.', time: '10:31 AM' },
  ]);
  const [inputMessage, setInputMessage] = useState('');

  if (!isOpen) return null;

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;
    setChatMessages([
      ...chatMessages,
      { sender: 'Rahul Sharma', text: inputMessage, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
    ]);
    setInputMessage('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 md:p-6 bg-black/80 backdrop-blur-md animate-fade-in font-mono-tech">
      <div className="bg-[#141414] text-white w-full max-w-4xl h-[90vh] max-h-[750px] flex flex-col overflow-hidden border-2 border-[#141414] shadow-[8px_8px_0px_rgba(255,255,255,0.2)]">
        {/* Call Header */}
        <div className="bg-black/60 px-4 py-3 flex items-center justify-between border-b border-white/20">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={appointment.doctorAvatarUrl}
                alt={appointment.doctorName}
                className="w-9 h-9 object-cover border border-[#2A5CFF]"
              />
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-[#079455] border border-black"></span>
            </div>
            <div>
              <h3 className="font-bold text-xs md:text-sm uppercase leading-tight">{appointment.doctorName}</h3>
              <p className="text-[10px] text-[#2A5CFF]">{appointment.doctorSpecialty} // {appointment.doctorHospital}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 text-[10px] bg-[#D92D20]/20 text-[#D92D20] border border-[#D92D20]/50 px-2 py-0.5">
              <span className="w-1.5 h-1.5 bg-[#D92D20] animate-pulse"></span>
              REC 12:45
            </span>
            <button
              onClick={onClose}
              className="p-1 hover:bg-white/20 text-gray-400 hover:text-white cursor-pointer"
            >
              <span className="material-symbols-outlined text-base">close</span>
            </button>
          </div>
        </div>

        {/* Video Area & Panel */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
          {/* Main Doctor Screen */}
          <div className="flex-1 bg-black relative flex items-center justify-center p-4">
            <div className="relative w-full h-full max-w-2xl max-h-[480px] overflow-hidden bg-zinc-900 border border-white/20 flex items-center justify-center">
              <img
                src={appointment.doctorAvatarUrl}
                alt={appointment.doctorName}
                className="w-full h-full object-cover opacity-90 grayscale contrast-125"
              />

              {/* Patient PiP Video */}
              <div className="absolute top-4 right-4 w-28 md:w-36 aspect-video bg-black overflow-hidden border border-white/40 shadow-lg flex items-center justify-center">
                {isVideoOff ? (
                  <div className="flex flex-col items-center justify-center text-gray-400 text-[10px]">
                    <span className="material-symbols-outlined text-base">videocam_off</span>
                    <span>VIDEO_OFF</span>
                  </div>
                ) : (
                  <img
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuBsDRKKyPXPUufe5dee0HImM595b7FlZqhsQTwxjSmTCzooxWiHibaFncp0fyXiBheSyPReJqQMxpO2mAsjh61Sgw6rZ8NGBbqZzjp9STbc-x5A5Jxl9OkrB0lG6THAZJIeEDp0zK0C1NHkMkDghaN8QHRK5qsNFXnN3JkM4OOt8mBjMwWzB-N2VD0B9yGOtxBSdPIi3tX1ek4Dmc8GsG2Vf6gdGGL8pT3Dux_PXkzklZJOuuD-LGHS"
                    alt="You"
                    className="w-full h-full object-cover"
                  />
                )}
                <span className="absolute bottom-1 left-1 text-[9px] bg-black/80 px-1 text-white">YOU</span>
              </div>

              {/* Status Overlay */}
              <div className="absolute bottom-4 left-4 flex items-center gap-2 bg-black/80 px-2.5 py-1 text-[10px] border border-white/20">
                <span className="w-2 h-2 bg-[#079455]"></span>
                <span>HD_STREAM // ENCRYPTED_AES256</span>
              </div>
            </div>
          </div>

          {/* Chat Side Drawer (Desktop) */}
          <div className="w-full md:w-72 bg-zinc-900 border-t md:border-t-0 md:border-l border-white/20 flex flex-col">
            <div className="p-3 border-b border-white/20 flex justify-between items-center text-xs">
              <span className="font-bold uppercase tracking-wider text-white/90">Clinical Transcript</span>
              <span className="tech-tag bg-zinc-800 text-white text-[9px]">LIVE</span>
            </div>

            <div className="flex-1 p-3 overflow-y-auto space-y-2 text-xs">
              {chatMessages.map((msg, i) => (
                <div key={i} className="bg-black/60 p-2.5 border border-white/10 space-y-0.5">
                  <div className="flex justify-between text-[10px] text-gray-400 font-bold uppercase">
                    <span>{msg.sender}</span>
                    <span>{msg.time}</span>
                  </div>
                  <p className="text-[11px] text-gray-200 font-sans">{msg.text}</p>
                </div>
              ))}
            </div>

            <form onSubmit={handleSendMessage} className="p-2 border-t border-white/20 flex gap-1">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Type note to physician..."
                className="flex-1 bg-black border border-white/30 text-white text-xs px-2 py-1.5 focus:outline-none focus:border-[#2A5CFF] font-sans"
              />
              <button
                type="submit"
                className="bg-[#2A5CFF] text-white px-3 py-1.5 text-xs font-bold uppercase cursor-pointer"
              >
                Send
              </button>
            </form>
          </div>
        </div>

        {/* Video Controls Footer */}
        <div className="bg-black px-6 py-4 flex items-center justify-between border-t border-white/20">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className={`px-3 py-2 border text-xs font-bold uppercase flex items-center gap-1 cursor-pointer ${
                isMuted ? 'bg-[#D92D20] text-white border-[#D92D20]' : 'bg-zinc-800 text-white border-white/30 hover:bg-zinc-700'
              }`}
            >
              <span className="material-symbols-outlined text-base">{isMuted ? 'mic_off' : 'mic'}</span>
              <span>{isMuted ? 'MUTED' : 'MUTE'}</span>
            </button>

            <button
              onClick={() => setIsVideoOff(!isVideoOff)}
              className={`px-3 py-2 border text-xs font-bold uppercase flex items-center gap-1 cursor-pointer ${
                isVideoOff ? 'bg-[#D92D20] text-white border-[#D92D20]' : 'bg-zinc-800 text-white border-white/30 hover:bg-zinc-700'
              }`}
            >
              <span className="material-symbols-outlined text-base">{isVideoOff ? 'videocam_off' : 'videocam'}</span>
              <span>{isVideoOff ? 'CAM_OFF' : 'CAM'}</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#D92D20] hover:bg-[#B42318] text-white font-bold text-xs uppercase border border-white/40 shadow-[2px_2px_0px_rgba(255,255,255,0.3)] cursor-pointer active:translate-x-0.5 active:translate-y-0.5 flex items-center gap-1.5"
          >
            <span className="material-symbols-outlined text-base">call_end</span>
            DISCONNECT CALL
          </button>
        </div>
      </div>
    </div>
  );
};
