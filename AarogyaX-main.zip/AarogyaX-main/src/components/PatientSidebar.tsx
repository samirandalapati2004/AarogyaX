import React from 'react';
import {
  LayoutDashboard,
  Sparkles,
  CalendarDays,
  FolderHeart,
  FileText,
  Pill,
  Syringe,
  ShieldCheck,
  History,
  User,
  Bell,
  Stethoscope,
  ClipboardList,
  ChevronRight,
  FileSearch,
} from 'lucide-react';
import { MainView } from '../types';

interface PatientSidebarProps {
  currentView: MainView;
  onNavigate: (view: MainView) => void;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export const PatientSidebar: React.FC<PatientSidebarProps> = ({
  currentView,
  onNavigate,
  isOpenMobile,
  onCloseMobile,
}) => {
  const navItems = [
    {
      id: 'home' as MainView,
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: '',
    },
    {
      id: 'med-sarthi' as MainView,
      label: 'Med Sarthi AI',
      icon: Sparkles,
      badge: 'AI Active',
      isSpecial: true,
    },
    {
      id: 'specialties' as MainView,
      label: 'Find Specialists',
      icon: Stethoscope,
      badge: '12 Depts',
    },
    {
      id: 'doctor-discovery' as MainView,
      label: 'Doctors & Clinics',
      icon: CalendarDays,
      badge: '',
    },
    {
      id: 'pre-consultation' as MainView,
      label: 'Pre-Consultation Form',
      icon: ClipboardList,
      badge: 'Step Form',
    },
    {
      id: 'medical-records' as MainView,
      label: 'Medical Records',
      icon: FolderHeart,
      badge: '5 Items',
    },
    {
      id: 'report-viewer' as MainView,
      label: 'Report AI Viewer',
      icon: FileSearch,
      badge: '',
    },
    {
      id: 'prescriptions' as MainView,
      label: 'Digital Rx & Audio',
      icon: FileText,
      badge: '',
    },
    {
      id: 'medicine-reminders' as MainView,
      label: 'Medicine Reminders',
      icon: Pill,
      badge: '2 Today',
    },
    {
      id: 'vaccinations' as MainView,
      label: 'Vaccination Tracker',
      icon: Syringe,
      badge: '',
    },
    {
      id: 'consent-management' as MainView,
      label: 'Consent & Privacy',
      icon: ShieldCheck,
      badge: '1 Pending',
    },
    {
      id: 'audit-log' as MainView,
      label: 'Security Audit Log',
      icon: History,
      badge: '',
    },
    {
      id: 'notifications' as MainView,
      label: 'Notifications',
      icon: Bell,
      badge: '',
    },
    {
      id: 'patient-profile' as MainView,
      label: 'Health Profile',
      icon: User,
      badge: '',
    },
  ];

  const handleItemClick = (view: MainView) => {
    onNavigate(view);
    if (onCloseMobile) onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      <aside
        className={`fixed lg:sticky top-16 left-0 z-40 w-64 h-[calc(100vh-4rem)] bg-white border-r border-slate-200 overflow-y-auto transition-transform duration-200 ease-in-out ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="p-4 space-y-6">
          {/* Patient Quick Card */}
          <div className="p-3 bg-gradient-to-br from-blue-50 to-indigo-50/50 rounded-2xl border border-blue-100 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                RS
              </div>
              <div>
                <p className="text-xs font-bold text-slate-800">Rahul Sharma</p>
                <p className="text-[10px] text-blue-700 font-mono font-medium">ABHA: AX-1029384</p>
              </div>
            </div>
            <span className="w-2 h-2 rounded-full bg-emerald-500 ring-4 ring-emerald-100" title="Connected" />
          </div>

          {/* Navigation Section */}
          <div className="space-y-1">
            <p className="px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Healthcare Journey
            </p>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive =
                item.id === currentView ||
                (item.id === 'home' && (currentView === 'home' || currentView === 'patient-dashboard'));

              return (
                <button
                  key={item.id}
                  id={`sidebar-nav-${item.id}`}
                  onClick={() => handleItemClick(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? item.isSpecial
                        ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-sm shadow-blue-500/25'
                        : 'bg-blue-50 text-blue-700 border border-blue-200/70 font-bold'
                      : item.isSpecial
                      ? 'bg-gradient-to-r from-blue-50/70 to-teal-50/70 text-blue-800 border border-blue-100 hover:bg-blue-100/50'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon
                      className={`w-4 h-4 ${
                        isActive
                          ? item.isSpecial
                            ? 'text-white'
                            : 'text-blue-600'
                          : item.isSpecial
                          ? 'text-blue-600'
                          : 'text-slate-400'
                      }`}
                    />
                    <span>{item.label}</span>
                  </div>

                  {item.badge && (
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        isActive
                          ? item.isSpecial
                            ? 'bg-white/20 text-white'
                            : 'bg-blue-200 text-blue-800'
                          : item.isSpecial
                          ? 'bg-blue-100 text-blue-700'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Quick Help Card */}
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-center">
            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mx-auto">
              <Sparkles className="w-4 h-4" />
            </div>
            <p className="text-xs font-bold text-slate-800">Need Clinical Guidance?</p>
            <p className="text-[11px] text-slate-500">
              Med Sarthi analyzes symptoms & arranges appointments in seconds.
            </p>
            <button
              onClick={() => handleItemClick('med-sarthi')}
              className="w-full py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            >
              Start Symptom Check
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
