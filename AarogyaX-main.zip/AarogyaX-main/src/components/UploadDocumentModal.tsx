import React, { useState } from 'react';
import {
  Upload,
  X,
  FileText,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { MedicalRecord } from '../types';

interface UploadDocumentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadSuccess: (newRecord: Partial<MedicalRecord>) => void;
}

export const UploadDocumentModal: React.FC<UploadDocumentModalProps> = ({
  isOpen,
  onClose,
  onUploadSuccess,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Lab Reports');
  const [facility, setFacility] = useState('Apollo Diagnostics');
  const [fileName, setFileName] = useState('Complete_Blood_Count_Report.pdf');
  const [isAiSummarizeChecked, setIsAiSummarizeChecked] = useState(true);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUploadSuccess({
      id: `rec-${Date.now()}`,
      title: title || 'Comprehensive Health Report',
      category: category as any,
      facility: facility || 'National Diagnostic Centre',
      uploadDate: 'Today',
      fileUrl: '#',
      fileSize: '2.4 MB',
      isAiSummarized: isAiSummarizeChecked,
      aiSummary: {
        summary: 'Parameters evaluated are largely within optimal biological thresholds.',
        keyFindings: [
          'Biomarkers verified within clinical standards.',
          'Digitally signed and encrypted under ABHA specifications.',
        ],
        biomarkers: [
          { name: 'Fasting Blood Glucose', value: '98 mg/dL', referenceRange: '70 - 100 mg/dL', status: 'normal' },
        ],
        recommendations: 'Maintain standard balanced hydration and scheduled physician reviews.',
      },
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 font-sans animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200 relative animate-in zoom-in-95 duration-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 hover:bg-slate-100 rounded-full cursor-pointer transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6 sm:p-7 space-y-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Upload Medical Record</h2>
              <p className="text-xs text-slate-500">Add to your encrypted ABHA personal health vault</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            {/* Drag and Drop Zone */}
            <div className="p-6 border-2 border-dashed border-blue-200 rounded-2xl bg-blue-50/40 text-center space-y-2 cursor-pointer hover:bg-blue-50/70 transition-colors">
              <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mx-auto">
                <FileText className="w-5 h-5" />
              </div>
              <p className="text-slate-800 font-bold">{fileName}</p>
              <p className="text-[11px] text-slate-500">Drag and drop PDF, JPG, or DICOM scans (Up to 25MB)</p>
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-700 uppercase tracking-wider block">Document Title</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Upper Abdominal Ultrasound or CBC Report"
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-bold text-slate-700 uppercase tracking-wider block">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer"
                >
                  <option value="Lab Reports">Lab Reports</option>
                  <option value="Scans & Imaging">Scans & Imaging</option>
                  <option value="Prescriptions">Prescriptions</option>
                  <option value="Discharge Summaries">Discharge Summaries</option>
                  <option value="Vaccinations">Vaccinations</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 uppercase tracking-wider block">Hospital / Diagnostic Lab</label>
                <input
                  type="text"
                  value={facility}
                  onChange={(e) => setFacility(e.target.value)}
                  placeholder="e.g. Apollo Diagnostics"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none"
                />
              </div>
            </div>

            {/* AI Toggle */}
            <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-blue-600" />
                <div>
                  <p className="font-bold text-blue-950">Med Sarthi AI Breakdown</p>
                  <p className="text-[10px] text-slate-500">Automatically extract plain-English findings & biomarkers</p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={isAiSummarizeChecked}
                onChange={(e) => setIsAiSummarizeChecked(e.target.checked)}
                className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-101 cursor-pointer flex items-center justify-center gap-1.5"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Encrypt & Save to Health Vault</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
