import React from 'react';
import {
  LayoutDashboard,
  Calendar,
  Sparkles,
  FolderHeart,
  User,
} from 'lucide-react';
import { MainView } from '../types';

interface BottomNavProps {
  currentView: MainView;
  onNavigate: (view: MainView) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentView, onNavigate }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 lg:hidden bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-lg px-2 py-1">
      <div className="flex items-center justify-around relative">
        {/* Home */}
        <button
          onClick={() => onNavigate('home')}
          className={`flex flex-col items-center justify-center w-14 py-1 cursor-pointer transition-colors ${
            currentView === 'home' || currentView === 'patient-dashboard' ? 'text-blue-600 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <LayoutDashboard className="w-5 h-5 mb-0.5" />
          <span className="text-[10px]">Home</span>
        </button>

        {/* Appointments / Doctors */}
        <button
          onClick={() => onNavigate('doctor-discovery')}
          className={`flex flex-col items-center justify-center w-14 py-1 cursor-pointer transition-colors ${
            currentView === 'doctor-discovery' || currentView === 'specialties' || currentView === 'appointment-booking'
              ? 'text-blue-600 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Calendar className="w-5 h-5 mb-0.5" />
          <span className="text-[10px]">Doctors</span>
        </button>

        {/* Central Prominent Floating Med Sarthi Button */}
        <div className="relative -top-5 flex flex-col items-center">
          <button
            onClick={() => onNavigate('med-sarthi')}
            className={`w-13 h-13 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-200 active:scale-95 cursor-pointer ${
              currentView === 'med-sarthi'
                ? 'bg-gradient-to-tr from-blue-600 to-indigo-600 text-white ring-4 ring-blue-100 shadow-blue-500/40'
                : 'bg-gradient-to-tr from-blue-600 to-teal-500 text-white shadow-blue-500/30 hover:scale-105'
            }`}
            aria-label="Med Sarthi AI Assistant"
          >
            <Sparkles className="w-6 h-6 animate-pulse" />
          </button>
          <span
            className={`text-[10px] font-bold mt-1 ${
              currentView === 'med-sarthi' ? 'text-blue-600' : 'text-slate-600'
            }`}
          >
            Med Sarthi
          </span>
        </div>

        {/* Records */}
        <button
          onClick={() => onNavigate('medical-records')}
          className={`flex flex-col items-center justify-center w-14 py-1 cursor-pointer transition-colors ${
            currentView === 'medical-records' || currentView === 'report-viewer' || currentView === 'prescriptions'
              ? 'text-blue-600 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <FolderHeart className="w-5 h-5 mb-0.5" />
          <span className="text-[10px]">Records</span>
        </button>

        {/* Profile */}
        <button
          onClick={() => onNavigate('patient-profile')}
          className={`flex flex-col items-center justify-center w-14 py-1 cursor-pointer transition-colors ${
            currentView === 'patient-profile' ? 'text-blue-600 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <User className="w-5 h-5 mb-0.5" />
          <span className="text-[10px]">Profile</span>
        </button>
      </div>
    </div>
  );
};
