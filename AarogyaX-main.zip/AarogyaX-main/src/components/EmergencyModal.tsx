import React, { useState } from 'react';
import {
  AlertCircle,
  PhoneCall,
  MapPin,
  X,
  Share2,
  ShieldCheck,
  CheckCircle2,
  HeartPulse,
} from 'lucide-react';
import { PatientProfile } from '../types';

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient: PatientProfile;
}

export const EmergencyModal: React.FC<EmergencyModalProps> = ({
  isOpen,
  onClose,
  patient,
}) => {
  const [isLocationShared, setIsLocationShared] = useState(false);

  if (!isOpen) return null;

  const handleShareLocation = () => {
    setIsLocationShared(true);
    setTimeout(() => setIsLocationShared(false), 5000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 font-sans animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border-2 border-red-500 relative animate-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 hover:bg-slate-100 rounded-full cursor-pointer transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Pulsing Emergency Header */}
        <div className="bg-gradient-to-r from-red-600 via-rose-600 to-red-700 p-6 text-white text-center space-y-2">
          <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center mx-auto ring-4 ring-white/30 backdrop-blur-xs">
            <HeartPulse className="w-8 h-8 text-white animate-pulse" />
          </div>
          <h2 className="text-2xl font-extrabold tracking-tight">EMERGENCY MEDICAL SOS</h2>
          <p className="text-xs text-red-100 max-w-xs mx-auto">
            Immediate emergency triage, ambulance dispatch, and critical health broadcast
          </p>
        </div>

        {/* Body Content */}
        <div className="p-6 space-y-5">
          {/* Direct Call 108 / 112 Action */}
          <div className="grid grid-cols-2 gap-3">
            <a
              href="tel:108"
              className="p-4 bg-red-600 hover:bg-red-700 text-white rounded-2xl text-center shadow-lg shadow-red-500/25 transition-all hover:scale-102 flex flex-col items-center justify-center gap-1.5 cursor-pointer"
            >
              <PhoneCall className="w-6 h-6 animate-bounce" />
              <span className="text-sm font-extrabold">Call Ambulance (108)</span>
            </a>

            <a
              href={`tel:${patient.emergencyContact.phone}`}
              className="p-4 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-center shadow-md transition-all hover:scale-102 flex flex-col items-center justify-center gap-1.5 cursor-pointer"
            >
              <PhoneCall className="w-6 h-6 text-teal-400" />
              <span className="text-sm font-extrabold">Call Next of Kin</span>
            </a>
          </div>

          {/* Nearest Emergency Room */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
            <div className="flex items-center justify-between font-bold text-slate-900">
              <span className="flex items-center gap-1.5 text-red-700">
                <MapPin className="w-4 h-4 text-red-600" />
                Nearest Trauma Centre
              </span>
              <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                1.8 km (4 Mins)
              </span>
            </div>
            <p className="text-slate-800 font-bold">Apollo Hospitals — Emergency & Trauma Wing</p>
            <p className="text-slate-500">Bannerghatta Main Road, Bangalore • 24x7 ER Active</p>
          </div>

          {/* Broadcast Medical Summary */}
          <div className="p-4 bg-red-50/50 rounded-2xl border border-red-100 space-y-2 text-xs">
            <span className="text-[10px] font-bold text-red-800 uppercase tracking-wider block">
              Critical Emergency Responder Card
            </span>
            <div className="grid grid-cols-3 gap-2 text-slate-800">
              <div>
                <span className="text-[10px] text-slate-400 font-bold block">Patient</span>
                <span className="font-bold">{patient.name}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold block">Blood Group</span>
                <span className="font-extrabold text-red-700">{patient.bloodGroup}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold block">Allergies</span>
                <span className="font-bold text-red-700">{patient.allergies[0]}</span>
              </div>
            </div>
          </div>

          {/* Share Live Location */}
          <button
            onClick={handleShareLocation}
            className={`w-full py-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              isLocationShared
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
            }`}
          >
            {isLocationShared ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Live GPS & Medical ID Broadcasted to ER Team!</span>
              </>
            ) : (
              <>
                <Share2 className="w-4 h-4 text-slate-600" />
                <span>Broadcast Live GPS & Medical ID to Emergency Unit</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
