import React, { useState } from 'react';
import {
  Search,
  Stethoscope,
  Sparkles,
  Heart,
  Brain,
  Bone,
  Eye,
  Activity,
  User,
  ShieldCheck,
  ArrowRight,
  Baby,
  Smile,
  ShieldPlus,
  Flame,
  Wind,
  Pill,
} from 'lucide-react';
import { SpecialtyItem, MainView } from '../types';
import { specialtiesData } from '../data/mockData';

interface SpecialtyScreenProps {
  specialties?: SpecialtyItem[];
  onSelectSpecialty: (specialtyName: string) => void;
  onNavigate: (view: MainView) => void;
}

export const SpecialtyScreen: React.FC<SpecialtyScreenProps> = ({
  specialties = specialtiesData,
  onSelectSpecialty,
  onNavigate,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState('All');

  const tags = [
    'All',
    'Most Consulted',
    'Digestive & Internal',
    'Heart & Vitals',
    'Brain & Neuro',
    'Bones & Joints',
    'Women & Child',
  ];

  const getSpecialtyIcon = (id: string) => {
    switch (id) {
      case 'cardio':
        return Heart;
      case 'neuro':
        return Brain;
      case 'ortho':
        return Bone;
      case 'derma':
        return Sparkles;
      case 'pedia':
        return Baby;
      case 'gynae':
        return ShieldPlus;
      case 'ent':
        return Activity;
      case 'opth':
        return Eye;
      case 'pulmo':
        return Wind;
      case 'genmed':
        return ShieldCheck;
      case 'psych':
        return Smile;
      default:
        return Stethoscope;
    }
  };

  const list = specialties && specialties.length > 0 ? specialties : specialtiesData;

  const filtered = list.filter((spec) => {
    const matchesSearch =
      spec.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      spec.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      spec.commonSymptoms.some((sym) => sym.toLowerCase().includes(searchQuery.toLowerCase()));

    if (selectedTag === 'All') return matchesSearch;
    if (selectedTag === 'Most Consulted') {
      return matchesSearch && ['gastro', 'cardio', 'derma', 'genmed'].includes(spec.id);
    }
    if (selectedTag === 'Digestive & Internal') {
      return matchesSearch && ['gastro', 'genmed'].includes(spec.id);
    }
    if (selectedTag === 'Heart & Vitals') {
      return matchesSearch && ['cardio', 'pulmo'].includes(spec.id);
    }
    if (selectedTag === 'Brain & Neuro') {
      return matchesSearch && ['neuro', 'psych'].includes(spec.id);
    }
    if (selectedTag === 'Bones & Joints') {
      return matchesSearch && ['ortho'].includes(spec.id);
    }
    if (selectedTag === 'Women & Child') {
      return matchesSearch && ['gynae', 'pedia'].includes(spec.id);
    }
    return matchesSearch;
  });

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-teal-700 rounded-3xl p-6 sm:p-8 text-white shadow-lg space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-white border border-white/30 text-xs font-bold backdrop-blur-xs">
          <Stethoscope className="w-3.5 h-3.5 text-blue-200" />
          <span>VERIFIED CLINICAL DEPARTMENTS</span>
        </div>
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Find Specialists by Medical Specialty
          </h1>
          <p className="text-sm text-blue-100 max-w-2xl mt-1 leading-relaxed">
            Browse accredited medical departments, common symptoms, and connect directly with verified senior consultants across OPD and Telehealth.
          </p>
        </div>

        <div className="flex flex-wrap gap-2 pt-1">
          <button
            onClick={() => onNavigate('doctor-discovery')}
            className="px-4 py-2 bg-white text-blue-800 hover:bg-blue-50 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
          >
            <span>View All Doctors & Clinics</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onNavigate('med-sarthi')}
            className="px-4 py-2 bg-white/15 hover:bg-white/25 text-white border border-white/30 rounded-xl text-xs font-bold transition-all backdrop-blur-xs cursor-pointer flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-200" />
            <span>Ask Med Sarthi to Recommend Specialty</span>
          </button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="space-y-4">
        <div className="relative max-w-xl">
          <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search specialties, symptoms (e.g. acid reflux, knee pain, rash, chest tightness)..."
            className="w-full pl-12 pr-4 py-3 text-xs sm:text-sm bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all shadow-xs"
          />
        </div>

        {/* Filter Chips */}
        <div className="flex items-center gap-2 overflow-x-auto hide-scrollbar pb-1">
          {tags.map((tag) => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer transition-all ${
                selectedTag === tag
                  ? 'bg-blue-600 text-white shadow-xs font-bold'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      </div>

      {/* Specialties Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((spec) => {
          const Icon = getSpecialtyIcon(spec.id);
          return (
            <div
              key={spec.id}
              onClick={() => onSelectSpecialty(spec.name)}
              className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:border-blue-300 hover:shadow-xl hover:shadow-blue-500/5 transition-all cursor-pointer flex flex-col justify-between group"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold group-hover:bg-blue-600 group-hover:text-white transition-colors shadow-xs">
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="px-2.5 py-1 bg-slate-100 text-slate-700 text-xs font-bold rounded-lg group-hover:bg-blue-50 group-hover:text-blue-700 transition-colors">
                    {spec.doctorCount} Doctors
                  </span>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                    {spec.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    {spec.description}
                  </p>
                </div>

                {/* Common Symptoms */}
                <div className="space-y-1.5 pt-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Common Symptoms Treated:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {spec.commonSymptoms.map((sym, i) => (
                      <span
                        key={i}
                        className="px-2 py-0.5 bg-slate-50 border border-slate-200 text-slate-600 rounded-md text-[11px] font-medium"
                      >
                        {sym}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-5 mt-5 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-blue-600 group-hover:text-blue-700">
                <span>Explore {spec.name} Specialists</span>
                <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

