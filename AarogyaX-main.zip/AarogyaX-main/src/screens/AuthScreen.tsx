import React, { useState } from 'react';
import {
  Activity,
  User,
  Stethoscope,
  Building2,
  Lock,
  Mail,
  Phone,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  X,
} from 'lucide-react';
import { UserRole, MainView } from '../types';

interface AuthScreenProps {
  onClose?: () => void;
  onLoginSuccess: (role: UserRole) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onClose, onLoginSuccess }) => {
  const [selectedRole, setSelectedRole] = useState<UserRole>('patient');
  const [isSignUp, setIsSignUp] = useState(false);
  const [identifier, setIdentifier] = useState('AX-1029384');
  const [password, setPassword] = useState('••••••••••••');
  const [rememberMe, setRememberMe] = useState(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLoginSuccess(selectedRole);
  };

  return (
    <div className="min-h-screen bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4 z-50 fixed inset-0 font-sans">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 max-w-xl w-full overflow-hidden relative animate-in fade-in zoom-in-95 duration-200">
        {onClose && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Header */}
        <div className="p-8 pb-4 text-center">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex items-center justify-center mx-auto shadow-md shadow-blue-500/20 mb-3">
            <Activity className="w-7 h-7" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">
            {isSignUp ? 'Create your AarogyaX Account' : 'Welcome back to AarogyaX'}
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {isSignUp
              ? 'Join the connected AI healthcare ecosystem'
              : 'Sign in to access your health vault, clinical EHR, or hospital portal'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 pt-2 space-y-6">
          {/* Role Selection */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
              I am a
            </label>
            <div className="grid grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => {
                  setSelectedRole('patient');
                  setIdentifier('AX-1029384');
                }}
                className={`p-3.5 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                  selectedRole === 'patient'
                    ? 'border-blue-600 bg-blue-50/80 text-blue-900 shadow-sm ring-2 ring-blue-500/20 font-bold'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${selectedRole === 'patient' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                  <User className="w-4 h-4" />
                </div>
                <span className="text-xs">Patient</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSelectedRole('doctor');
                  setIdentifier('dr.jenkins@apollo.health');
                }}
                className={`p-3.5 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                  selectedRole === 'doctor'
                    ? 'border-teal-600 bg-teal-50/80 text-teal-900 shadow-sm ring-2 ring-teal-500/20 font-bold'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${selectedRole === 'doctor' ? 'bg-teal-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                  <Stethoscope className="w-4 h-4" />
                </div>
                <span className="text-xs">Doctor</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSelectedRole('hospital');
                  setIdentifier('admin@apollo-bannerghatta.org');
                }}
                className={`p-3.5 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                  selectedRole === 'hospital'
                    ? 'border-indigo-600 bg-indigo-50/80 text-indigo-900 shadow-sm ring-2 ring-indigo-500/20 font-bold'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${selectedRole === 'hospital' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                  <Building2 className="w-4 h-4" />
                </div>
                <span className="text-xs">Hospital</span>
              </button>
            </div>
          </div>

          {/* Form Fields */}
          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                {selectedRole === 'patient'
                  ? 'Medical ID / ABHA Number / Email'
                  : selectedRole === 'doctor'
                  ? 'Doctor License ID / Official Email'
                  : 'Hospital Admin ID / Email'}
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="e.g. AX-1029384 or user@email.com"
                  className="w-full pl-10 pr-4 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-semibold text-slate-700">Password</label>
                {!isSignUp && (
                  <a href="#" className="text-[11px] text-blue-600 hover:underline font-semibold">
                    Forgot password?
                  </a>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-4 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all"
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-600">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500"
                />
                <span>Remember credentials</span>
              </label>
              <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                ABHA 256-bit Secure
              </span>
            </div>
          </div>

          {/* Submit CTA */}
          <button
            type="submit"
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-101 cursor-pointer flex items-center justify-center gap-2"
          >
            <span>
              {isSignUp
                ? `Register as ${selectedRole.charAt(0).toUpperCase() + selectedRole.slice(1)}`
                : `Login to ${selectedRole.charAt(0).toUpperCase() + selectedRole.slice(1)} Portal`}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>

          {/* Toggle login vs signup */}
          <div className="text-center pt-1">
            <button
              type="button"
              onClick={() => setIsSignUp(!isSignUp)}
              className="text-xs text-slate-600 hover:text-blue-600 cursor-pointer"
            >
              {isSignUp ? (
                <>Already have an account? <strong className="text-blue-600">Sign in</strong></>
              ) : (
                <>Don't have an account? <strong className="text-blue-600">Create account</strong></>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
