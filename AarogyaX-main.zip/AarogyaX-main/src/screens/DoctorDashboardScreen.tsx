import React, { useState } from 'react';
import {
  Users,
  Video,
  Clock,
  FileSignature,
  Activity,
  CheckCircle2,
  Calendar,
  AlertCircle,
  Search,
  ChevronRight,
  Stethoscope,
  Building2,
  Sparkles,
} from 'lucide-react';
import { MainView } from '../types';

interface DoctorDashboardScreenProps {
  onNavigate: (view: MainView) => void;
  onSelectPatient: (patientId: string) => void;
}

export const DoctorDashboardScreen: React.FC<DoctorDashboardScreenProps> = ({
  onNavigate,
  onSelectPatient,
}) => {
  const [queueFilter, setQueueFilter] = useState<'all' | 'waiting' | 'completed'>('all');

  const queuePatients = [
    {
      token: '#TK-04',
      id: 'P-101',
      name: 'Rahul Sharma',
      age: 32,
      gender: 'Male',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
      time: '02:30 PM',
      type: 'Video Telehealth',
      complaint: 'Epigastric stomach pain post meals for 3 days',
      status: 'waiting',
      hasPreConsultation: true,
    },
    {
      token: '#TK-05',
      id: 'P-102',
      name: 'Anita Desai',
      age: 45,
      gender: 'Female',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=120&q=80',
      time: '03:15 PM',
      type: 'In-Person OPD',
      complaint: 'Follow-up for chronic GERD and endoscopy review',
      status: 'waiting',
      hasPreConsultation: true,
    },
    {
      token: '#TK-03',
      id: 'P-103',
      name: 'Vikram Singh',
      age: 58,
      gender: 'Male',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80',
      time: '01:45 PM',
      type: 'In-Person OPD',
      complaint: 'Abdominal ultrasound review for fatty liver',
      status: 'completed',
      hasPreConsultation: false,
    },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Doctor Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Dr. Sarah Jenkins — Clinical EHR Dashboard
            </h1>
            <span className="px-2.5 py-0.5 bg-teal-50 text-teal-700 border border-teal-200 text-xs font-bold rounded-md">
              OPD ROOM #304 ACTIVE
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Department of Gastroenterology • Apollo Hospitals, Bannerghatta Hub
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('doctor-rx-builder')}
            className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-500/20 transition-all hover:scale-101 cursor-pointer flex items-center gap-1.5"
          >
            <FileSignature className="w-4 h-4" />
            <span>Generate Digital Rx</span>
          </button>
        </div>
      </div>

      {/* Stats Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] text-slate-500 font-medium">Today's Appointments</p>
            <p className="text-2xl font-extrabold text-slate-900 mt-0.5">8 Patients</p>
            <span className="text-[10px] text-teal-600 font-bold">5 OPD • 3 Video</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
            <Calendar className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] text-slate-500 font-medium">In Waiting Queue</p>
            <p className="text-2xl font-extrabold text-amber-600 mt-0.5">2 Waiting</p>
            <span className="text-[10px] text-slate-500 font-medium">Avg wait: 11 mins</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] text-slate-500 font-medium">Prescriptions Signed</p>
            <p className="text-2xl font-extrabold text-slate-900 mt-0.5">14 Today</p>
            <span className="text-[10px] text-emerald-600 font-bold">100% Digital Signed</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <FileSignature className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] text-slate-500 font-medium">AI Triage Summaries</p>
            <p className="text-2xl font-extrabold text-indigo-600 mt-0.5">100% Ready</p>
            <span className="text-[10px] text-indigo-600 font-bold">Pre-intake verified</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Sparkles className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Patient Queue Workspace */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-7 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Today's Patient Queue</h2>
            <p className="text-xs text-slate-500">Live OPD & Telehealth consultations queue</p>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setQueueFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                queueFilter === 'all' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600'
              }`}
            >
              All (3)
            </button>
            <button
              onClick={() => setQueueFilter('waiting')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                queueFilter === 'waiting' ? 'bg-white text-amber-700 shadow-xs font-bold' : 'text-slate-600'
              }`}
            >
              Waiting (2)
            </button>
            <button
              onClick={() => setQueueFilter('completed')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                queueFilter === 'completed' ? 'bg-white text-emerald-700 shadow-xs font-bold' : 'text-slate-600'
              }`}
            >
              Completed (1)
            </button>
          </div>
        </div>

        {/* Patient Queue Cards List */}
        <div className="space-y-3">
          {queuePatients
            .filter((p) => (queueFilter === 'all' ? true : p.status === queueFilter))
            .map((patient) => (
              <div
                key={patient.id}
                className="p-5 bg-slate-50 hover:bg-white rounded-2xl border border-slate-200 hover:border-teal-300 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 group"
              >
                <div className="flex items-start md:items-center gap-4">
                  <div className="px-3 py-2 bg-teal-100 text-teal-800 rounded-xl text-center font-mono font-extrabold text-xs shrink-0">
                    {patient.token}
                  </div>

                  <img
                    src={patient.avatar}
                    alt={patient.name}
                    className="w-12 h-12 rounded-2xl object-cover ring-2 ring-slate-200"
                  />

                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-sm font-extrabold text-slate-900">{patient.name}</h3>
                      <span className="text-xs text-slate-500 font-medium">
                        {patient.age} Yrs / {patient.gender}
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        patient.type.includes('Video')
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-teal-100 text-teal-800'
                      }`}>
                        {patient.type}
                      </span>
                      {patient.hasPreConsultation && (
                        <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded text-[10px] font-bold flex items-center gap-1">
                          <Sparkles className="w-3 h-3" />
                          AI Intake Ready
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-600 font-medium">
                      <strong className="text-slate-700">Complaint:</strong> {patient.complaint}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end md:self-center">
                  <button
                    onClick={() => {
                      onSelectPatient(patient.id);
                      onNavigate('doctor-patient-view');
                    }}
                    className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                  >
                    View EHR
                  </button>

                  <button
                    onClick={() => {
                      onSelectPatient(patient.id);
                      onNavigate('doctor-consultation');
                    }}
                    className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all hover:scale-101 cursor-pointer flex items-center gap-1.5"
                  >
                    <Stethoscope className="w-4 h-4" />
                    <span>Start Consultation</span>
                  </button>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};
