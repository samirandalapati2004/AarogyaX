import React from 'react';
import {
  Sparkles,
  Calendar,
  Clock,
  Video,
  FileText,
  Pill,
  Syringe,
  Activity,
  Heart,
  Droplet,
  ChevronRight,
  Upload,
  Plus,
  CheckCircle2,
  AlertCircle,
  Stethoscope,
  Building2,
  FolderHeart,
  ArrowUpRight,
  ShieldCheck,
} from 'lucide-react';
import {
  PatientProfile,
  Appointment,
  Medicine,
  MedicalRecord,
  MainView,
} from '../types';

interface HomeScreenProps {
  patient: PatientProfile;
  upcomingAppointment: Appointment;
  medicines: Medicine[];
  recentRecords: MedicalRecord[];
  onNavigate: (view: MainView) => void;
  onOpenEmergency: () => void;
  onOpenUploadDoc: () => void;
  onOpenAddMed: () => void;
  onJoinVideoCall?: () => void;
  onReschedule?: () => void;
  onToggleMed: (id: string) => void;
  onViewRecord?: (record: MedicalRecord) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  patient,
  upcomingAppointment,
  medicines,
  recentRecords,
  onNavigate,
  onOpenEmergency,
  onOpenUploadDoc,
  onOpenAddMed,
  onJoinVideoCall = () => onNavigate('doctor-consultation'),
  onReschedule = () => onNavigate('doctor-discovery'),
  onToggleMed,
  onViewRecord = (_record?: MedicalRecord) => onNavigate('medical-records'),
}) => {
  const healthTimelineEvents = [
    {
      date: 'Today, Oct 24',
      type: 'Upcoming Tele-Consultation',
      detail: 'Dr. Sarah Jenkins — Gastroenterology follow-up for epigastric discomfort',
      status: 'Scheduled',
      icon: Video,
      color: 'bg-blue-600 text-white ring-blue-100',
    },
    {
      date: 'Oct 19, 2023',
      type: 'Digital Prescription Issued',
      detail: 'Pantoprazole 40mg + Pancreatin Enzymes (14-day protocol)',
      status: 'Active Rx',
      icon: FileText,
      color: 'bg-teal-600 text-white ring-teal-100',
    },
    {
      date: 'Oct 18, 2023',
      type: 'Diagnostic Ultrasound Scan',
      detail: 'Upper Abdominal Scan at Apollo Diagnostics (AI Summarized)',
      status: 'Verified',
      icon: Activity,
      color: 'bg-indigo-600 text-white ring-indigo-100',
    },
    {
      date: 'Oct 15, 2023',
      type: 'Comprehensive Lab Report',
      detail: 'Dr. Lal PathLabs: Normal Glucose (98 mg/dL), Total Chol (188 mg/dL)',
      status: 'Normal',
      icon: Droplet,
      color: 'bg-emerald-600 text-white ring-emerald-100',
    },
    {
      date: 'Nov 14, 2022',
      type: 'COVID-19 Booster Vaccination',
      detail: 'Covishield Booster administered at BBMP Health Centre',
      status: 'Completed',
      icon: Syringe,
      color: 'bg-purple-600 text-white ring-purple-100',
    },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8 font-sans">
      {/* Top Greeting & AI Med Sarthi Hero Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Good morning, {patient.name.split(' ')[0]} 👋
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Medical ID: <strong className="text-slate-800 font-mono">{patient.medicalId}</strong> • All systems synchronized & secure
          </p>
        </div>

        {/* Quick Actions Row */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onNavigate('med-sarthi')}
            className="px-4 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-102 cursor-pointer flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-blue-200" />
            <span>Consult Med Sarthi AI</span>
          </button>

          <button
            onClick={onOpenUploadDoc}
            className="px-3.5 py-2.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <Upload className="w-4 h-4 text-slate-500" />
            <span>Upload Document</span>
          </button>

          <button
            onClick={() => onNavigate('specialties')}
            className="px-3.5 py-2.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <Stethoscope className="w-4 h-4 text-blue-600" />
            <span>Find Specialist</span>
          </button>
        </div>
      </div>

      {/* Vitals & Health Overview Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] text-slate-500 font-medium">Blood Pressure</p>
            <p className="text-lg font-extrabold text-slate-900 mt-0.5">{patient.vitals.bloodPressure}</p>
            <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">Optimal</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
            <Heart className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] text-slate-500 font-medium">Heart Rate</p>
            <p className="text-lg font-extrabold text-slate-900 mt-0.5">{patient.vitals.heartRate}</p>
            <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">Resting Normal</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <Activity className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] text-slate-500 font-medium">Fasting Glucose</p>
            <p className="text-lg font-extrabold text-slate-900 mt-0.5">{patient.vitals.glucose}</p>
            <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">Normal</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
            <Droplet className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] text-slate-500 font-medium">Blood Oxygen (SpO2)</p>
            <p className="text-lg font-extrabold text-slate-900 mt-0.5">{patient.vitals.spo2}</p>
            <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">Excellent</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Main Grid: Upcoming Appointment & Medicine Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Upcoming Appointment Card & Recent Medical Records */}
        <div className="lg:col-span-7 space-y-6">
          {/* Upcoming Appointment Card */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-5 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Calendar className="w-5 h-5 text-blue-200" />
                <h3 className="font-bold text-sm tracking-wide">UPCOMING CONSULTATION</h3>
              </div>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-white/20 text-white border border-white/30 backdrop-blur-xs">
                {upcomingAppointment.status}
              </span>
            </div>

            <div className="p-6 space-y-5">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <img
                    src={upcomingAppointment.doctorAvatarUrl}
                    alt={upcomingAppointment.doctorName}
                    className="w-16 h-16 rounded-2xl object-cover ring-2 ring-blue-500/20 shadow-sm"
                  />
                  <div>
                    <h4 className="text-base font-extrabold text-slate-900">
                      {upcomingAppointment.doctorName}
                    </h4>
                    <p className="text-xs font-semibold text-teal-700">
                      {upcomingAppointment.doctorSpecialty}
                    </p>
                    <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                      <Building2 className="w-3.5 h-3.5 text-slate-400" />
                      <span>{upcomingAppointment.doctorHospital}</span>
                    </p>
                  </div>
                </div>

                <div className="bg-blue-50/80 border border-blue-100 p-3 rounded-2xl text-left sm:text-right w-full sm:w-auto">
                  <div className="flex items-center sm:justify-end gap-1.5 text-blue-900 text-xs font-bold">
                    <Clock className="w-4 h-4 text-blue-600" />
                    <span>{upcomingAppointment.date}</span>
                  </div>
                  <p className="text-sm font-extrabold text-blue-700 mt-0.5">{upcomingAppointment.time}</p>
                  <p className="text-[10px] text-slate-500 font-mono">Token #{upcomingAppointment.tokenNumber || 4}</p>
                </div>
              </div>

              {/* Appointment Chief Complaint & Notes */}
              {upcomingAppointment.chiefComplaint && (
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700 space-y-1">
                  <span className="font-bold text-slate-900 uppercase text-[10px] tracking-wider block">
                    Chief Complaint / Clinical Notes:
                  </span>
                  <p>{upcomingAppointment.chiefComplaint}</p>
                </div>
              )}

              {/* CTAs: Join Video Call & Reschedule */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={onJoinVideoCall}
                  className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-101 cursor-pointer flex items-center justify-center gap-2"
                >
                  <Video className="w-4 h-4" />
                  <span>Join Video Consultation</span>
                </button>

                <button
                  onClick={onReschedule}
                  className="px-4 py-3 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer"
                >
                  Reschedule
                </button>
              </div>
            </div>
          </div>

          {/* Recent Medical Records Strip */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">Recent Medical Records</h3>
                <p className="text-xs text-slate-500">Verified diagnostic reports and scans</p>
              </div>
              <button
                onClick={() => onNavigate('medical-records')}
                className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
              >
                <span>View All Records</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {recentRecords.slice(0, 4).map((rec) => (
                <div
                  key={rec.id}
                  onClick={() => onViewRecord(rec)}
                  className="p-4 bg-slate-50/70 hover:bg-blue-50/40 border border-slate-200 hover:border-blue-200 rounded-2xl transition-all cursor-pointer group"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="px-2 py-0.5 bg-white text-slate-700 text-[10px] font-bold rounded-md border border-slate-200">
                      {rec.category}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">{rec.uploadDate}</span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-1">
                    {rec.title}
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">{rec.facility}</p>
                  
                  {rec.isAiSummarized && (
                    <span className="mt-2 inline-flex items-center gap-1 text-[10px] font-bold text-blue-700 bg-blue-100/70 px-2 py-0.5 rounded">
                      <Sparkles className="w-3 h-3 text-blue-600" />
                      AI Summarized
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Medicine Timeline & Health Timeline */}
        <div className="lg:col-span-5 space-y-6">
          {/* Today's Medicine Reminder Timeline */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">Today's Medication Schedule</h3>
                <p className="text-xs text-slate-500">Adherence timeline & instructions</p>
              </div>
              <button
                onClick={onOpenAddMed}
                className="p-1.5 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-lg cursor-pointer transition-colors"
                title="Add Medication"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Medicine Timeline List */}
            <div className="space-y-3">
              {medicines.map((med) => (
                <div
                  key={med.id}
                  className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between ${
                    med.taken
                      ? 'bg-emerald-50/50 border-emerald-200'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => onToggleMed(med.id)}
                      className={`w-6 h-6 rounded-lg flex items-center justify-center transition-colors cursor-pointer ${
                        med.taken
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'border-2 border-slate-300 hover:border-blue-500 bg-white'
                      }`}
                    >
                      {med.taken && <CheckCircle2 className="w-4 h-4" />}
                    </button>

                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className={`text-xs font-bold ${med.taken ? 'text-slate-800 line-through opacity-75' : 'text-slate-900'}`}>
                          {med.name}
                        </h4>
                        <span className="text-[10px] text-slate-500 font-medium">({med.dosage})</span>
                      </div>
                      <p className="text-[11px] text-slate-500">{med.instructions}</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-mono font-bold text-slate-700 block">{med.scheduledTime}</span>
                    <span
                      className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded ${
                        med.taken
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {med.taken ? 'Taken ✓' : 'Upcoming'}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => onNavigate('medicine-reminders')}
              className="w-full py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold transition-colors cursor-pointer text-center"
            >
              Open Full Medication Manager →
            </button>
          </div>

          {/* Health Journey Timeline */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">Health Journey Timeline</h3>
                <p className="text-xs text-slate-500">Chronological clinical milestones</p>
              </div>
            </div>

            <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
              {healthTimelineEvents.map((evt, idx) => {
                const Icon = evt.icon;
                return (
                  <div key={idx} className="relative space-y-1">
                    <div className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full flex items-center justify-center ring-4 ${evt.color}`}>
                      <Icon className="w-3 h-3" />
                    </div>
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-slate-900">{evt.type}</h4>
                      <span className="text-[10px] text-slate-400 font-mono">{evt.date}</span>
                    </div>
                    <p className="text-[11px] text-slate-600 leading-tight">{evt.detail}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
