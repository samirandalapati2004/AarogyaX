import React, { useState } from 'react';
import {
  Building2,
  Users,
  BedDouble,
  Clock,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  TrendingUp,
  Activity,
  Layers,
  ChevronRight,
  BarChart3,
  Calendar,
} from 'lucide-react';
import { MainView } from '../types';

interface HospitalDashboardScreenProps {
  onNavigate: (view: MainView) => void;
}

export const HospitalDashboardScreen: React.FC<HospitalDashboardScreenProps> = ({
  onNavigate,
}) => {
  const [departments, setDepartments] = useState([
    { name: 'Gastroenterology', activeDoctors: 6, queueCount: 18, capacity: '85%' },
    { name: 'Cardiology', activeDoctors: 8, queueCount: 24, capacity: '92%' },
    { name: 'Dermatology', activeDoctors: 4, queueCount: 12, capacity: '60%' },
    { name: 'Orthopedics', activeDoctors: 5, queueCount: 15, capacity: '75%' },
    { name: 'Emergency Care', activeDoctors: 12, queueCount: 8, capacity: '45%' },
  ]);

  const [pendingDoctors, setPendingDoctors] = useState([
    {
      id: 'D-201',
      name: 'Dr. Ramesh Nair',
      specialty: 'Pulmonology',
      qualifications: 'MBBS, MD (Chest)',
      regNumber: 'KMC-77291',
      experience: '12 Years',
      status: 'pending',
    },
  ]);

  const handleApproveDoc = (id: string) => {
    setPendingDoctors(
      pendingDoctors.map((d) => (d.id === id ? { ...d, status: 'approved' } : d))
    );
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Hospital Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Apollo Hospitals — Enterprise Dashboard
            </h1>
            <span className="px-2.5 py-0.5 bg-indigo-50 text-indigo-700 border border-indigo-200 text-xs font-bold rounded-md">
              MAIN HUB
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Real-time OPD patient queues, doctor verification, and hospital facility metrics
          </p>
        </div>

        <button
          onClick={() => onNavigate('hospital-analytics')}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-500/20 transition-all hover:scale-101 cursor-pointer flex items-center gap-1.5 self-start md:self-auto"
        >
          <BarChart3 className="w-4 h-4" />
          <span>View Hospital Analytics</span>
        </button>
      </div>

      {/* Top Hospital Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-medium">Total OPD Patients</p>
            <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-0.5">312</p>
            <span className="text-[10px] text-emerald-600 font-bold">+14% vs yesterday</span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-medium">On-Duty Doctors</p>
            <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-0.5">60</p>
            <span className="text-[10px] text-indigo-600 font-bold">6 Departments</span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center">
            <Activity className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-medium">Bed Occupancy</p>
            <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-0.5">78%</p>
            <span className="text-[10px] text-slate-500">182 / 240 Beds</span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <BedDouble className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-medium">Average OPD Wait</p>
            <p className="text-2xl sm:text-3xl font-extrabold text-emerald-600 mt-0.5">14 Mins</p>
            <span className="text-[10px] text-emerald-600 font-bold">Optimal efficiency</span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Grid: Department Queues & Doctor Credentialing */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Department OPD Queues */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-600" />
              <h2 className="text-base font-bold text-slate-900">Department OPD Queues</h2>
            </div>
            <span className="text-xs text-slate-500">Live Synchronization</span>
          </div>

          <div className="space-y-3">
            {departments.map((dept, i) => (
              <div
                key={i}
                className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between"
              >
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900">{dept.name}</h4>
                  <p className="text-xs text-slate-500">{dept.activeDoctors} Active Physicians</p>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <span className="text-xs sm:text-sm font-extrabold text-indigo-700">
                      {dept.queueCount} in Queue
                    </span>
                    <p className="text-[10px] text-slate-400">Load: {dept.capacity}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Doctor Credentialing Requests */}
        <div className="lg:col-span-5 bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-teal-600" />
              <h2 className="text-base font-bold text-slate-900">Doctor Credentialing</h2>
            </div>
            <span className="px-2 py-0.5 bg-amber-50 text-amber-800 text-[10px] font-bold rounded">
              VERIFICATION GATEWAY
            </span>
          </div>

          <div className="space-y-3">
            {pendingDoctors.map((doc) => (
              <div
                key={doc.id}
                className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs sm:text-sm font-bold text-slate-900">{doc.name}</h4>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        doc.status === 'approved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {doc.status.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-xs text-teal-700 font-semibold">{doc.specialty}</p>
                  <p className="text-xs text-slate-500">{doc.qualifications} • Reg #{doc.regNumber}</p>
                </div>

                {doc.status === 'pending' && (
                  <div className="flex items-center gap-2 pt-1 border-t border-slate-200">
                    <button
                      onClick={() => handleApproveDoc(doc.id)}
                      className="flex-1 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Approve Credentials</span>
                    </button>
                    <button
                      className="px-3 py-1.5 bg-white border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-100 cursor-pointer"
                    >
                      Review
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
