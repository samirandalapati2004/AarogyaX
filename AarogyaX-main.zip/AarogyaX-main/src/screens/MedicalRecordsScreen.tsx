import React, { useState } from 'react';
import {
  FolderHeart,
  Search,
  Upload,
  FileText,
  Activity,
  Droplet,
  ShieldCheck,
  Sparkles,
  Download,
  Share2,
  ChevronRight,
  Filter,
  CheckCircle2,
  Eye,
  Plus,
} from 'lucide-react';
import { MedicalRecord, MainView } from '../types';

interface MedicalRecordsScreenProps {
  records: MedicalRecord[];
  onSelectRecord: (record: MedicalRecord) => void;
  onOpenUpload: () => void;
  onNavigate: (view: MainView) => void;
}

export const MedicalRecordsScreen: React.FC<MedicalRecordsScreenProps> = ({
  records,
  onSelectRecord,
  onOpenUpload,
  onNavigate,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Lab Reports', 'Scans & Imaging', 'Prescriptions', 'Vaccinations', 'Discharge Summaries'];

  const filtered = records.filter((rec) => {
    const matchesCategory = selectedCategory === 'All' || rec.category === selectedCategory;
    const matchesSearch =
      rec.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.facility.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.doctorName?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Medical Records Vault
            </h1>
            <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold rounded-lg flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              ABHA 256-bit Encrypted
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Access, view AI summaries, and share your diagnostic lab reports, MRI scans, and digital prescriptions securely
          </p>
        </div>

        <button
          onClick={onOpenUpload}
          className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-101 cursor-pointer flex items-center gap-2 self-start md:self-auto"
        >
          <Upload className="w-4 h-4" />
          <span>Upload Medical Record</span>
        </button>
      </div>

      {/* Search & Category Tabs */}
      <div className="bg-white rounded-3xl border border-slate-200 p-4 sm:p-5 shadow-xs space-y-4">
        <div className="relative max-w-xl">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search reports by name, diagnostic lab, or doctor..."
            className="w-full pl-10 pr-4 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all"
          />
        </div>

        {/* Categories Bar */}
        <div className="flex items-center gap-2 overflow-x-auto hide-scrollbar pb-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer transition-all ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white shadow-xs font-bold'
                  : 'bg-slate-50 text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Records Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((rec) => (
          <div
            key={rec.id}
            className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:border-blue-300 hover:shadow-xl hover:shadow-blue-500/5 transition-all flex flex-col justify-between group"
          >
            <div className="space-y-4">
              {/* Category & Status Bar */}
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-1 bg-slate-100 text-slate-700 text-[11px] font-bold rounded-lg border border-slate-200">
                  {rec.category}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">{rec.uploadDate}</span>
              </div>

              {/* Title & Facility */}
              <div>
                <h3 className="text-sm sm:text-base font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-1">
                  {rec.title}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">{rec.facility}</p>
                {rec.doctorName && (
                  <p className="text-[11px] text-teal-700 font-medium mt-0.5">Ref: {rec.doctorName}</p>
                )}
              </div>

              {/* AI Key Insights preview */}
              {rec.aiSummary && (
                <div className="p-3 bg-blue-50/70 rounded-2xl border border-blue-100/80 space-y-1">
                  <div className="flex items-center gap-1.5 text-[11px] font-bold text-blue-900">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    <span>AI Key Finding</span>
                  </div>
                  <p className="text-[11px] text-slate-700 leading-snug line-clamp-2">
                    {rec.aiSummary.keyFindings[0]}
                  </p>
                </div>
              )}
            </div>

            {/* CTAs: View Report & AI Breakdown */}
            <div className="pt-5 mt-5 border-t border-slate-100 flex items-center gap-2">
              <button
                onClick={() => {
                  onSelectRecord(rec);
                  onNavigate('report-viewer');
                }}
                className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>AI Insights & View</span>
              </button>

              <button
                onClick={() => alert(`Downloading verified PDF for ${rec.title}...`)}
                className="p-2 bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200 rounded-xl cursor-pointer"
                title="Download PDF"
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
