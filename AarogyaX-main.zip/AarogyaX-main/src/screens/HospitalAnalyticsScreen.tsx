import React from 'react';
import {
  BarChart3,
  TrendingUp,
  Users,
  Activity,
  ArrowLeft,
  Calendar,
  Download,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { MainView } from '../types';

interface HospitalAnalyticsScreenProps {
  onBack: () => void;
  onNavigate: (view: MainView) => void;
}

export const HospitalAnalyticsScreen: React.FC<HospitalAnalyticsScreenProps> = ({
  onBack,
  onNavigate,
}) => {
  const hourlyTraffic = [
    { hour: '08 AM', count: 18, pct: '30%' },
    { hour: '09 AM', count: 48, pct: '80%' },
    { hour: '10 AM', count: 62, pct: '100%' },
    { hour: '11 AM', count: 55, pct: '90%' },
    { hour: '12 PM', count: 32, pct: '50%' },
    { hour: '02 PM', count: 44, pct: '70%' },
    { hour: '03 PM', count: 58, pct: '95%' },
    { hour: '04 PM', count: 40, pct: '65%' },
    { hour: '05 PM', count: 22, pct: '35%' },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-indigo-600 transition-colors cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Hospital Overview</span>
      </button>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Hospital Clinical Analytics & Trends
            </h1>
            <span className="px-2.5 py-0.5 bg-indigo-50 text-indigo-700 border border-indigo-200 text-xs font-bold rounded-md">
              LIVE TELEMETRY
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Departmental patient flow, consultation mode distribution, and turnaround metrics
          </p>
        </div>

        <button
          onClick={() => alert('Exporting complete hospital operations report...')}
          className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Export Analytics PDF</span>
        </button>
      </div>

      {/* Top Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex justify-between items-center text-xs text-slate-500 font-bold uppercase">
            <span>Patient Satisfaction</span>
            <span className="text-emerald-600">★ 4.9 / 5</span>
          </div>
          <p className="text-3xl font-extrabold text-slate-900">98.4%</p>
          <p className="text-xs text-slate-500">Based on 1,420 post-consultation reviews</p>
        </div>

        <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex justify-between items-center text-xs text-slate-500 font-bold uppercase">
            <span>Emergency Response Time</span>
            <span className="text-blue-600">Optimal</span>
          </div>
          <p className="text-3xl font-extrabold text-slate-900">3.2 Mins</p>
          <p className="text-xs text-slate-500">Triage-to-bed allocation speed</p>
        </div>

        <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex justify-between items-center text-xs text-slate-500 font-bold uppercase">
            <span>Telehealth vs OPD</span>
            <span className="text-teal-600">Hybrid</span>
          </div>
          <p className="text-3xl font-extrabold text-slate-900">32% / 68%</p>
          <p className="text-xs text-slate-500">Video consultations vs In-person clinic visits</p>
        </div>
      </div>

      {/* Hourly Footfall Chart */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-base font-bold text-slate-900">Peak OPD Hours & Patient Load</h3>
            <p className="text-xs text-slate-500">Today's hourly patient footfall across departments</p>
          </div>
          <span className="text-xs font-bold text-indigo-600">Peak: 10:00 AM</span>
        </div>

        {/* CSS Bar Chart */}
        <div className="grid grid-cols-9 gap-2 sm:gap-4 items-end h-48 pt-6 pb-2">
          {hourlyTraffic.map((item, idx) => (
            <div key={idx} className="flex flex-col items-center h-full justify-end group">
              <span className="text-[10px] font-bold text-slate-700 opacity-0 group-hover:opacity-100 transition-opacity mb-1 font-mono">
                {item.count}
              </span>
              <div
                className="w-full bg-indigo-100 group-hover:bg-indigo-600 rounded-t-xl transition-all duration-300"
                style={{ height: item.pct }}
              ></div>
              <span className="text-[10px] font-semibold text-slate-500 mt-2 font-mono whitespace-nowrap">
                {item.hour}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
