import React, { useState } from 'react';
import {
  Sparkles,
  Send,
  Mic,
  MicOff,
  Paperclip,
  AlertTriangle,
  Stethoscope,
  Calendar,
  CheckCircle2,
  ChevronRight,
  ShieldCheck,
  PhoneCall,
  User,
  Activity,
  ArrowRight,
} from 'lucide-react';
import { ChatMessage, ReportedSymptom, MainView } from '../types';

interface MedSarthiScreenProps {
  chatMessages: ChatMessage[];
  reportedSymptoms: ReportedSymptom[];
  onSendMessage: (text: string) => void;
  onNavigate: (view: MainView) => void;
  onOpenEmergency: () => void;
}

export const MedSarthiScreen: React.FC<MedSarthiScreenProps> = ({
  chatMessages,
  reportedSymptoms,
  onSendMessage,
  onNavigate,
  onOpenEmergency,
}) => {
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isEmergencyDetected, setIsEmergencyDetected] = useState(false);

  const quickPrompts = [
    'I have stomach pain after eating meals',
    'Experiencing mild headache and dizziness for 2 days',
    'Need follow-up guidance on my blood pressure report',
    'Severe sudden chest tightness and left arm numbness',
  ];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    if (
      inputText.toLowerCase().includes('chest pain') ||
      inputText.toLowerCase().includes('chest tightness') ||
      inputText.toLowerCase().includes('arm numbness') ||
      inputText.toLowerCase().includes('difficulty breathing')
    ) {
      setIsEmergencyDetected(true);
    }

    onSendMessage(inputText);
    setInputText('');
  };

  const handleSelectQuickPrompt = (prompt: string) => {
    if (
      prompt.toLowerCase().includes('chest tightness') ||
      prompt.toLowerCase().includes('arm numbness')
    ) {
      setIsEmergencyDetected(true);
    }
    onSendMessage(prompt);
  };

  const toggleVoice = () => {
    setIsListening(!isListening);
    if (!isListening) {
      setTimeout(() => {
        setInputText('I have a sharp pain in my right stomach that gets worse after meals.');
        setIsListening(false);
      }, 2500);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Med Sarthi Header */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-teal-700 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-white/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-white border border-white/30 text-xs font-bold backdrop-blur-xs">
              <Sparkles className="w-3.5 h-3.5 text-blue-200 animate-pulse" />
              <span>CLINICAL AI TRIAGE ASSISTANT</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight">
              Med Sarthi
            </h1>
            <p className="text-sm sm:text-base text-blue-100 max-w-xl font-medium">
              Your AI healthcare companion. Describe what you're experiencing in plain words — Med Sarthi organizes symptoms and matches you with verified specialists.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-white/10 p-3 rounded-2xl border border-white/20 backdrop-blur-xs">
            <ShieldCheck className="w-6 h-6 text-emerald-300 shrink-0" />
            <div className="text-xs text-blue-100">
              <p className="font-bold text-white">Private & Encrypted</p>
              <p className="text-[11px] text-blue-200">ABHA & HIPAA Compliant Triage</p>
            </div>
          </div>
        </div>
      </div>

      {/* Emergency Alert Banner (when detected or triggered) */}
      {isEmergencyDetected && (
        <div className="p-5 rounded-3xl bg-red-50 border-2 border-red-500 shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-red-500/30">
              <AlertTriangle className="w-7 h-7 animate-bounce" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-red-900">
                Potential High-Risk Symptom Detected
              </h3>
              <p className="text-xs text-red-700 mt-0.5 max-w-xl">
                Symptoms matching cardiovascular distress or acute emergencies require immediate medical evaluation rather than routine scheduling.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={onOpenEmergency}
              className="w-full sm:w-auto px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold shadow-md shadow-red-500/25 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Seek Urgent Emergency Attention (108)</span>
            </button>
            <button
              onClick={() => setIsEmergencyDetected(false)}
              className="px-3 py-2.5 bg-white text-red-700 border border-red-200 rounded-xl text-xs font-semibold hover:bg-red-50 cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Main Grid: Chat Area + Clinical Assessment Summary Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Chat Interface Column (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 shadow-sm flex flex-col h-[650px] overflow-hidden">
          {/* Chat Header */}
          <div className="p-4 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-xs">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-900">Med Sarthi AI Session</h3>
                <p className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  Active Clinical Listener
                </p>
              </div>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">ENCRYPTED_SESSION</span>
          </div>

          {/* Messages Scroll Area */}
          <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
            {chatMessages.map((msg) => {
              const isAi = msg.sender === 'ai';
              return (
                <div
                  key={msg.id}
                  className={`flex items-start gap-3 ${isAi ? 'justify-start' : 'justify-end'}`}
                >
                  {isAi && (
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs mt-1">
                      <Sparkles className="w-4 h-4" />
                    </div>
                  )}

                  <div
                    className={`max-w-[85%] rounded-2xl p-4 text-xs sm:text-sm space-y-2.5 ${
                      isAi
                        ? 'bg-slate-50 text-slate-800 border border-slate-200 shadow-xs'
                        : 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                    }`}
                  >
                    <p className="leading-relaxed font-normal">{msg.text}</p>

                    {msg.bulletPoints && (
                      <ul className="space-y-1.5 pl-4 list-disc text-xs text-slate-700">
                        {msg.bulletPoints.map((bp, i) => (
                          <li key={i} className="font-medium">{bp}</li>
                        ))}
                      </ul>
                    )}

                    <span className={`block text-[9px] font-mono mt-1 ${isAi ? 'text-slate-400' : 'text-blue-200 text-right'}`}>
                      {msg.timestamp}
                    </span>
                  </div>

                  {!isAi && (
                    <div className="w-8 h-8 rounded-xl bg-slate-800 text-white flex items-center justify-center shrink-0 shadow-xs mt-1">
                      <User className="w-4 h-4" />
                    </div>
                  )}
                </div>
              );
            })}

            {isListening && (
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl flex items-center gap-3 text-xs text-blue-700 animate-pulse">
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center">
                  <Mic className="w-3.5 h-3.5 animate-spin" />
                </div>
                <span>Listening to your voice... Speak naturally in English, Hindi, or regional languages</span>
              </div>
            )}
          </div>

          {/* Quick Prompts Carousel */}
          <div className="px-4 py-2 bg-slate-50/50 border-t border-slate-100 flex items-center gap-2 overflow-x-auto hide-scrollbar">
            <span className="text-[10px] font-bold text-slate-400 uppercase shrink-0">Suggestions:</span>
            {quickPrompts.map((qp, idx) => (
              <button
                key={idx}
                onClick={() => handleSelectQuickPrompt(qp)}
                className="px-2.5 py-1 bg-white hover:bg-blue-50 text-slate-600 hover:text-blue-700 border border-slate-200 hover:border-blue-200 rounded-full text-[11px] font-medium whitespace-nowrap cursor-pointer transition-colors shadow-2xs"
              >
                {qp}
              </button>
            ))}
          </div>

          {/* Message Input Bar */}
          <form onSubmit={handleSend} className="p-3 bg-white border-t border-slate-200 flex items-center gap-2">
            <button
              type="button"
              onClick={toggleVoice}
              className={`p-2.5 rounded-xl border transition-colors cursor-pointer ${
                isListening
                  ? 'bg-red-500 text-white border-red-600 animate-pulse'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
              title="Voice Input (Speech-to-Text)"
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            <button
              type="button"
              className="p-2.5 bg-slate-50 text-slate-600 border border-slate-200 hover:bg-slate-100 rounded-xl cursor-pointer"
              title="Attach Lab Report or Image"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Type your symptoms or health queries..."
              className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all placeholder:text-slate-400"
            />

            <button
              type="submit"
              disabled={!inputText.trim()}
              className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-sm shadow-blue-500/25 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <span>Send</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>

        {/* Clinical Assessment Sidebar (5 cols): Symptom Summary Card + Recommendation Card */}
        <div className="lg:col-span-5 space-y-6">
          {/* Symptom Summary Card */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">Symptom Summary Card</h3>
              </div>
              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold rounded">
                STRUCTURED
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Main Complaint</span>
                <p className="font-bold text-slate-900">Epigastric stomach pain post-meals</p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Duration</span>
                  <p className="font-bold text-slate-900 mt-0.5">3 Days</p>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Severity</span>
                  <p className="font-bold text-amber-600 mt-0.5">Moderate (5/10)</p>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Location & Character</span>
                <p className="font-semibold text-slate-800">Upper right quadrant • Burning & cramping sensation</p>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Associated Symptoms</span>
                <p className="text-slate-700">Mild bloating, post-prandial acid reflux sensation</p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[9px] font-bold text-slate-500 uppercase block">Current Meds</span>
                  <span className="font-semibold text-slate-800">Telmisartan 40mg</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[9px] font-bold text-slate-500 uppercase block">Allergies</span>
                  <span className="font-semibold text-red-600">Penicillin (Rash)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Recommendation Card */}
          <div className="bg-gradient-to-br from-blue-50 via-indigo-50/50 to-teal-50 rounded-3xl border border-blue-200 p-6 space-y-4 shadow-sm">
            <div className="flex items-center gap-2">
              <Stethoscope className="w-5 h-5 text-blue-700" />
              <h3 className="text-base font-bold text-blue-950">Recommended Next Step</h3>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-blue-200/80 space-y-2 shadow-xs">
              <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Suggested Specialty</p>
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-lg font-extrabold text-blue-700">Gastroenterology</h4>
                  <p className="text-xs text-slate-600">Upper GI endoscopy & acid reflux evaluation</p>
                </div>
                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-bold rounded-lg">
                  18 Doctors
                </span>
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <button
                onClick={() => onNavigate('doctor-discovery')}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-101 cursor-pointer flex items-center justify-center gap-2"
              >
                <Calendar className="w-4 h-4" />
                <span>View Doctors & Book Consultation</span>
              </button>

              <button
                onClick={() => onNavigate('pre-consultation')}
                className="w-full py-2.5 bg-white hover:bg-slate-50 text-blue-700 border border-blue-200 rounded-xl text-xs font-bold shadow-2xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <span>Fill Pre-Consultation Form First</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Disclaimer */}
            <p className="text-[10px] text-slate-500 text-center italic">
              *Med Sarthi provides clinical triage assistance and does not replace in-person professional physician diagnoses.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
