import React, { useState } from 'react';
import {
  Video,
  Mic,
  MicOff,
  VideoOff,
  PhoneOff,
  Share2,
  FileSignature,
  FileText,
  Sparkles,
  Plus,
  CheckCircle2,
  Stethoscope,
  User,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { MainView } from '../types';

interface DoctorConsultationScreenProps {
  onNavigate: (view: MainView) => void;
  onCompleteConsultation: () => void;
}

export const DoctorConsultationScreen: React.FC<DoctorConsultationScreenProps> = ({
  onNavigate,
  onCompleteConsultation,
}) => {
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [clinicalNotes, setClinicalNotes] = useState(
    'Patient presents with sharp epigastric pain following meals. Denies radiation to back or hematemesis. Vitals stable. Abdomen soft on palpation with localized epigastric tenderness.'
  );
  const [diagnosis, setDiagnosis] = useState('Acute Gastritis with Mild Acid Reflux (K29.70)');
  const [followUpDate, setFollowUpDate] = useState('Nov 07, 2026');

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Consultation Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 text-white p-4 sm:p-5 rounded-3xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-teal-600 flex items-center justify-center font-bold text-sm">
            RS
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold">Rahul Sharma</h2>
              <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold rounded">
                LIVE CALL • 08:24
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">Token #TK-04 • ABHA: AX-1029384</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('doctor-rx-builder')}
            className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <FileSignature className="w-4 h-4" />
            <span>Open Full Rx Builder</span>
          </button>

          <button
            onClick={onCompleteConsultation}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <PhoneOff className="w-4 h-4" />
            <span>End Call & Sign Rx</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Video Telehealth Stage (7 cols) + Clinical Notes & Orders (5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Video Room */}
        <div className="lg:col-span-7 space-y-4">
          <div className="relative bg-slate-950 rounded-3xl overflow-hidden aspect-video shadow-xl flex items-center justify-center border border-slate-800">
            {/* Patient Mock Video feed */}
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80"
              alt="Patient Video"
              className="w-full h-full object-cover opacity-90"
            />

            {/* Doctor Picture-in-Picture */}
            <div className="absolute top-4 right-4 w-32 sm:w-40 aspect-video rounded-2xl overflow-hidden border-2 border-white/40 shadow-2xl bg-slate-800">
              <img
                src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=300&q=80"
                alt="Doctor Feed"
                className="w-full h-full object-cover"
              />
              <span className="absolute bottom-1 left-2 text-[9px] text-white font-bold bg-black/60 px-1 rounded">
                You (Dr. Jenkins)
              </span>
            </div>

            {/* Patient Label Overlay */}
            <div className="absolute bottom-4 left-4 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl text-white text-xs font-semibold flex items-center gap-2 border border-white/10">
              <User className="w-3.5 h-3.5 text-teal-400" />
              <span>Rahul Sharma (ABHA Linked)</span>
            </div>

            {/* Call Controls Bar Overlay */}
            <div className="absolute bottom-4 right-4 flex items-center gap-2 bg-slate-900/80 backdrop-blur-md p-1.5 rounded-2xl border border-white/10">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className={`p-2.5 rounded-xl transition-colors cursor-pointer ${
                  isMuted ? 'bg-red-600 text-white' : 'bg-white/20 text-white hover:bg-white/30'
                }`}
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>

              <button
                onClick={() => setIsVideoOff(!isVideoOff)}
                className={`p-2.5 rounded-xl transition-colors cursor-pointer ${
                  isVideoOff ? 'bg-red-600 text-white' : 'bg-white/20 text-white hover:bg-white/30'
                }`}
                title={isVideoOff ? 'Start Video' : 'Stop Video'}
              >
                {isVideoOff ? <VideoOff className="w-4 h-4" /> : <Video className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: In-Consultation Notes & Orders */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Stethoscope className="w-4 h-4 text-teal-600" />
                <h3 className="text-sm font-bold text-slate-900">Clinical Consultation Notes</h3>
              </div>
              <span className="text-[10px] text-teal-700 bg-teal-50 px-2 py-0.5 rounded font-bold">
                AUTO-SAVING
              </span>
            </div>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-700 uppercase">
                  Provisional Diagnosis
                </label>
                <input
                  type="text"
                  value={diagnosis}
                  onChange={(e) => setDiagnosis(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold text-blue-700 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-700 uppercase">
                  Doctor's Examination & Clinical Findings
                </label>
                <textarea
                  rows={4}
                  value={clinicalNotes}
                  onChange={(e) => setClinicalNotes(e.target.value)}
                  className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20 leading-relaxed text-slate-800"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-700 uppercase">
                  Follow-up Review Schedule
                </label>
                <input
                  type="text"
                  value={followUpDate}
                  onChange={(e) => setFollowUpDate(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white focus:outline-none"
                />
              </div>
            </div>

            <button
              onClick={() => onNavigate('doctor-rx-builder')}
              className="w-full py-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <FileSignature className="w-4 h-4" />
              <span>Proceed to Digital Prescription Builder →</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
