import React, { useState } from 'react';
import {
  FileSignature,
  Pill,
  Plus,
  Trash2,
  CheckCircle2,
  ShieldCheck,
  Building2,
  Calendar,
  Sparkles,
  ArrowLeft,
  Volume2,
} from 'lucide-react';
import { PrescribedMedication, MainView } from '../types';

interface DoctorRxBuilderScreenProps {
  onBack: () => void;
  onNavigate: (view: MainView) => void;
  onPrescriptionIssued: (rxData: any) => void;
}

export const DoctorRxBuilderScreen: React.FC<DoctorRxBuilderScreenProps> = ({
  onBack,
  onNavigate,
  onPrescriptionIssued,
}) => {
  const [medications, setMedications] = useState<PrescribedMedication[]>([
    {
      name: 'Pantoprazole 40mg',
      dosage: '1 tablet (40mg)',
      frequency: '1-0-0',
      timing: 'Before meals (Morning)',
      duration: '14 Days',
      instructions: 'Take 30 minutes before breakfast with full glass of water',
    },
    {
      name: 'Pancreatin Digestive Enzymes',
      dosage: '1 capsule (10,000 units)',
      frequency: '1-0-1',
      timing: 'With meals',
      duration: '14 Days',
      instructions: 'Swallow whole with principal meals',
    },
  ]);

  const [currentMedName, setCurrentMedName] = useState('');
  const [currentDosage, setCurrentDosage] = useState('1 tablet');
  const [currentFreq, setCurrentFreq] = useState('1-0-1');
  const [currentTiming, setCurrentTiming] = useState('After meals');
  const [currentDuration, setCurrentDuration] = useState('7 Days');
  const [currentInstructions, setCurrentInstructions] = useState('');
  const [doctorNotes, setDoctorNotes] = useState(
    'Avoid spicy, fried foods, and carbonated beverages. Eat small, frequent meals. Follow-up in 14 days.'
  );
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);

  const drugSuggestions = [
    'Pantoprazole 40mg (PPI)',
    'Domperidone 10mg (Prokinetic)',
    'Sucralfate Suspension 1g (Mucosal protectant)',
    'Pancreatin Enzymes (Digestive)',
    'Rifaximin 550mg (Antibiotic)',
    'Probiotics Capsule (Gut flora)',
  ];

  const handleAddMed = () => {
    if (!currentMedName.trim()) return;
    setMedications([
      ...medications,
      {
        name: currentMedName,
        dosage: currentDosage,
        frequency: currentFreq,
        timing: currentTiming,
        duration: currentDuration,
        instructions: currentInstructions || 'Take as directed',
      },
    ]);
    setCurrentMedName('');
    setCurrentInstructions('');
  };

  const handleRemoveMed = (index: number) => {
    setMedications(medications.filter((_, i) => i !== index));
  };

  const handleSignAndIssue = () => {
    setIsSuccessModalOpen(true);
    onPrescriptionIssued({
      medications,
      doctorNotes,
      date: 'Today, Oct 24',
      patientName: 'Rahul Sharma',
    });
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6 font-sans">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-teal-600 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Clinical View</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-mono">PATIENT: Rahul Sharma (AX-1029384)</span>
        </div>
      </div>

      {/* Main Prescription Paper Builder */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-xs">
              <FileSignature className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900">Digital Prescription Builder (Rx)</h1>
              <p className="text-xs text-slate-500">Dr. Sarah Jenkins • Apollo Hospitals</p>
            </div>
          </div>
          <span className="px-2.5 py-1 bg-teal-50 text-teal-800 text-xs font-bold rounded-lg border border-teal-200">
            DRAFTING MODE
          </span>
        </div>

        {/* Add Medication Line Item Form */}
        <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
            <Plus className="w-4 h-4 text-teal-600" />
            <span>Add Medication to Prescription</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
            <div className="sm:col-span-6 space-y-1">
              <label className="text-[11px] font-bold text-slate-600">Medicine Name & Formulation</label>
              <input
                type="text"
                value={currentMedName}
                onChange={(e) => setCurrentMedName(e.target.value)}
                placeholder="e.g. Sucralfate Suspension 1g"
                className="w-full p-2.5 text-xs bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
              />
              {/* Quick suggestions */}
              <div className="flex flex-wrap gap-1 pt-1">
                {drugSuggestions.slice(0, 3).map((sug, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setCurrentMedName(sug)}
                    className="px-2 py-0.5 bg-white border border-slate-200 text-slate-600 rounded text-[10px] hover:bg-teal-50 hover:text-teal-700 cursor-pointer"
                  >
                    + {sug.split(' ')[0]}
                  </button>
                ))}
              </div>
            </div>

            <div className="sm:col-span-3 space-y-1">
              <label className="text-[11px] font-bold text-slate-600">Dosage Frequency</label>
              <select
                value={currentFreq}
                onChange={(e) => setCurrentFreq(e.target.value)}
                className="w-full p-2.5 text-xs bg-white border border-slate-300 rounded-xl focus:outline-none cursor-pointer font-mono font-bold"
              >
                <option value="1-0-0">1-0-0 (Morning only)</option>
                <option value="1-0-1">1-0-1 (Morning & Night)</option>
                <option value="1-1-1">1-1-1 (Thrice daily)</option>
                <option value="0-0-1">0-0-1 (Bedtime)</option>
                <option value="SOS">SOS (When needed)</option>
              </select>
            </div>

            <div className="sm:col-span-3 space-y-1">
              <label className="text-[11px] font-bold text-slate-600">Food Timing</label>
              <select
                value={currentTiming}
                onChange={(e) => setCurrentTiming(e.target.value)}
                className="w-full p-2.5 text-xs bg-white border border-slate-300 rounded-xl focus:outline-none cursor-pointer font-medium"
              >
                <option value="Before meals">Before meals</option>
                <option value="After meals">After meals</option>
                <option value="With meals">With meals</option>
                <option value="Empty stomach">Empty stomach</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
            <div className="sm:col-span-4 space-y-1">
              <label className="text-[11px] font-bold text-slate-600">Duration</label>
              <input
                type="text"
                value={currentDuration}
                onChange={(e) => setCurrentDuration(e.target.value)}
                placeholder="e.g. 14 Days"
                className="w-full p-2.5 text-xs bg-white border border-slate-300 rounded-xl focus:outline-none"
              />
            </div>

            <div className="sm:col-span-6 space-y-1">
              <label className="text-[11px] font-bold text-slate-600">Special Instructions</label>
              <input
                type="text"
                value={currentInstructions}
                onChange={(e) => setCurrentInstructions(e.target.value)}
                placeholder="e.g. Drink plenty of water"
                className="w-full p-2.5 text-xs bg-white border border-slate-300 rounded-xl focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <button
                type="button"
                onClick={handleAddMed}
                className="w-full py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-1"
              >
                <Plus className="w-4 h-4" />
                <span>Add Item</span>
              </button>
            </div>
          </div>
        </div>

        {/* Prescribed Items Table */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Active Medications in this Rx ({medications.length})
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100 text-slate-700 text-[10px] font-bold uppercase">
                <tr>
                  <th className="py-2.5 px-3">Medicine</th>
                  <th className="py-2.5 px-3">Frequency</th>
                  <th className="py-2.5 px-3">Timing</th>
                  <th className="py-2.5 px-3">Duration</th>
                  <th className="py-2.5 px-3">Instructions</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {medications.map((med, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    <td className="py-3 px-3 font-bold text-slate-900">{med.name}</td>
                    <td className="py-3 px-3 font-mono font-bold text-teal-700">{med.frequency}</td>
                    <td className="py-3 px-3 text-slate-600">{med.timing}</td>
                    <td className="py-3 px-3 font-semibold text-slate-700">{med.duration}</td>
                    <td className="py-3 px-3 text-slate-500">{med.instructions}</td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => handleRemoveMed(i)}
                        className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg cursor-pointer"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Doctor Advice Textarea */}
        <div className="space-y-1">
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
            Dietary Advice & Clinical Guidance
          </label>
          <textarea
            rows={3}
            value={doctorNotes}
            onChange={(e) => setDoctorNotes(e.target.value)}
            className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20"
          />
        </div>

        {/* Sign CTA */}
        <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Digital Cryptographic Signing Key #DR-JENKINS-8819</span>
          </div>

          <button
            onClick={handleSignAndIssue}
            className="w-full sm:w-auto px-7 py-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-500/20 transition-all hover:scale-101 cursor-pointer flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Sign & Publish Digital Prescription</span>
          </button>
        </div>
      </div>

      {/* Success Modal */}
      {isSuccessModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-200 text-center space-y-5 animate-in fade-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <h3 className="text-xl font-extrabold text-slate-900">Prescription Issued!</h3>
              <p className="text-xs text-slate-500">
                Digital Rx #8819 signed and automatically pushed to Rahul Sharma's health vault and medication reminder schedule.
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                onClick={() => {
                  setIsSuccessModalOpen(false);
                  onNavigate('prescriptions');
                }}
                className="w-full py-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer"
              >
                View Patient Prescription Screen
              </button>
              <button
                onClick={() => {
                  setIsSuccessModalOpen(false);
                  onNavigate('doctor-dashboard');
                }}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
              >
                Return to OPD Queue
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
