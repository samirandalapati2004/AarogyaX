import React from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Building2,
  Stethoscope,
  Lock,
  AlertTriangle,
  History,
  ChevronRight,
} from 'lucide-react';
import { ConsentRequest, MainView } from '../types';

interface ConsentScreenProps {
  consentRequests: ConsentRequest[];
  onApproveConsent: (id: string) => void;
  onDenyConsent: (id: string) => void;
  onRevokeConsent: (id: string) => void;
  onNavigate: (view: MainView) => void;
}

export const ConsentScreen: React.FC<ConsentScreenProps> = ({
  consentRequests,
  onApproveConsent,
  onDenyConsent,
  onRevokeConsent,
  onNavigate,
}) => {
  const pendingRequests = consentRequests.filter((c) => c.status === 'pending');
  const activeGrants = consentRequests.filter((c) => c.status === 'approved');

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6 font-sans">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Consent & Data Privacy Gateway
            </h1>
            <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold rounded-md">
              PATIENT CONTROLLED
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Grant, manage, or revoke access to your encrypted medical records in real time
          </p>
        </div>

        <button
          onClick={() => onNavigate('audit-log')}
          className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 self-start sm:self-auto"
        >
          <History className="w-4 h-4 text-slate-500" />
          <span>View Access Audit Trail</span>
        </button>
      </div>

      {/* Pending Consent Requests Section */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-amber-500" />
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            Pending Access Requests ({pendingRequests.length})
          </h2>
        </div>

        {pendingRequests.length === 0 ? (
          <div className="p-6 bg-slate-50 rounded-3xl border border-slate-200 text-center text-xs text-slate-500">
            No pending record access requests.
          </div>
        ) : (
          pendingRequests.map((req) => (
            <div
              key={req.id}
              className="bg-amber-50/40 rounded-3xl border border-amber-200 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 bg-amber-100 text-amber-800 text-[10px] font-bold rounded uppercase">
                    ACTION REQUIRED
                  </span>
                  <h3 className="text-base font-extrabold text-slate-900">{req.requesterName}</h3>
                </div>
                <p className="text-xs text-slate-600">
                  {req.requesterType === 'doctor' ? 'Clinical Physician' : 'Hospital Department'} • {req.requesterOrg}
                </p>
                <p className="text-xs text-slate-700 pt-1">
                  <strong>Purpose:</strong> {req.purpose}
                </p>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  <span className="text-[10px] text-slate-500 font-bold uppercase">Scope:</span>
                  {req.scope.map((s, i) => (
                    <span key={i} className="px-2 py-0.5 bg-white border border-amber-200 text-amber-900 rounded text-[10px] font-medium">
                      {s}
                    </span>
                  ))}
                  <span className="text-[10px] text-slate-500 ml-2">Expires: {req.expiry}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end md:self-center">
                <button
                  onClick={() => onApproveConsent(req.id)}
                  className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Grant Access</span>
                </button>

                <button
                  onClick={() => onDenyConsent(req.id)}
                  className="px-4 py-2.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  Deny
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Active Consent Grants Section */}
      <div className="space-y-4 pt-4">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            Active Data Sharing Authorizations ({activeGrants.length})
          </h2>
        </div>

        <div className="space-y-3">
          {activeGrants.map((grant) => (
            <div
              key={grant.id}
              className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-extrabold text-slate-900">{grant.requesterName}</h3>
                  <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold rounded">
                    ACTIVE GRANT
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  {grant.requesterOrg} • Granted on: {grant.requestedDate}
                </p>
                <p className="text-xs text-slate-600">
                  <strong>Scope:</strong> {grant.scope.join(', ')} (Valid until: {grant.expiry})
                </p>
              </div>

              <div className="self-end md:self-center">
                <button
                  onClick={() => onRevokeConsent(grant.id)}
                  className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <XCircle className="w-4 h-4 text-red-600" />
                  <span>Revoke Immediately</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
