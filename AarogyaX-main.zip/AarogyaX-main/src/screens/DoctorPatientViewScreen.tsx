import React from 'react';
import {
  User,
  Heart,
  Activity,
  Droplet,
  FileText,
  Sparkles,
  AlertTriangle,
  FolderHeart,
  ArrowLeft,
  Stethoscope,
  FileSignature,
  Building2,
  Calendar,
  ShieldCheck,
  Plus,
} from 'lucide-react';
import { PatientProfile, MedicalRecord, MainView } from '../types';

interface DoctorPatientViewScreenProps {
  patient: PatientProfile;
  records: MedicalRecord[];
  onNavigate: (view: MainView) => void;
  onBack: () => void;
}

export const DoctorPatientViewScreen: React.FC<DoctorPatientViewScreenProps> = ({
  patient,
  records,
  onNavigate,
  onBack,
}) => {
  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Back Button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-teal-600 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Today's Queue</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('doctor-rx-builder')}
            className="px-4 py-2 bg-white hover:bg-slate-50 text-teal-800 border border-teal-300 rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <FileSignature className="w-4 h-4 text-teal-600" />
            <span>Draft Rx</span>
          </button>

          <button
            onClick={() => onNavigate('doctor-consultation')}
            className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-500/20 transition-all hover:scale-101 cursor-pointer flex items-center gap-1.5"
          >
            <Stethoscope className="w-4 h-4" />
            <span>Launch Consultation Room</span>
          </button>
        </div>
      </div>

      {/* Patient Header Banner */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <img
              src={patient.avatarUrl}
              alt={patient.name}
              className="w-16 h-16 rounded-2xl object-cover ring-2 ring-teal-500/20 shadow-xs"
            />
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-extrabold text-slate-900">{patient.name}</h1>
                <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-md border border-emerald-200">
                  Consent Granted ✓
                </span>
              </div>
              <p className="text-xs text-slate-500 font-mono">
                ABHA: <strong className="text-slate-800">{patient.medicalId}</strong> • {patient.age} Yrs / {patient.gender} • Blood Group: <strong className="text-slate-900">{patient.bloodGroup}</strong>
              </p>
            </div>
          </div>

          {/* Critical Allergy Pill */}
          <div className="p-3 bg-red-50 rounded-2xl border border-red-200 flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-red-600 shrink-0" />
            <div className="text-xs">
              <p className="font-extrabold text-red-900">ALLERGY ALERT</p>
              <p className="text-red-700 font-semibold">{patient.allergies.join(', ')}</p>
            </div>
          </div>
        </div>

        {/* Vitals Summary Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-100">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Blood Pressure</span>
            <span className="text-sm font-extrabold text-slate-900">{patient.vitals.bloodPressure}</span>
          </div>
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Heart Rate</span>
            <span className="text-sm font-extrabold text-slate-900">{patient.vitals.heartRate}</span>
          </div>
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Fasting Glucose</span>
            <span className="text-sm font-extrabold text-slate-900">{patient.vitals.glucose}</span>
          </div>
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">SpO2</span>
            <span className="text-sm font-extrabold text-emerald-600">{patient.vitals.spo2}</span>
          </div>
        </div>
      </div>

      {/* Main Grid: AI Clinical Intake Summary + Linked Records */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): AI Pre-Consultation Summary */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-gradient-to-br from-teal-50/70 via-blue-50/50 to-white rounded-3xl border border-teal-200 p-6 sm:p-7 shadow-xs space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-teal-200/70">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-teal-700" />
                <h3 className="text-base font-bold text-teal-950">Med Sarthi AI Clinical Intake Summary</h3>
              </div>
              <span className="px-2 py-0.5 bg-teal-100 text-teal-800 text-[10px] font-bold rounded">
                AUTONOMOUS TRIAGE
              </span>
            </div>

            <div className="space-y-3 text-xs text-slate-700">
              <div className="p-3.5 bg-white rounded-2xl border border-teal-100 space-y-1 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-400 uppercase">Chief Complaint</span>
                <p className="font-extrabold text-slate-900 text-sm">
                  Epigastric stomach pain post meals for 3 days with burning sensation & mild acid regurgitation.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-white rounded-2xl border border-teal-100 shadow-2xs">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Reported Timeline</span>
                  <p className="font-bold text-slate-900 mt-0.5">3-5 Days (Severity: 5/10)</p>
                </div>
                <div className="p-3 bg-white rounded-2xl border border-teal-100 shadow-2xs">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Active Medications</span>
                  <p className="font-bold text-slate-900 mt-0.5">Telmisartan 40mg daily</p>
                </div>
              </div>

              <div className="p-3.5 bg-white rounded-2xl border border-teal-100 space-y-1 shadow-2xs">
                <span className="text-[10px] font-bold text-slate-400 uppercase">AI Differential Diagnosis Note</span>
                <p className="text-slate-700 leading-relaxed font-normal">
                  Symptom cluster consistent with Acute Gastritis / GERD. Recommended clinical exam to rule out peptic ulcer disease or biliary colic.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Linked Verified Records */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <FolderHeart className="w-5 h-5 text-blue-600" />
                <h3 className="text-sm font-bold text-slate-900">Linked Diagnostic Reports</h3>
              </div>
              <span className="text-xs font-bold text-blue-600">{records.length} Verified</span>
            </div>

            <div className="space-y-3">
              {records.slice(0, 3).map((rec) => (
                <div
                  key={rec.id}
                  onClick={() => onNavigate('report-viewer')}
                  className="p-3.5 bg-slate-50 hover:bg-teal-50/40 rounded-2xl border border-slate-200 hover:border-teal-200 transition-all cursor-pointer group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-slate-500">{rec.category}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{rec.uploadDate}</span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 group-hover:text-teal-700 transition-colors mt-1">
                    {rec.title}
                  </h4>
                  <p className="text-[11px] text-slate-500">{rec.facility}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
