import React, { useState } from 'react';
import {
  ClipboardList,
  CheckCircle2,
  ChevronRight,
  ArrowLeft,
  Upload,
  Sparkles,
  ShieldCheck,
  AlertCircle,
  FileText,
  Activity,
} from 'lucide-react';
import { MainView } from '../types';

interface PreConsultationScreenProps {
  onComplete: () => void;
  onNavigate: (view: MainView) => void;
}

export const PreConsultationScreen: React.FC<PreConsultationScreenProps> = ({
  onComplete,
  onNavigate,
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [complaint, setComplaint] = useState('Epigastric stomach pain post meals and occasional acid regurgitation');
  const [duration, setDuration] = useState('3-5 days');
  const [severity, setSeverity] = useState(5);
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>(['Acid Reflux', 'Bloating', 'Burning Sensation']);
  const [currentMeds, setCurrentMeds] = useState('Telmisartan 40mg (Daily for BP)');
  const [allergies, setAllergies] = useState('Penicillin (Skin Rash)');
  const [lifestyleNotes, setLifestyleNotes] = useState('Moderate coffee intake (2 cups/day), desk job');
  const [consentGranted, setConsentGranted] = useState(true);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const symptomOptions = [
    'Acid Reflux',
    'Bloating',
    'Burning Sensation',
    'Nausea',
    'Loss of Appetite',
    'Dizziness',
    'Fatigue',
    'Constipation',
    'Headache',
  ];

  const toggleSymptom = (sym: string) => {
    if (selectedSymptoms.includes(sym)) {
      setSelectedSymptoms(selectedSymptoms.filter((s) => s !== sym));
    } else {
      setSelectedSymptoms([...selectedSymptoms, sym]);
    }
  };

  const handleNext = () => {
    if (currentStep < 4) setCurrentStep(currentStep + 1);
    else setIsSubmitted(true);
  };

  const handleBack = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto space-y-6 font-sans">
      {/* Header */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200 text-xs font-bold">
          <ClipboardList className="w-3.5 h-3.5 text-blue-600" />
          <span>STRUCTURED CLINICAL INTAKE</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Pre-Consultation Clinical Intake
        </h1>
        <p className="text-xs sm:text-sm text-slate-500">
          Answer a few quick questions to prepare Dr. Sarah Jenkins with structured clinical context before your call.
        </p>
      </div>

      {/* Stepper Bar */}
      <div className="bg-white p-4 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-slate-700">
          <span>Step {currentStep} of 4: {
            currentStep === 1 ? 'Chief Complaint & Symptoms' :
            currentStep === 2 ? 'Severity & Timeline' :
            currentStep === 3 ? 'Current Medications & Allergies' :
            'Summary & Consent Authorization'
          }</span>
          <span className="text-blue-600 font-mono">{currentStep * 25}%</span>
        </div>
        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
          <div
            className="bg-blue-600 h-full rounded-full transition-all duration-300"
            style={{ width: `${currentStep * 25}%` }}
          ></div>
        </div>
      </div>

      {/* Main Step Form Card */}
      {!isSubmitted ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
          {currentStep === 1 && (
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                  Describe what you are currently experiencing
                </label>
                <textarea
                  rows={3}
                  value={complaint}
                  onChange={(e) => setComplaint(e.target.value)}
                  placeholder="e.g. Upper stomach burn after eating fried food or lying down..."
                  className="w-full p-4 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-2xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                  Select Associated Symptoms
                </label>
                <div className="flex flex-wrap gap-2">
                  {symptomOptions.map((sym) => {
                    const isSelected = selectedSymptoms.includes(sym);
                    return (
                      <button
                        key={sym}
                        type="button"
                        onClick={() => toggleSymptom(sym)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-blue-600 text-white shadow-xs font-bold'
                            : 'bg-slate-50 text-slate-700 border border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {sym} {isSelected ? '✓' : '+'}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Symptom Severity (Pain Scale 1 - 10)
                  </label>
                  <span className={`text-xs font-extrabold px-2.5 py-1 rounded-lg ${
                    severity <= 3 ? 'bg-emerald-100 text-emerald-800' :
                    severity <= 6 ? 'bg-amber-100 text-amber-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {severity} / 10 ({severity <= 3 ? 'Mild' : severity <= 6 ? 'Moderate' : 'Severe'})
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={severity}
                  onChange={(e) => setSeverity(parseInt(e.target.value))}
                  className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-medium">
                  <span>1 - Barely noticeable</span>
                  <span>5 - Moderate discomfort</span>
                  <span>10 - Unbearable</span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                  How long has this symptom been present?
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {['Less than 24 hrs', '1-3 days', '3-5 days', 'More than 2 weeks'].map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setDuration(d)}
                      className={`p-3 rounded-2xl border text-xs font-semibold text-center transition-all cursor-pointer ${
                        duration === d
                          ? 'border-blue-600 bg-blue-50 text-blue-800 font-bold shadow-xs'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                  Current Medications & Dosages
                </label>
                <input
                  type="text"
                  value={currentMeds}
                  onChange={(e) => setCurrentMeds(e.target.value)}
                  placeholder="e.g. Telmisartan 40mg, Metformin 500mg, Multivitamins..."
                  className="w-full p-3.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                  Known Drug or Food Allergies
                </label>
                <input
                  type="text"
                  value={allergies}
                  onChange={(e) => setAllergies(e.target.value)}
                  placeholder="e.g. Penicillin, Sulfa drugs, Peanuts, Latex..."
                  className="w-full p-3.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all text-red-700 font-semibold"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                  Lifestyle / Diet Notes
                </label>
                <input
                  type="text"
                  value={lifestyleNotes}
                  onChange={(e) => setLifestyleNotes(e.target.value)}
                  placeholder="e.g. Vegetarian diet, high stress, regular alcohol/smoking..."
                  className="w-full p-3.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all"
                />
              </div>
            </div>
          )}

          {currentStep === 4 && (
            <div className="space-y-6">
              {/* Summary Preview Box */}
              <div className="p-5 bg-gradient-to-br from-blue-50 to-indigo-50/50 rounded-2xl border border-blue-200 space-y-3">
                <div className="flex items-center gap-2 text-blue-900 font-bold text-sm">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  <span>AI Pre-Consultation Summary Ready for Physician</span>
                </div>
                <div className="text-xs text-slate-700 space-y-1.5 pl-2 border-l-2 border-blue-500">
                  <p><strong>Complaint:</strong> {complaint}</p>
                  <p><strong>Timeline:</strong> {duration} (Severity: {severity}/10)</p>
                  <p><strong>Symptoms:</strong> {selectedSymptoms.join(', ')}</p>
                  <p><strong>Meds & Allergies:</strong> {currentMeds} • <span className="text-red-600">{allergies}</span></p>
                </div>
              </div>

              {/* Consent check */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-start gap-3">
                <input
                  type="checkbox"
                  id="consentCheck"
                  checked={consentGranted}
                  onChange={(e) => setConsentGranted(e.target.checked)}
                  className="w-4 h-4 mt-0.5 rounded text-blue-600 border-slate-300 focus:ring-blue-500"
                />
                <label htmlFor="consentCheck" className="text-xs text-slate-700 cursor-pointer">
                  <strong className="text-slate-900">Authorize Clinical EHR Pre-Review:</strong> I authorize Dr. Sarah Jenkins (Apollo Hospitals) to review this intake summary and my linked ABHA medical records for this consultation.
                </label>
              </div>
            </div>
          )}

          {/* Stepper Navigation Buttons */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            {currentStep > 1 ? (
              <button
                type="button"
                onClick={handleBack}
                className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Previous Step</span>
              </button>
            ) : <div />}

            <button
              type="button"
              onClick={handleNext}
              disabled={currentStep === 4 && !consentGranted}
              className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-101 cursor-pointer flex items-center gap-2"
            >
              <span>{currentStep === 4 ? 'Submit to Doctor EHR' : 'Continue'}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        /* Submission Success Card */
        <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-10 shadow-lg text-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl font-extrabold text-slate-900">
              Pre-Consultation Summary Synchronized!
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto">
              Your structured symptom profile has been securely sent to Dr. Sarah Jenkins' clinical dashboard.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={() => onNavigate('patient-dashboard')}
              className="w-full sm:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer"
            >
              Return to Patient Dashboard
            </button>
            <button
              onClick={() => onNavigate('doctor-patient-view')}
              className="w-full sm:w-auto px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-colors cursor-pointer"
            >
              Preview Doctor's EHR View
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
