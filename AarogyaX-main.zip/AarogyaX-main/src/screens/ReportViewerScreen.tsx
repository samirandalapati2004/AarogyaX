import React, { useState } from 'react';
import {
  ArrowLeft,
  Sparkles,
  Download,
  Share2,
  Volume2,
  VolumeX,
  CheckCircle2,
  AlertTriangle,
  Building2,
  Calendar,
  FileText,
  ShieldCheck,
  Stethoscope,
  Activity,
} from 'lucide-react';
import { MedicalRecord, MainView } from '../types';

interface ReportViewerScreenProps {
  record: MedicalRecord;
  onBack: () => void;
  onNavigate: (view: MainView) => void;
}

export const ReportViewerScreen: React.FC<ReportViewerScreenProps> = ({
  record,
  onBack,
  onNavigate,
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const toggleAudio = () => {
    setIsPlayingAudio(!isPlayingAudio);
    if (!isPlayingAudio) {
      setTimeout(() => setIsPlayingAudio(false), 5000);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-blue-600 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Medical Records</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleAudio}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              isPlayingAudio
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 hover:bg-slate-50 text-slate-700'
            }`}
          >
            {isPlayingAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-blue-600" />}
            <span>{isPlayingAudio ? 'Speaking Summary...' : 'Listen Audio Summary'}</span>
          </button>

          <button
            onClick={() => alert(`Downloading verified PDF for ${record.title}...`)}
            className="px-3.5 py-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Download PDF</span>
          </button>
        </div>
      </div>

      {/* Split Screen Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Document Raw Content & Patient Header */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6">
            {/* Report Header */}
            <div className="border-b border-slate-200 pb-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-1 bg-blue-50 text-blue-700 font-bold text-xs rounded-lg border border-blue-200">
                  {record.category}
                </span>
                <span className="text-xs text-slate-400 font-mono">REPORT ID: {record.id}</span>
              </div>

              <div>
                <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">{record.title}</h1>
                <p className="text-xs text-slate-500 mt-1 flex items-center gap-2">
                  <Building2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>{record.facility}</span>
                  <span>•</span>
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>{record.uploadDate}</span>
                </p>
              </div>
            </div>

            {/* Biomarker Parameters Table */}
            {record.aiSummary && record.aiSummary.biomarkers.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Extracted Lab Parameters & Diagnostic Markers
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 text-slate-500 text-[10px] font-bold uppercase border-y border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3">Test Parameter</th>
                        <th className="py-2.5 px-3">Observed Value</th>
                        <th className="py-2.5 px-3">Reference Range</th>
                        <th className="py-2.5 px-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {record.aiSummary.biomarkers.map((bio, i) => (
                        <tr key={i} className="hover:bg-slate-50/50">
                          <td className="py-3 px-3 font-semibold text-slate-900">{bio.name}</td>
                          <td className="py-3 px-3 font-bold text-slate-800">{bio.value}</td>
                          <td className="py-3 px-3 text-slate-500">{bio.referenceRange}</td>
                          <td className="py-3 px-3">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                bio.status === 'normal'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {bio.status.toUpperCase()}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Document Digital Verification Footer */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between text-xs text-slate-500">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Digitally Signed by Lab Pathologist</span>
              </div>
              <span className="font-mono text-[10px]">SHA-256 VERIFIED</span>
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): AI Insights Breakdown Panel */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-gradient-to-br from-blue-50 via-indigo-50/40 to-teal-50 rounded-3xl border border-blue-200 p-6 sm:p-7 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-blue-200/70">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-blue-950">Med Sarthi AI Insights</h3>
                  <p className="text-[10px] text-blue-700 font-medium">Plain-English Clinical Breakdown</p>
                </div>
              </div>
            </div>

            {record.aiSummary && (
              <div className="space-y-4 text-xs">
                {/* Plain English Summary */}
                <div className="p-4 bg-white rounded-2xl border border-blue-100 shadow-2xs space-y-1.5">
                  <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                    Executive Clinical Summary
                  </h4>
                  <p className="text-slate-700 leading-relaxed font-normal">
                    {record.aiSummary.summary}
                  </p>
                </div>

                {/* Key Findings list */}
                <div className="p-4 bg-white rounded-2xl border border-blue-100 shadow-2xs space-y-2">
                  <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                    Key Findings
                  </h4>
                  <ul className="space-y-2 pl-4 list-disc text-slate-700">
                    {record.aiSummary.keyFindings.map((finding, idx) => (
                      <li key={idx} className="leading-snug">{finding}</li>
                    ))}
                  </ul>
                </div>

                {/* Recommendations */}
                <div className="p-4 bg-white rounded-2xl border border-blue-100 shadow-2xs space-y-2">
                  <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                    Recommended Next Steps
                  </h4>
                  <p className="text-slate-700 leading-snug">
                    {record.aiSummary.recommendations}
                  </p>
                </div>
              </div>
            )}

            {/* Consult Doctor CTA */}
            <button
              onClick={() => onNavigate('doctor-discovery')}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-101 cursor-pointer flex items-center justify-center gap-2"
            >
              <Stethoscope className="w-4 h-4" />
              <span>Discuss This Report with a Specialist</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
