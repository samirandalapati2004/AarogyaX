import React, { useState } from 'react';
import { Doctor } from '../types';

interface ScheduleScreenProps {
  doctors: Doctor[];
  onSelectDoctor: (doctor: Doctor) => void;
}

export const ScheduleScreen: React.FC<ScheduleScreenProps> = ({ doctors, onSelectDoctor }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'today' | 'distance' | 'fee' | 'all'>('today');

  const filteredDoctors = doctors.filter((doc) => {
    const matchesSearch =
      doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.hospital.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.specialty.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (activeFilter === 'today') {
      return doc.nextSlot.toLowerCase().includes('today');
    }
    if (activeFilter === 'distance') {
      return doc.distanceKm < 3.0;
    }
    return true;
  });

  return (
    <main className="max-w-7xl mx-auto px-4 md:px-8 py-6 space-y-6">
      {/* Header & Step Flow Indicator */}
      <section className="border-b border-[#141414] pb-4 flex flex-col md:flex-row justify-between items-start md:items-end gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="tech-tag bg-white">SCHEDULE_ENGINE</span>
            <span className="font-mono-tech text-[11px] text-[#5A5A58]">CLINIC_DIRECTORY // V2</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-[#141414] uppercase">
            Specialist Selection
          </h1>
        </div>

        {/* Technical Step Indicator */}
        <div className="flex items-center gap-1 font-mono-tech text-[10px] uppercase overflow-x-auto hide-scrollbar w-full md:w-auto">
          <span className="px-2 py-1 bg-white border border-[#141414] text-[#5A5A58]">01_SYMPTOMS</span>
          <span className="text-[#141414]">&gt;</span>
          <span className="px-2 py-1 bg-white border border-[#141414] text-[#5A5A58]">02_SPECIALITY</span>
          <span className="text-[#141414]">&gt;</span>
          <span className="px-2 py-1 bg-[#141414] text-white border border-[#141414] font-bold">03_SELECTION</span>
          <span className="text-[#141414]">&gt;</span>
          <span className="px-2 py-1 bg-[#F0EFED] border border-[#141414]/30 text-[#5A5A58]">04_BOOKING</span>
        </div>
      </section>

      {/* AI Recommendation Card */}
      <section className="bg-white border border-[#141414] p-5 flex flex-col sm:flex-row items-start gap-4">
        <div className="w-10 h-10 border border-[#141414] bg-[#2A5CFF] text-white flex items-center justify-center shrink-0 font-mono-tech font-bold text-xs">
          AI
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h2 className="text-sm md:text-base font-bold text-[#141414] uppercase tracking-tight">Med Sarthi Triage Recommendation</h2>
            <span className="tech-tag-accent">RECOMMENDED</span>
          </div>
          <p className="text-xs text-[#5A5A58] mb-3 leading-relaxed">
            Based on your reported epigastric pain and digestive discomfort, verified clinical models prioritize consultations with specialists in:
          </p>
          <div className="inline-flex items-center gap-2 bg-[#F0EFED] border border-[#141414] px-3 py-1.5 font-mono-tech text-xs font-bold text-[#141414]">
            <span className="material-symbols-outlined text-[#2A5CFF] text-base">medical_services</span>
            <span>GASTROENTEROLOGY & HEPATOLOGY</span>
          </div>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="space-y-3">
        <div className="relative w-full max-w-2xl">
          <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-[#5A5A58] text-lg">
            search
          </span>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search verified physicians, hospital affiliations, or sub-specialties..."
            className="w-full h-11 pl-10 pr-4 bg-white border border-[#141414] text-xs font-mono-tech text-[#141414] focus:outline-none focus:ring-2 focus:ring-[#2A5CFF] shadow-[2px_2px_0px_#141414]"
          />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1 hide-scrollbar">
          <button
            onClick={() => setActiveFilter('today')}
            className={`px-3 py-1.5 border font-mono-tech text-xs uppercase tracking-wider cursor-pointer transition-colors ${
              activeFilter === 'today'
                ? 'bg-[#141414] text-white border-[#141414] font-bold'
                : 'bg-white text-[#141414] border-[#141414] hover:bg-[#F0EFED]'
            }`}
          >
            [01] Availability Today
          </button>

          <button
            onClick={() => setActiveFilter('distance')}
            className={`px-3 py-1.5 border font-mono-tech text-xs uppercase tracking-wider cursor-pointer transition-colors ${
              activeFilter === 'distance'
                ? 'bg-[#141414] text-white border-[#141414] font-bold'
                : 'bg-white text-[#141414] border-[#141414] hover:bg-[#F0EFED]'
            }`}
          >
            [02] Distance &lt; 5km
          </button>

          <button
            onClick={() => setActiveFilter('fee')}
            className={`px-3 py-1.5 border font-mono-tech text-xs uppercase tracking-wider cursor-pointer transition-colors ${
              activeFilter === 'fee'
                ? 'bg-[#141414] text-white border-[#141414] font-bold'
                : 'bg-white text-[#141414] border-[#141414] hover:bg-[#F0EFED]'
            }`}
          >
            [03] Fee: Low to High
          </button>

          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 border font-mono-tech text-xs uppercase tracking-wider cursor-pointer transition-colors ${
              activeFilter === 'all'
                ? 'bg-[#141414] text-white border-[#141414] font-bold'
                : 'bg-white text-[#141414] border-[#141414] hover:bg-[#F0EFED]'
            }`}
          >
            [04] All Physicians
          </button>
        </div>
      </section>

      {/* Doctor Cards Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredDoctors.map((doc) => {
          const isFastest = !!doc.badge;
          return (
            <div
              key={doc.id}
              className="bg-white border border-[#141414] p-5 flex flex-col justify-between hover:shadow-[4px_4px_0px_#141414] transition-all group"
            >
              <div>
                <div className="flex justify-between items-start gap-2 mb-3">
                  <span className="tech-tag bg-[#F0EFED] font-mono-tech text-[9px]">{doc.id.toUpperCase()}</span>
                  {isFastest ? (
                    <span className="tech-tag-solid text-[9px]">{doc.badge}</span>
                  ) : (
                    <span className="tech-tag bg-white text-[9px] text-[#141414]">★ {doc.rating} RATING</span>
                  )}
                </div>

                <div className="flex items-start gap-3.5 mb-4">
                  <div className="w-14 h-14 border border-[#141414] bg-[#F0EFED] overflow-hidden shrink-0">
                    <img
                      className="w-full h-full object-cover grayscale contrast-125 group-hover:grayscale-0 transition-all"
                      alt={doc.name}
                      src={doc.avatarUrl}
                    />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-[#141414] uppercase tracking-tight">
                      {doc.name}
                    </h3>
                    <p className="font-mono-tech text-xs text-[#2A5CFF] font-bold mt-0.5">{doc.title}</p>
                    <p className="font-mono-tech text-[11px] text-[#5A5A58]">{doc.experienceYears}+ YRS EXPERIENCE</p>
                  </div>
                </div>

                <div className="space-y-1.5 py-3 border-y border-[#141414]/15 font-mono-tech text-xs text-[#5A5A58] mb-4">
                  <div className="flex justify-between">
                    <span>HOSPITAL:</span>
                    <span className="font-bold text-[#141414] text-right">{doc.hospital}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>DISTANCE:</span>
                    <span className="text-[#141414]">{doc.distanceKm} km</span>
                  </div>
                  <div className="flex justify-between">
                    <span>CONSULTATION:</span>
                    <span className="font-bold text-[#141414]">${doc.consultationFee}</span>
                  </div>
                </div>
              </div>

              <div>
                <div className="bg-[#F0EFED] p-2.5 border border-[#141414]/20 mb-3 flex items-center justify-between font-mono-tech text-xs">
                  <span className="text-[#5A5A58] uppercase">Next Available:</span>
                  <span className="font-bold text-[#2A5CFF]">{doc.nextSlot}</span>
                </div>

                <button
                  onClick={() => onSelectDoctor(doc)}
                  className="w-full py-2.5 bg-[#141414] hover:bg-[#2A5CFF] text-white border border-[#141414] font-mono-tech text-xs font-bold transition-colors cursor-pointer uppercase tracking-wider shadow-[2px_2px_0px_#141414] active:translate-x-0.5 active:translate-y-0.5"
                >
                  Book Appointment &gt;
                </button>
              </div>
            </div>
          );
        })}
      </section>
    </main>
  );
};
