import React from 'react';
import {
  History,
  ShieldCheck,
  ArrowLeft,
  Calendar,
  Lock,
  Download,
} from 'lucide-react';
import { AuditLogEntry, MainView } from '../types';

interface AuditLogScreenProps {
  auditLogs: AuditLogEntry[];
  onBack: () => void;
  onNavigate: (view: MainView) => void;
}

export const AuditLogScreen: React.FC<AuditLogScreenProps> = ({
  auditLogs,
  onBack,
  onNavigate,
}) => {
  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6 font-sans">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-blue-600 transition-colors cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Consent Management</span>
      </button>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Security & Access Audit Trail
            </h1>
            <span className="px-2.5 py-0.5 bg-blue-50 text-blue-700 border border-blue-200 text-xs font-bold rounded-md">
              IMMUTABLE LEDGER
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Real-time chronological record of every practitioner or institution that accessed or modified your health data
          </p>
        </div>

        <button
          onClick={() => alert('Exporting signed audit trail CSV...')}
          className="px-4 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Export Audit Log</span>
        </button>
      </div>

      {/* Audit Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 text-[10px] font-bold uppercase border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">Timestamp</th>
                <th className="py-3.5 px-4">Accessor Name & Role</th>
                <th className="py-3.5 px-4">Organization</th>
                <th className="py-3.5 px-4">Action & Resource</th>
                <th className="py-3.5 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {auditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/70">
                  <td className="py-4 px-4 font-mono text-slate-500 text-[11px] whitespace-nowrap">
                    {log.timestamp}
                  </td>
                  <td className="py-4 px-4">
                    <p className="font-bold text-slate-900">{log.accessorName}</p>
                    <p className="text-[10px] text-slate-400 capitalize">{log.role}</p>
                  </td>
                  <td className="py-4 px-4 text-slate-700">{log.organization}</td>
                  <td className="py-4 px-4">
                    <p className="font-semibold text-slate-800">{log.action}</p>
                    <p className="text-[11px] text-slate-500">{log.recordName}</p>
                  </td>
                  <td className="py-4 px-4">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        log.status === 'success'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {log.status.toUpperCase()}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
