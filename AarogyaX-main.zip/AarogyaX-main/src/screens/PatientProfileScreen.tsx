import React, { useState } from 'react';
import {
  User,
  Heart,
  ShieldCheck,
  Phone,
  AlertCircle,
  FileText,
  Download,
  Edit2,
  CheckCircle2,
  Activity,
  QrCode,
} from 'lucide-react';
import { PatientProfile, MainView } from '../types';

interface PatientProfileScreenProps {
  patient: PatientProfile;
  onUpdateProfile: (updated: Partial<PatientProfile>) => void;
  onNavigate: (view: MainView) => void;
}

export const PatientProfileScreen: React.FC<PatientProfileScreenProps> = ({
  patient,
  onUpdateProfile,
  onNavigate,
}) => {
  const [isEditing, setIsEditing] = useState(false);

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6 font-sans">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Patient Health Profile & ABHA Identity
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Personal health metrics, emergency contacts, and national digital health credentials
          </p>
        </div>

        <button
          onClick={() => alert('Downloading official AarogyaX & ABHA Digital Health Card...')}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-101 cursor-pointer flex items-center gap-2 self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Download Health Card</span>
        </button>
      </div>

      {/* Main Grid: Profile Card & Vitals Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (5 cols): ABHA Digital Identity Card */}
        <div className="lg:col-span-5 space-y-6">
          {/* Digital Card Graphic */}
          <div className="bg-gradient-to-br from-blue-700 via-indigo-800 to-slate-900 text-white p-6 sm:p-7 rounded-3xl shadow-xl space-y-6 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="w-6 h-6 text-blue-300" />
                <span className="font-extrabold tracking-tight text-sm">AarogyaX ABHA Card</span>
              </div>
              <span className="px-2 py-0.5 bg-white/20 text-white text-[10px] font-bold rounded">
                NATIONAL ID
              </span>
            </div>

            <div className="flex items-center gap-4">
              <img
                src={patient.avatarUrl}
                alt={patient.name}
                className="w-16 h-16 rounded-2xl object-cover ring-2 ring-white/50 shadow-md"
              />
              <div>
                <h3 className="text-lg font-bold">{patient.name}</h3>
                <p className="text-xs text-blue-200 font-mono mt-0.5">ID: {patient.medicalId}</p>
                <p className="text-xs text-blue-200">{patient.age} Yrs • {patient.gender}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/20 text-xs">
              <div>
                <span className="text-[10px] text-blue-300 font-bold uppercase">Blood Group</span>
                <p className="font-extrabold text-sm">{patient.bloodGroup}</p>
              </div>
              <div>
                <span className="text-[10px] text-blue-300 font-bold uppercase">Insurance Policy</span>
                <p className="font-extrabold text-sm font-mono">{patient.insurancePolicyNumber}</p>
              </div>
            </div>
          </div>

          {/* Emergency Contacts Card */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-2 text-red-600 font-bold text-sm">
              <AlertCircle className="w-5 h-5" />
              <span>Emergency Primary Contact</span>
            </div>

            <div className="p-4 bg-red-50/50 rounded-2xl border border-red-100 space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="font-bold text-slate-900">{patient.emergencyContact.name}</span>
                <span className="text-slate-500 font-medium">({patient.emergencyContact.relationship})</span>
              </div>
              <p className="text-slate-700 font-mono font-bold flex items-center gap-1.5 text-sm text-red-700">
                <Phone className="w-4 h-4" />
                <span>{patient.emergencyContact.phone}</span>
              </p>
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Clinical History, Conditions & Allergies */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-xs space-y-6">
            <h3 className="text-base font-bold text-slate-900 pb-3 border-b border-slate-100">
              Clinical Baseline & Allergies
            </h3>

            {/* Chronic Conditions */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Chronic Health Conditions
              </span>
              <div className="flex flex-wrap gap-2">
                {patient.chronicConditions.map((cond, i) => (
                  <span
                    key={i}
                    className="px-3 py-1.5 bg-blue-50 text-blue-800 border border-blue-200 rounded-xl text-xs font-semibold"
                  >
                    {cond}
                  </span>
                ))}
              </div>
            </div>

            {/* Known Allergies */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Known Drug & Food Allergies
              </span>
              <div className="flex flex-wrap gap-2">
                {patient.allergies.map((all, i) => (
                  <span
                    key={i}
                    className="px-3 py-1.5 bg-red-50 text-red-700 border border-red-200 rounded-xl text-xs font-bold"
                  >
                    ⚠️ {all}
                  </span>
                ))}
              </div>
            </div>

            {/* Past Surgeries & Major Illnesses */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Surgical History
              </span>
              <div className="flex flex-wrap gap-2">
                {patient.pastSurgeries.map((surg, i) => (
                  <span
                    key={i}
                    className="px-3 py-1.5 bg-slate-50 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold"
                  >
                    {surg}
                  </span>
                ))}
              </div>
            </div>

            {/* Biometric Metrics */}
            <div className="pt-4 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Height</span>
                <span className="text-sm font-bold text-slate-800">{patient.height}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Weight</span>
                <span className="text-sm font-bold text-slate-800">{patient.weight}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">BMI</span>
                <span className="text-sm font-bold text-emerald-600">{patient.bmi} (Normal)</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Blood Group</span>
                <span className="text-sm font-bold text-slate-800">{patient.bloodGroup}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
