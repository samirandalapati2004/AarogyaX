import React, { useState } from 'react';
import {
  Star,
  CheckCircle2,
  Building2,
  MapPin,
  Calendar,
  Clock,
  Video,
  User,
  ShieldCheck,
  Languages,
  Award,
  ArrowLeft,
  ChevronRight,
  FileCheck,
} from 'lucide-react';
import { Doctor, MainView } from '../types';

interface DoctorProfileScreenProps {
  doctor: Doctor;
  onBack: () => void;
  onBookAppointment: (bookingDetails: {
    doctor: Doctor;
    date: string;
    time: string;
    mode: 'in-person' | 'video';
    chiefComplaint: string;
  }) => void;
  onNavigate: (view: MainView) => void;
}

export const DoctorProfileScreen: React.FC<DoctorProfileScreenProps> = ({
  doctor,
  onBack,
  onBookAppointment,
  onNavigate,
}) => {
  const [selectedMode, setSelectedMode] = useState<'video' | 'in-person'>('video');
  const [selectedDate, setSelectedDate] = useState('Today, Oct 24');
  const [selectedTime, setSelectedTime] = useState('02:30 PM');
  const [chiefComplaint, setChiefComplaint] = useState('Epigastric stomach discomfort for 3 days post-meals');
  const [isBookedModalOpen, setIsBookedModalOpen] = useState(false);

  const availableDates = ['Today, Oct 24', 'Tomorrow, Oct 25', 'Wed, Oct 26', 'Thu, Oct 27'];
  const morningSlots = ['09:30 AM', '10:15 AM', '11:00 AM', '11:45 AM'];
  const afternoonSlots = ['02:00 PM', '02:30 PM', '03:15 PM', '04:00 PM'];
  const eveningSlots = ['05:30 PM', '06:15 PM', '07:00 PM'];

  const handleConfirmBooking = () => {
    setIsBookedModalOpen(true);
  };

  const handleFinishBooking = () => {
    setIsBookedModalOpen(false);
    onBookAppointment({
      doctor,
      date: selectedDate,
      time: selectedTime,
      mode: selectedMode,
      chiefComplaint,
    });
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-blue-600 transition-colors cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Doctors List</span>
      </button>

      {/* Main Grid: Doctor Details (7 cols) + Appointment Slot Picker (5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Doctor Profile */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
            {/* Header info */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
              <img
                src={doctor?.avatarUrl || 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=400&q=80'}
                alt={doctor?.name || 'Doctor Profile'}
                className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl object-cover ring-4 ring-blue-500/10 shadow-md"
              />
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">{doctor?.name || 'Dr. Specialist'}</h1>
                  <CheckCircle2 className="w-5 h-5 text-blue-600" />
                </div>
                <p className="text-sm font-bold text-teal-700">{doctor?.specialty || 'General Medicine'}</p>
                <p className="text-xs text-slate-500 font-medium">{doctor?.qualifications || doctor?.qualification || 'MBBS, MD'} • Reg #{doctor?.registrationNumber || 'KMC-88192'}</p>
                
                <div className="flex flex-wrap items-center gap-3 pt-1 text-xs">
                  <span className="flex items-center gap-1 text-amber-500 font-bold bg-amber-50 px-2.5 py-1 rounded-lg">
                    <Star className="w-4 h-4 fill-amber-400" />
                    {doctor?.rating || 4.9} ({doctor?.reviewCount || 120} reviews)
                  </span>
                  <span className="flex items-center gap-1 text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg font-semibold">
                    <Award className="w-4 h-4" />
                    {doctor?.experienceYears || 10}+ Years Experience
                  </span>
                </div>
              </div>
            </div>

            {/* Hospital & Address */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2 text-xs">
              <div className="flex items-center gap-2 font-semibold text-slate-800">
                <Building2 className="w-4 h-4 text-blue-600" />
                <span>{doctor?.hospitalName || doctor?.hospital || 'AarogyaX Super Specialty Hospital'}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-500">
                <MapPin className="w-4 h-4 text-slate-400" />
                <span>{doctor?.location || 'Bengaluru, India'}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-600 pt-1 border-t border-slate-200">
                <Languages className="w-4 h-4 text-slate-400" />
                <span>Languages: {doctor?.languages ? doctor.languages.join(', ') : 'English, Hindi, Kannada'}</span>
              </div>
            </div>

            {/* About Doctor */}
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">About Doctor</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {doctor?.about || 'Senior clinical consultant specializing in comprehensive patient care, proactive diagnosis, and evidence-based clinical treatment.'}
              </p>
            </div>

            {/* Verified Patient Reviews */}
            <div className="space-y-3 pt-2">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Patient Testimonials</h3>
              <div className="space-y-2.5">
                <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800">Rohan M.</span>
                    <span className="text-amber-500 font-bold">★★★★★</span>
                  </div>
                  <p className="text-slate-600">
                    "Dr. Jenkins was very attentive, reviewed my past lab reports instantly through the portal, and provided clear dietary guidance along with digital Rx."
                  </p>
                </div>
                <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800">Priya K.</span>
                    <span className="text-amber-500 font-bold">★★★★★</span>
                  </div>
                  <p className="text-slate-600">
                    "Very smooth video consultation experience. The AI pre-consultation summary made the call fast and focused."
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Slot Picker & Booking Box */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-sm space-y-6 sticky top-24">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">Select Appointment Slot</h3>
                <p className="text-xs text-slate-500">Fast digital token allocation</p>
              </div>
              <div className="text-right">
                <span className="text-lg font-extrabold text-blue-700">₹{doctor?.consultationFee || 800}</span>
                <span className="text-[10px] text-slate-400 block">consultation fee</span>
              </div>
            </div>

            {/* Consultation Mode */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Consultation Type
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedMode('video')}
                  className={`p-3 rounded-2xl border text-center transition-all cursor-pointer flex items-center justify-center gap-2 text-xs font-bold ${
                    selectedMode === 'video'
                      ? 'border-blue-600 bg-blue-50 text-blue-700 ring-2 ring-blue-500/20 shadow-xs'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <Video className="w-4 h-4 text-blue-600" />
                  <span>Video Telehealth</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedMode('in-person')}
                  className={`p-3 rounded-2xl border text-center transition-all cursor-pointer flex items-center justify-center gap-2 text-xs font-bold ${
                    selectedMode === 'in-person'
                      ? 'border-teal-600 bg-teal-50 text-teal-800 ring-2 ring-teal-500/20 shadow-xs'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <Building2 className="w-4 h-4 text-teal-600" />
                  <span>In-Person OPD</span>
                </button>
              </div>
            </div>

            {/* Date Selector */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Select Date
              </label>
              <div className="grid grid-cols-2 gap-2">
                {availableDates.map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setSelectedDate(d)}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold text-center transition-all cursor-pointer ${
                      selectedDate === d
                        ? 'bg-slate-900 text-white border-slate-900 font-bold shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>

            {/* Time Slots */}
            <div className="space-y-3">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Available Time Slots
              </label>

              {/* Afternoon Slots */}
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1.5">Afternoon Slots</span>
                <div className="grid grid-cols-2 gap-2">
                  {afternoonSlots.map((slot) => (
                    <button
                      key={slot}
                      type="button"
                      onClick={() => setSelectedTime(slot)}
                      className={`py-2 px-2.5 rounded-xl border text-xs font-semibold text-center transition-all cursor-pointer ${
                        selectedTime === slot
                          ? 'bg-blue-600 text-white border-blue-600 font-bold shadow-xs'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              {/* Evening Slots */}
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1.5">Evening Slots</span>
                <div className="grid grid-cols-3 gap-2">
                  {eveningSlots.map((slot) => (
                    <button
                      key={slot}
                      type="button"
                      onClick={() => setSelectedTime(slot)}
                      className={`py-2 px-2 rounded-xl border text-xs font-semibold text-center transition-all cursor-pointer ${
                        selectedTime === slot
                          ? 'bg-blue-600 text-white border-blue-600 font-bold shadow-xs'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Chief Complaint Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Reason for Visit / Symptoms
              </label>
              <textarea
                rows={2}
                value={chiefComplaint}
                onChange={(e) => setChiefComplaint(e.target.value)}
                className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all"
              />
            </div>

            {/* Book CTA */}
            <button
              type="button"
              onClick={handleConfirmBooking}
              className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-101 cursor-pointer flex items-center justify-center gap-2"
            >
              <span>Confirm & Generate Token</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Booking Success Modal */}
      {isBookedModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-200 text-center space-y-5 animate-in fade-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <h3 className="text-xl font-extrabold text-slate-900">Appointment Confirmed!</h3>
              <p className="text-xs text-slate-500">Your consultation slot has been reserved successfully</p>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-left text-xs">
              <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                <span className="text-slate-500">Doctor:</span>
                <span className="font-bold text-slate-900">{doctor.name}</span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                <span className="text-slate-500">Slot & Date:</span>
                <span className="font-bold text-slate-900">{selectedDate}, {selectedTime}</span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                <span className="text-slate-500">Mode:</span>
                <span className="font-bold text-blue-600 capitalize">{selectedMode} Consultation</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">OPD / Tele Token:</span>
                <span className="font-mono font-extrabold text-slate-900 px-2 py-0.5 bg-blue-100 rounded text-blue-800">
                  #TK-04
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <button
                onClick={() => {
                  setIsBookedModalOpen(false);
                  onNavigate('pre-consultation');
                }}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <FileCheck className="w-4 h-4" />
                <span>Fill Pre-Consultation Form (Recommended)</span>
              </button>

              <button
                onClick={handleFinishBooking}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
              >
                Go to Patient Dashboard
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
