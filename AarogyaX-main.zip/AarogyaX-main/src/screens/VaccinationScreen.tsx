import React, { useState } from 'react';
import {
  Syringe,
  CheckCircle2,
  Calendar,
  Download,
  Plus,
  ShieldCheck,
  Building2,
  QrCode,
  ArrowRight,
} from 'lucide-react';
import { VaccineRecord, MainView } from '../types';

interface VaccinationScreenProps {
  vaccines: VaccineRecord[];
  onOpenAddVaccine: () => void;
  onNavigate: (view: MainView) => void;
}

export const VaccinationScreen: React.FC<VaccinationScreenProps> = ({
  vaccines,
  onOpenAddVaccine,
  onNavigate,
}) => {
  const [activeTab, setActiveTab] = useState<'completed' | 'upcoming'>('completed');

  const completedVaccines = vaccines.filter((v) => v.status === 'completed');
  const upcomingVaccines = vaccines.filter((v) => v.status === 'upcoming' || v.status === 'overdue');

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6 font-sans">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Vaccination & Immunization Tracker
            </h1>
            <span className="px-2.5 py-0.5 bg-blue-50 text-blue-700 border border-blue-200 text-xs font-bold rounded-md">
              COWIN / ABHA LINKED
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Access verified digital immunization certificates, booster timelines, and family records
          </p>
        </div>

        <button
          onClick={onOpenAddVaccine}
          className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-101 cursor-pointer flex items-center gap-2 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Vaccine Record</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('completed')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'completed'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Completed Records ({completedVaccines.length})
        </button>

        <button
          onClick={() => setActiveTab('upcoming')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'upcoming'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Upcoming Boosters ({upcomingVaccines.length})
        </button>
      </div>

      {/* Vaccine List */}
      <div className="space-y-4">
        {(activeTab === 'completed' ? completedVaccines : upcomingVaccines).map((vac) => (
          <div
            key={vac.id}
            className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:border-blue-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center shrink-0">
                <Syringe className="w-6 h-6" />
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base font-extrabold text-slate-900">{vac.name}</h3>
                  <span className="px-2 py-0.5 bg-blue-50 text-blue-700 text-xs font-bold rounded-md">
                    {vac.dose}
                  </span>
                  {vac.certificateUrl && (
                    <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />
                      Verified
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-500 flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>{vac.facility}</span>
                  {vac.batchNumber && (
                    <>
                      <span>•</span>
                      <span className="font-mono text-[10px]">Batch: {vac.batchNumber}</span>
                    </>
                  )}
                </p>

                <p className="text-xs text-slate-600 flex items-center gap-1.5 pt-0.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>Administered: <strong className="text-slate-800">{vac.dateAdministered}</strong></span>
                  {vac.nextDueDate && (
                    <span className="text-blue-700 font-semibold ml-2">Next Booster: {vac.nextDueDate}</span>
                  )}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-center">
              <button
                onClick={() => alert(`Downloading verified Immunization Certificate for ${vac.name}...`)}
                className="px-4 py-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Download className="w-4 h-4" />
                <span>Certificate</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
