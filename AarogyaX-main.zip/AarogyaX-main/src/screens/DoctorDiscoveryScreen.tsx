import React, { useState, useEffect } from 'react';
import {
  Search,
  MapPin,
  Star,
  Calendar,
  Video,
  Building2,
  CheckCircle2,
  Filter,
  Stethoscope,
  ChevronRight,
  Sparkles,
  ArrowLeft,
} from 'lucide-react';
import { Doctor, MainView } from '../types';

interface DoctorDiscoveryScreenProps {
  doctors: Doctor[];
  selectedSpecialtyFilter?: string;
  onSelectDoctor: (doc: Doctor) => void;
  onNavigate: (view: MainView) => void;
}

export const DoctorDiscoveryScreen: React.FC<DoctorDiscoveryScreenProps> = ({
  doctors,
  selectedSpecialtyFilter,
  onSelectDoctor,
  onNavigate,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedConsultType, setSelectedConsultType] = useState<'all' | 'in-person' | 'video'>('all');
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>(selectedSpecialtyFilter || 'all');

  // Keep state in sync if parent changes selectedSpecialtyFilter
  useEffect(() => {
    if (selectedSpecialtyFilter) {
      setSelectedSpecialty(selectedSpecialtyFilter);
    }
  }, [selectedSpecialtyFilter]);

  const specialtiesList = [
    'all',
    'Gastroenterology',
    'Cardiology',
    'Dermatology',
    'General Medicine',
    'Orthopedics',
    'Neurology',
    'Pediatrics',
    'Gynecology',
    'Pulmonology',
    'ENT',
  ];

  const filteredDoctors = doctors.filter((doc) => {
    const docName = doc.name || '';
    const docSpec = doc.specialty || '';
    const docHosp = doc.hospitalName || doc.hospital || '';
    const docLoc = doc.location || 'Bengaluru';
    const docAbout = doc.about || '';

    const matchesSearch =
      docName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      docSpec.toLowerCase().includes(searchQuery.toLowerCase()) ||
      docHosp.toLowerCase().includes(searchQuery.toLowerCase()) ||
      docLoc.toLowerCase().includes(searchQuery.toLowerCase()) ||
      docAbout.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesSpecialty =
      selectedSpecialty === 'all' ||
      docSpec.toLowerCase().includes(selectedSpecialty.toLowerCase()) ||
      selectedSpecialty.toLowerCase().includes(docSpec.toLowerCase());

    const matchesType =
      selectedConsultType === 'all'
        ? true
        : selectedConsultType === 'video'
        ? !doc.consultationModes || doc.consultationModes.includes('video')
        : !doc.consultationModes || doc.consultationModes.includes('in-person');

    return matchesSearch && matchesSpecialty && matchesType;
  });

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Find & Book Verified Specialists
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Browse senior medical practitioners, schedule in-person hospital OPD or video consultations
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('specialties')}
            className="px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <Stethoscope className="w-4 h-4" />
            <span>Browse Specialties</span>
          </button>
          <button
            onClick={() => onNavigate('med-sarthi')}
            className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl text-xs font-bold shadow-xs hover:scale-102 transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Doctor Finder</span>
          </button>
        </div>
      </div>

      {/* Quick Specialty Chips Filter */}
      <div className="flex items-center gap-2 overflow-x-auto hide-scrollbar pb-1">
        {specialtiesList.map((spec) => (
          <button
            key={spec}
            onClick={() => setSelectedSpecialty(spec)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer transition-all ${
              selectedSpecialty === spec || (spec === 'all' && selectedSpecialty === 'all')
                ? 'bg-blue-600 text-white shadow-xs font-bold'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {spec === 'all' ? 'All Specialists' : spec}
          </button>
        ))}
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white rounded-3xl border border-slate-200 p-4 sm:p-5 shadow-xs space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search doctor name, hospital, condition..."
              className="w-full pl-10 pr-4 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all"
            />
          </div>

          <div className="md:col-span-4 flex items-center gap-2">
            <select
              value={selectedSpecialty}
              onChange={(e) => setSelectedSpecialty(e.target.value)}
              className="w-full px-3 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all text-slate-700 cursor-pointer font-medium"
            >
              <option value="all">All Specialties</option>
              <option value="Gastroenterology">Gastroenterology</option>
              <option value="Cardiology">Cardiology</option>
              <option value="Dermatology">Dermatology</option>
              <option value="General Medicine">General Medicine</option>
              <option value="Orthopedics">Orthopedics</option>
              <option value="Neurology">Neurology</option>
              <option value="Pediatrics">Pediatrics</option>
              <option value="Gynecology">Gynecology</option>
              <option value="Pulmonology">Pulmonology</option>
            </select>
          </div>

          <div className="md:col-span-3 flex items-center bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setSelectedConsultType('all')}
              className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                selectedConsultType === 'all'
                  ? 'bg-white text-slate-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setSelectedConsultType('video')}
              className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                selectedConsultType === 'video'
                  ? 'bg-white text-blue-700 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Video
            </button>
            <button
              onClick={() => setSelectedConsultType('in-person')}
              className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                selectedConsultType === 'in-person'
                  ? 'bg-white text-teal-700 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              OPD
            </button>
          </div>
        </div>
      </div>

      {/* Doctor Listings Grid */}
      {filteredDoctors.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
            <Stethoscope className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800">No doctors matched your criteria</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try resetting your filters or search for another specialty or symptom.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedSpecialty('all');
              setSelectedConsultType('all');
            }}
            className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition-colors cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDoctors.map((doc) => {
            const hospitalDisplay = doc.hospitalName || doc.hospital || 'AarogyaX Super Specialty Hospital';
            const locationDisplay = doc.location || 'Bengaluru, India';
            const qualificationsDisplay = doc.qualifications || doc.qualification || 'MBBS, MD';
            const slotDisplay = doc.nextSlot || 'Today, 02:30 PM';

            return (
              <div
                key={doc.id}
                className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:border-blue-300 hover:shadow-xl hover:shadow-blue-500/5 transition-all flex flex-col justify-between group"
              >
                <div className="space-y-4">
                  {/* Doctor Head Info */}
                  <div className="flex items-start gap-4">
                    <img
                      src={doc.avatarUrl}
                      alt={doc.name}
                      className="w-16 h-16 rounded-2xl object-cover ring-2 ring-blue-500/20 shadow-xs shrink-0"
                    />
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5">
                        <h3 className="text-base font-extrabold text-slate-900 group-hover:text-blue-600 transition-colors">
                          {doc.name}
                        </h3>
                        <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" title="Verified Specialist" />
                      </div>
                      <p className="text-xs font-bold text-teal-700">{doc.specialty}</p>
                      <p className="text-[11px] text-slate-500">{qualificationsDisplay} • {doc.experienceYears}+ yrs exp</p>
                    </div>
                  </div>

                  {/* Hospital & Location */}
                  <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-1 text-xs text-slate-600">
                    <p className="font-semibold text-slate-800 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-slate-400" />
                      <span>{hospitalDisplay}</span>
                    </p>
                    <p className="text-slate-500 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>{locationDisplay}</span>
                    </p>
                  </div>

                  {/* Stats Row */}
                  <div className="flex items-center justify-between text-xs pt-1">
                    <div className="flex items-center gap-1 text-amber-500 font-bold">
                      <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                      <span className="text-slate-800">{doc.rating}</span>
                      <span className="text-slate-400 font-normal">({doc.reviewCount})</span>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-extrabold text-slate-900">₹{doc.consultationFee}</span>
                      <span className="text-[10px] text-slate-500 ml-1 font-normal">/ session</span>
                    </div>
                  </div>

                  {/* Next Available Slot */}
                  <div className="flex items-center justify-between p-2.5 bg-blue-50/60 rounded-xl border border-blue-100 text-xs">
                    <span className="text-blue-900 font-semibold flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-blue-600" />
                      Next Available
                    </span>
                    <span className="font-bold text-blue-700">{slotDisplay}</span>
                  </div>
                </div>

                {/* CTAs */}
                <div className="pt-5 mt-5 border-t border-slate-100 flex items-center gap-2">
                  <button
                    onClick={() => onSelectDoctor(doc)}
                    className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all hover:scale-101 cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <span>Book Appointment</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onSelectDoctor(doc)}
                    className="px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Profile
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

