import React from 'react';
import {
  Activity,
  Sparkles,
  Calendar,
  FolderHeart,
  FileText,
  Pill,
  Syringe,
  Stethoscope,
  ShieldCheck,
  ArrowRight,
  CheckCircle2,
  Lock,
  HeartHandshake,
  Users,
  Smartphone,
  ChevronRight,
  Play,
} from 'lucide-react';
import { MainView, UserRole } from '../types';

interface LandingPageProps {
  onNavigate: (view: MainView) => void;
  onRoleChange: (role: UserRole) => void;
  onOpenAuth: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onNavigate,
  onRoleChange,
  onOpenAuth,
}) => {
  const features = [
    {
      icon: Sparkles,
      title: 'AI Health Assistant',
      desc: 'Med Sarthi analyzes symptoms with clinical precision, recommends specialties, and flags urgent risks.',
      color: 'bg-blue-50 text-blue-600 border-blue-100',
    },
    {
      icon: Calendar,
      title: 'Smart Appointments',
      desc: 'Book verified doctors in seconds with real-time OPD queue tokens and video consultation links.',
      color: 'bg-teal-50 text-teal-600 border-teal-100',
    },
    {
      icon: FolderHeart,
      title: 'Digital Medical Records',
      desc: 'All lab reports, MRI scans, and consultation summaries organized in an encrypted ABHA health vault.',
      color: 'bg-indigo-50 text-indigo-600 border-indigo-100',
    },
    {
      icon: FileText,
      title: 'Digital Prescription',
      desc: 'Legible, doctor-signed prescriptions with automated dose timelines and multi-lingual audio read-aloud.',
      color: 'bg-purple-50 text-purple-600 border-purple-100',
    },
    {
      icon: Pill,
      title: 'Medicine Reminders',
      desc: 'Smart medication schedules with before/after food instructions, refill tracking, and adherence logs.',
      color: 'bg-emerald-50 text-emerald-600 border-emerald-100',
    },
    {
      icon: Syringe,
      title: 'Vaccination Tracking',
      desc: 'Digital immunization certificates, booster alerts, and complete family vaccination timelines.',
      color: 'bg-cyan-50 text-cyan-600 border-cyan-100',
    },
    {
      icon: Stethoscope,
      title: 'Doctor Clinical EHR',
      desc: 'Streamlined clinical workspace for physicians with instant AI patient summaries and fast Rx generation.',
      color: 'bg-sky-50 text-sky-600 border-sky-100',
    },
    {
      icon: ShieldCheck,
      title: 'Secure Consent Data',
      desc: 'Granular patient consent management. You control exactly which doctor or hospital views your records.',
      color: 'bg-amber-50 text-amber-600 border-amber-100',
    },
  ];

  const journeySteps = [
    { step: '01', title: 'Symptoms', desc: 'Patient notices discomfort' },
    { step: '02', title: 'AI Assistant', desc: 'Med Sarthi organizes complaint' },
    { step: '03', title: 'Speciality', desc: 'Instant specialty match' },
    { step: '04', title: 'Doctor', desc: 'Select verified specialist' },
    { step: '05', title: 'Appointment', desc: 'In-person or Video slot' },
    { step: '06', title: 'Consultation', desc: 'Doctor examines with EHR' },
    { step: '07', title: 'Prescription', desc: 'Digital Rx & audio voice' },
    { step: '08', title: 'Follow-up', desc: 'Auto reminders & recovery' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Landing Navigation Header */}
      <nav className="bg-white/90 backdrop-blur-md border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
              <Activity className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-slate-900">
                Aarogya<span className="text-blue-600">X</span>
              </span>
              <span className="ml-2 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-blue-50 text-blue-700 rounded-md border border-blue-200">
                HEALTHCARE ECOSYSTEM
              </span>
            </div>
          </div>

          <div className="hidden lg:flex items-center gap-8 text-sm font-semibold text-slate-600">
            <a href="#features" className="hover:text-blue-600 transition-colors">Features</a>
            <a href="#journey" className="hover:text-blue-600 transition-colors">How It Works</a>
            <button
              onClick={() => {
                onRoleChange('patient');
                onNavigate('patient-dashboard');
              }}
              className="hover:text-blue-600 transition-colors cursor-pointer"
            >
              For Patients
            </button>
            <button
              onClick={() => {
                onRoleChange('doctor');
                onNavigate('doctor-dashboard');
              }}
              className="hover:text-blue-600 transition-colors cursor-pointer"
            >
              For Doctors
            </button>
            <button
              onClick={() => {
                onRoleChange('hospital');
                onNavigate('hospital-dashboard');
              }}
              className="hover:text-blue-600 transition-colors cursor-pointer"
            >
              For Hospitals
            </button>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onOpenAuth}
              className="px-4 py-2 text-sm font-semibold text-slate-700 hover:text-blue-600 transition-colors cursor-pointer"
            >
              Sign In
            </button>
            <button
              onClick={() => {
                onRoleChange('patient');
                onNavigate('patient-dashboard');
              }}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold shadow-md shadow-blue-500/20 transition-all hover:shadow-lg hover:shadow-blue-500/30 cursor-pointer flex items-center gap-1.5"
            >
              <span>Get Started</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28 bg-gradient-to-b from-blue-50/60 via-slate-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Hero Text */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100/80 border border-blue-200 text-blue-800 text-xs font-bold">
                <Sparkles className="w-4 h-4 text-blue-600" />
                <span>AI-Powered Connected Healthcare Platform</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-950 leading-[1.12]">
                Your Complete <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-indigo-600 to-teal-600">
                  Healthcare Journey,
                </span>{' '}
                Connected.
              </h1>

              <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto lg:mx-0 font-normal leading-relaxed">
                AarogyaX seamlessly unites patients, doctors, and hospitals into one intelligent healthcare ecosystem. From AI symptom triage and verified doctor booking to encrypted records and automated prescriptions.
              </p>

              {/* Tagline Box */}
              <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-xs max-w-xl mx-auto lg:mx-0 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-700 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <p className="text-xs font-semibold text-slate-800 italic">
                  “From Symptoms to Treatment — One Connected Healthcare Journey.”
                </p>
              </div>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
                <button
                  onClick={() => {
                    onRoleChange('patient');
                    onNavigate('patient-dashboard');
                  }}
                  className="w-full sm:w-auto px-7 py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-base font-bold shadow-lg shadow-blue-600/25 transition-all hover:scale-102 cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>Launch Patient Portal</span>
                  <ArrowRight className="w-5 h-5" />
                </button>

                <button
                  onClick={() => {
                    onRoleChange('doctor');
                    onNavigate('doctor-dashboard');
                  }}
                  className="w-full sm:w-auto px-6 py-3.5 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 rounded-xl text-base font-bold shadow-xs transition-all hover:border-slate-400 cursor-pointer flex items-center justify-center gap-2"
                >
                  <Stethoscope className="w-5 h-5 text-teal-600" />
                  <span>Doctor EHR Demo</span>
                </button>
              </div>

              {/* Trust badges */}
              <div className="pt-4 flex flex-wrap items-center justify-center lg:justify-start gap-6 text-xs text-slate-500 font-medium">
                <div className="flex items-center gap-1.5">
                  <Lock className="w-4 h-4 text-emerald-600" />
                  <span>ABHA & AES-256 Encrypted</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-blue-600" />
                  <span>Verified Medical Specialists</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-indigo-600" />
                  <span>100% Consent Driven</span>
                </div>
              </div>
            </div>

            {/* Right Hero Visual Mockup */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md bg-white rounded-3xl p-5 shadow-2xl border border-slate-200/80 space-y-4">
                {/* Visual Header */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-red-400"></span>
                    <span className="w-3 h-3 rounded-full bg-amber-400"></span>
                    <span className="w-3 h-3 rounded-full bg-emerald-400"></span>
                    <span className="text-xs font-bold text-slate-700 ml-2">AarogyaX Live Health Core</span>
                  </div>
                  <span className="px-2 py-0.5 text-[10px] bg-emerald-50 text-emerald-700 font-bold rounded-md">
                    ONLINE
                  </span>
                </div>

                {/* Patient AI Chat Pill Mock */}
                <div className="bg-blue-50/80 p-3.5 rounded-2xl border border-blue-100 space-y-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-blue-600" />
                    <span className="text-xs font-bold text-blue-900">Med Sarthi AI Triage</span>
                  </div>
                  <p className="text-xs text-slate-700 font-medium">
                    “Epigastric discomfort for 3 days post-prandial identified. Recommended specialty: <strong className="text-blue-800">Gastroenterology</strong>.”
                  </p>
                </div>

                {/* Doctor Booking Card Mock */}
                <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=120&q=80"
                      alt="Doctor"
                      className="w-11 h-11 rounded-xl object-cover ring-2 ring-blue-500/20"
                    />
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">Dr. Sarah Jenkins</h4>
                      <p className="text-[11px] text-teal-700 font-medium">Sr. Gastroenterologist</p>
                      <p className="text-[10px] text-slate-500">Apollo Hospitals • ★ 4.9 (342)</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 bg-blue-600 text-white text-[11px] font-bold rounded-lg shadow-xs">
                    Booked ✓
                  </span>
                </div>

                {/* Vitals & Prescription Strip */}
                <div className="grid grid-cols-2 gap-2.5">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-left">
                    <p className="text-[10px] text-slate-500 font-medium">Next Video Slot</p>
                    <p className="text-xs font-bold text-slate-800">Today, 02:30 PM</p>
                    <p className="text-[10px] text-emerald-600 font-semibold mt-0.5">Room Ready</p>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-left">
                    <p className="text-[10px] text-slate-500 font-medium">Digital Rx #8819</p>
                    <p className="text-xs font-bold text-slate-800">3 Active Meds</p>
                    <p className="text-[10px] text-blue-600 font-semibold mt-0.5">Audio Enabled 🔊</p>
                  </div>
                </div>

                <div className="p-3 bg-gradient-to-r from-teal-500 to-emerald-600 text-white rounded-2xl text-center shadow-md flex items-center justify-between px-4">
                  <span className="text-xs font-bold">1 Connected Health Vault</span>
                  <span className="text-xs font-mono font-medium">ABHA VERIFIED</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Section */}
      <section id="features" className="py-20 bg-white border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
            <span className="px-3.5 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold border border-blue-200">
              UNIFIED PLATFORM CAPABILITIES
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Designed for Patients, Doctors & Modern Hospitals
            </h2>
            <p className="text-base text-slate-600">
              Every stage of the healthcare experience is thoughtfully unified into high-clarity digital workflows.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feat, idx) => {
              const Icon = feat.icon;
              return (
                <div
                  key={idx}
                  className="p-6 bg-slate-50/70 hover:bg-white rounded-2xl border border-slate-200/80 hover:border-blue-200 transition-all hover:shadow-xl hover:shadow-blue-500/5 group"
                >
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-5 border ${feat.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
                    {feat.title}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed font-normal">
                    {feat.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works - Horizontal Journey */}
      <section id="journey" className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
            <span className="px-3.5 py-1 rounded-full bg-teal-50 text-teal-700 text-xs font-bold border border-teal-200">
              THE CONNECTED CLINICAL JOURNEY
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              From First Symptom to Complete Recovery
            </h2>
            <p className="text-base text-slate-600">
              Experience seamless healthcare where records, AI insights, prescriptions, and physician consultations flow continuously.
            </p>
          </div>

          {/* Horizontal Journey Steps */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {journeySteps.map((item, idx) => (
              <div
                key={idx}
                className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-mono font-bold text-blue-600 px-2 py-0.5 bg-blue-50 rounded border border-blue-200">
                      STEP {item.step}
                    </span>
                    {idx < journeySteps.length - 1 && (
                      <ChevronRight className="w-4 h-4 text-slate-300 hidden lg:block" />
                    )}
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">{item.title}</h4>
                  <p className="text-xs text-slate-500">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust & Security Section */}
      <section className="py-16 bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-slate-900 to-blue-950 text-white shadow-2xl">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              <div className="space-y-4">
                <span className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-400/30">
                  ENTERPRISE DATA GOVERNANCE
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                  Patient-Controlled Privacy & Consent Architecture
                </h3>
                <p className="text-sm text-slate-300 leading-relaxed">
                  Your medical records are stored in an encrypted ABHA health vault. Physicians and diagnostic labs only gain access after you grant explicit digital consent via our consent management gateway.
                </p>
                <div className="flex flex-wrap gap-4 pt-2">
                  <div className="flex items-center gap-2 text-xs text-slate-200 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Granular Time-Bound Access</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-200 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Instant Revocation</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-200 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Audit Log History</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/10">
                  <p className="text-2xl font-extrabold text-blue-400">100%</p>
                  <p className="text-xs text-slate-200 font-medium mt-1">Consent Driven</p>
                </div>
                <div className="p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/10">
                  <p className="text-2xl font-extrabold text-teal-400">AES-256</p>
                  <p className="text-xs text-slate-200 font-medium mt-1">Bank-Grade Encryption</p>
                </div>
                <div className="p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/10">
                  <p className="text-2xl font-extrabold text-emerald-400">ABHA</p>
                  <p className="text-xs text-slate-200 font-medium mt-1">National Health Compliant</p>
                </div>
                <div className="p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/10">
                  <p className="text-2xl font-extrabold text-indigo-400">5,000+</p>
                  <p className="text-xs text-slate-200 font-medium mt-1">Verified Doctors</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 py-12 border-t border-slate-800 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-10">
            <div className="col-span-2 space-y-3">
              <div className="flex items-center gap-2 text-white">
                <Activity className="w-5 h-5 text-blue-500" />
                <span className="font-bold text-base">AarogyaX Health</span>
              </div>
              <p className="text-slate-400 max-w-sm">
                From Symptoms to Treatment — One Connected Healthcare Journey.
              </p>
              <p className="text-[11px] text-slate-500">
                © 2026 AarogyaX Technologies Inc. All rights reserved.
              </p>
            </div>

            <div>
              <h5 className="font-bold text-white uppercase text-[11px] tracking-wider mb-3">Patients</h5>
              <ul className="space-y-2 text-slate-400">
                <li><button onClick={() => { onRoleChange('patient'); onNavigate('med-sarthi'); }} className="hover:text-white cursor-pointer">Med Sarthi AI</button></li>
                <li><button onClick={() => { onRoleChange('patient'); onNavigate('specialties'); }} className="hover:text-white cursor-pointer">Specialists</button></li>
                <li><button onClick={() => { onRoleChange('patient'); onNavigate('medical-records'); }} className="hover:text-white cursor-pointer">Health Records</button></li>
                <li><button onClick={() => { onRoleChange('patient'); onNavigate('prescriptions'); }} className="hover:text-white cursor-pointer">Digital Rx</button></li>
              </ul>
            </div>

            <div>
              <h5 className="font-bold text-white uppercase text-[11px] tracking-wider mb-3">Doctors & Hospitals</h5>
              <ul className="space-y-2 text-slate-400">
                <li><button onClick={() => { onRoleChange('doctor'); onNavigate('doctor-dashboard'); }} className="hover:text-white cursor-pointer">Doctor EHR</button></li>
                <li><button onClick={() => { onRoleChange('doctor'); onNavigate('doctor-consultation'); }} className="hover:text-white cursor-pointer">Consultation Room</button></li>
                <li><button onClick={() => { onRoleChange('hospital'); onNavigate('hospital-dashboard'); }} className="hover:text-white cursor-pointer">Hospital Hub</button></li>
                <li><button onClick={() => { onRoleChange('hospital'); onNavigate('hospital-analytics'); }} className="hover:text-white cursor-pointer">Clinical Analytics</button></li>
              </ul>
            </div>

            <div>
              <h5 className="font-bold text-white uppercase text-[11px] tracking-wider mb-3">Trust & Legal</h5>
              <ul className="space-y-2 text-slate-400">
                <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white">Terms of Care</a></li>
                <li><a href="#" className="hover:text-white">Security Architecture</a></li>
                <li><a href="#" className="hover:text-white">Emergency Guidelines</a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
