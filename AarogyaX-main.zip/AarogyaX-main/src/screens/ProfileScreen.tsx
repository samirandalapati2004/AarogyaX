import React from 'react';
import { PatientProfile, NavigationTab } from '../types';

interface ProfileScreenProps {
  patient: PatientProfile;
  onTabChange: (tab: NavigationTab) => void;
  onOpenEmergency: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  patient,
  onTabChange,
  onOpenEmergency,
}) => {
  return (
    <main className="max-w-4xl mx-auto px-4 md:px-8 py-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-end pb-4 border-b border-[#141414]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="tech-tag bg-white">CLINICAL_IDENTITY</span>
            <span className="font-mono-tech text-[10px] text-[#5A5A58]">ABHA_COMPLIANT</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-[#141414] uppercase tracking-tight">
            Patient Profile & Vault
          </h1>
        </div>

        <button
          onClick={onOpenEmergency}
          className="bg-[#D92D20] text-white px-3.5 py-1.5 border border-[#141414] font-mono-tech text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-[2px_2px_0px_#141414] active:scale-95"
        >
          <span className="material-symbols-outlined text-sm">emergency</span>
          SOS BEACON
        </button>
      </div>

      {/* Patient Primary Card */}
      <section className="bg-white border border-[#141414] p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5 pb-5 border-b border-[#141414]/15">
          <div className="w-20 h-20 border border-[#141414] bg-[#F0EFED] overflow-hidden shrink-0">
            <img
              className="w-full h-full object-cover grayscale contrast-125"
              alt={patient.name}
              src={patient.avatarUrl}
            />
          </div>

          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <h2 className="text-xl font-bold text-[#141414] uppercase">{patient.name}</h2>
              <span className="tech-tag-solid text-[9px] py-0.5 px-1.5">VERIFIED PATIENT</span>
            </div>
            <p className="font-mono-tech text-xs text-[#5A5A58]">
              {patient.gender} • {patient.age} YRS • BLOOD GROUP: <b className="text-[#141414]">{patient.bloodGroup}</b>
            </p>
            <div className="flex flex-wrap gap-2 mt-2 font-mono-tech text-xs">
              <span className="tech-tag bg-[#F0EFED]">MEDICAL_ID: {patient.medicalId}</span>
              <span className="tech-tag bg-[#F0EFED]">ABHA: {patient.abhaId}</span>
            </div>
          </div>
        </div>

        {/* Clinical Parameters Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-5 font-mono-tech text-xs">
          <div className="space-y-1 bg-[#F0EFED] p-3 border border-[#141414]/20">
            <span className="text-[#5A5A58] uppercase text-[10px]">Contact Information</span>
            <div className="text-[#141414] font-bold">{patient.phone}</div>
            <div className="text-[#5A5A58]">{patient.email}</div>
            <div className="text-[#5A5A58] text-[11px]">{patient.address}</div>
          </div>

          <div className="space-y-1 bg-[#F0EFED] p-3 border border-[#141414]/20">
            <span className="text-[#5A5A58] uppercase text-[10px]">Primary Physician</span>
            <div className="text-[#141414] font-bold">{patient.primaryDoctor.name}</div>
            <div className="text-[#2A5CFF]">{patient.primaryDoctor.title}</div>
            <div className="text-[#5A5A58] text-[11px]">{patient.primaryDoctor.hospital}</div>
          </div>
        </div>
      </section>

      {/* Critical Medical Indicators */}
      <section className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Allergies */}
        <div className="bg-white border border-[#141414] p-5">
          <div className="flex items-center gap-2 mb-3">
            <span className="material-symbols-outlined text-[#D92D20] text-lg">warning</span>
            <h3 className="font-bold text-sm text-[#141414] uppercase">Known Allergies</h3>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {patient.allergies.map((allergy, i) => (
              <span key={i} className="tech-tag bg-[#FEE4E2] text-[#D92D20] font-mono-tech text-xs font-bold">
                {allergy}
              </span>
            ))}
          </div>
        </div>

        {/* Chronic Conditions */}
        <div className="bg-white border border-[#141414] p-5">
          <div className="flex items-center gap-2 mb-3">
            <span className="material-symbols-outlined text-[#2A5CFF] text-lg">monitor_heart</span>
            <h3 className="font-bold text-sm text-[#141414] uppercase">Chronic Conditions</h3>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {patient.chronicConditions.map((cond, i) => (
              <span key={i} className="tech-tag bg-[#F0EFED] text-[#141414] font-mono-tech text-xs font-bold">
                {cond}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Emergency Contact Broadcast Details */}
      <section className="bg-white border border-[#141414] p-5">
        <div className="flex justify-between items-center mb-3">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#141414] text-lg">contact_phone</span>
            <h3 className="font-bold text-sm text-[#141414] uppercase">Designated Emergency Contact</h3>
          </div>
          <span className="tech-tag-solid text-[9px]">PRIMARY RESPONDER</span>
        </div>

        <div className="bg-[#F0EFED] p-4 border border-[#141414]/20 flex flex-col sm:flex-row justify-between sm:items-center gap-3 font-mono-tech text-xs">
          <div>
            <div className="font-bold text-sm text-[#141414]">{patient.emergencyContact.name}</div>
            <div className="text-[#5A5A58]">{patient.emergencyContact.relationship}</div>
          </div>

          <a
            href={`tel:${patient.emergencyContact.phone}`}
            className="px-4 py-2 bg-[#141414] text-white font-bold hover:bg-[#2A5CFF] transition-colors inline-flex items-center justify-center gap-2 border border-[#141414] uppercase tracking-wider"
          >
            <span className="material-symbols-outlined text-sm">call</span>
            Call {patient.emergencyContact.phone}
          </a>
        </div>
      </section>
    </main>
  );
};
