import React, { useState } from 'react';
import {
  Pill,
  CheckCircle2,
  Clock,
  Plus,
  Calendar,
  AlertCircle,
  TrendingUp,
  ShieldCheck,
  ChevronRight,
  Bell,
} from 'lucide-react';
import { Medicine, MainView } from '../types';

interface MedicineRemindersScreenProps {
  medicines: Medicine[];
  onToggleMed: (id: string) => void;
  onOpenAddMed: () => void;
  onNavigate: (view: MainView) => void;
}

export const MedicineRemindersScreen: React.FC<MedicineRemindersScreenProps> = ({
  medicines,
  onToggleMed,
  onOpenAddMed,
  onNavigate,
}) => {
  const [selectedDay, setSelectedDay] = useState('Today');

  const days = ['Mon', 'Tue', 'Wed', 'Thu (Today)', 'Fri', 'Sat', 'Sun'];

  const takenCount = medicines.filter((m) => m.taken).length;
  const adherencePercent = Math.round((takenCount / (medicines.length || 1)) * 100);

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6 font-sans">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Medicine Reminders & Adherence
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Track daily doses, before/after meal timings, and refill alerts
          </p>
        </div>

        <button
          onClick={onOpenAddMed}
          className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-101 cursor-pointer flex items-center gap-2 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Medication</span>
        </button>
      </div>

      {/* Adherence Streak Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 bg-gradient-to-br from-blue-600 to-indigo-700 text-white rounded-3xl shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs text-blue-200 font-bold uppercase">Today's Progress</span>
            <TrendingUp className="w-4 h-4 text-blue-200" />
          </div>
          <p className="text-3xl font-extrabold">{adherencePercent}%</p>
          <p className="text-xs text-blue-100">{takenCount} of {medicines.length} doses completed</p>
        </div>

        <div className="p-5 bg-white border border-slate-200 rounded-3xl shadow-xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-bold uppercase">Adherence Streak</span>
            <span className="text-xs font-bold text-emerald-600">🔥 Active</span>
          </div>
          <p className="text-3xl font-extrabold text-slate-900">14 Days</p>
          <p className="text-xs text-slate-500">Zero missed doses this fortnight</p>
        </div>

        <div className="p-5 bg-white border border-slate-200 rounded-3xl shadow-xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-bold uppercase">Refill Alerts</span>
            <AlertCircle className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-3xl font-extrabold text-amber-600">1 Due</p>
          <p className="text-xs text-slate-500">Telmisartan 40mg (5 tablets left)</p>
        </div>
      </div>

      {/* Day Selector */}
      <div className="bg-white rounded-2xl border border-slate-200 p-2 shadow-xs flex items-center justify-between overflow-x-auto gap-2">
        {days.map((d, i) => (
          <button
            key={i}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer transition-all text-center ${
              d.includes('Today')
                ? 'bg-blue-600 text-white font-bold shadow-xs'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            {d}
          </button>
        ))}
      </div>

      {/* Active Medication List */}
      <div className="space-y-4">
        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
          Scheduled Doses for Today
        </h3>

        <div className="space-y-3">
          {medicines.map((med) => (
            <div
              key={med.id}
              className={`p-5 rounded-3xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                med.taken
                  ? 'bg-emerald-50/40 border-emerald-200 shadow-2xs'
                  : 'bg-white border-slate-200 shadow-xs hover:border-blue-200'
              }`}
            >
              <div className="flex items-start sm:items-center gap-4">
                <button
                  onClick={() => onToggleMed(med.id)}
                  className={`w-9 h-9 rounded-2xl flex items-center justify-center transition-colors cursor-pointer shrink-0 mt-0.5 sm:mt-0 ${
                    med.taken
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'border-2 border-slate-300 hover:border-blue-600 bg-white'
                  }`}
                  title={med.taken ? 'Mark as Not Taken' : 'Mark as Taken'}
                >
                  {med.taken && <CheckCircle2 className="w-5 h-5" />}
                </button>

                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4 className={`text-sm font-bold ${med.taken ? 'text-slate-700 line-through opacity-75' : 'text-slate-900'}`}>
                      {med.name}
                    </h4>
                    <span className="text-xs text-slate-500 font-medium font-mono">({med.dosage})</span>
                    <span className="px-2 py-0.5 bg-blue-50 text-blue-700 text-[10px] font-bold rounded-md border border-blue-200">
                      {med.frequency}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 font-medium">{med.instructions}</p>
                  <p className="text-[11px] text-slate-400">Duration: {med.duration} • Refill in {med.refillDaysRemaining || 14} days</p>
                </div>
              </div>

              <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-100">
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-slate-800">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>{med.scheduledTime}</span>
                </div>
                <span
                  className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-md mt-1 ${
                    med.taken
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-blue-100 text-blue-800'
                  }`}
                >
                  {med.taken ? 'Dose Taken ✓' : 'Pending'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
