import React, { useState } from 'react';
import { MedicalRecord, NavigationTab } from '../types';

interface RecordsScreenProps {
  records: MedicalRecord[];
  onViewRecord: (record: MedicalRecord) => void;
  onOpenUpload: () => void;
  onTabChange: (tab: NavigationTab) => void;
}

export const RecordsScreen: React.FC<RecordsScreenProps> = ({
  records,
  onViewRecord,
  onOpenUpload,
  onTabChange,
}) => {
  const [activeCategory, setActiveCategory] = useState<'All Records' | 'Lab Reports' | 'Prescriptions' | 'Vaccinations'>('All Records');
  const [shareWithDoctor, setShareWithDoctor] = useState(true);

  const filteredRecords = records.filter((rec) => {
    if (activeCategory === 'All Records') return true;
    return rec.category === activeCategory;
  });

  return (
    <main className="max-w-7xl mx-auto px-4 md:px-8 py-6 md:grid md:grid-cols-12 md:gap-6">
      {/* Desktop Left Nav Sidebar */}
      <aside className="hidden md:block md:col-span-3">
        <nav className="sticky top-20 bg-white border border-[#141414] p-3 flex flex-col gap-1 font-mono-tech text-xs">
          <div className="px-3 py-2 border-b border-[#141414]/15 mb-1">
            <span className="text-[10px] text-[#5A5A58] uppercase font-bold tracking-wider">NAVIGATION</span>
          </div>

          <button
            onClick={() => onTabChange('home')}
            className="flex items-center gap-2.5 p-2.5 text-[#5A5A58] hover:bg-[#F0EFED] hover:text-[#141414] transition-colors cursor-pointer text-left uppercase"
          >
            <span className="material-symbols-outlined text-base">dashboard</span>
            <span>01 // Dashboard</span>
          </button>
          <button
            onClick={() => onTabChange('schedule')}
            className="flex items-center gap-2.5 p-2.5 text-[#5A5A58] hover:bg-[#F0EFED] hover:text-[#141414] transition-colors cursor-pointer text-left uppercase"
          >
            <span className="material-symbols-outlined text-base">calendar_today</span>
            <span>02 // Schedule</span>
          </button>
          <button
            onClick={() => onTabChange('sarthi')}
            className="flex items-center gap-2.5 p-2.5 text-[#5A5A58] hover:bg-[#F0EFED] hover:text-[#2A5CFF] transition-colors cursor-pointer text-left uppercase"
          >
            <span className="material-symbols-outlined text-base text-[#2A5CFF]">smart_toy</span>
            <span>03 // Med Sarthi</span>
          </button>
          <button
            onClick={() => onTabChange('records')}
            className="flex items-center gap-2.5 p-2.5 bg-[#141414] text-white font-bold transition-colors cursor-pointer text-left uppercase"
          >
            <span className="material-symbols-outlined text-base">folder</span>
            <span>04 // Records Vault</span>
          </button>
          <button
            onClick={() => onTabChange('profile')}
            className="flex items-center gap-2.5 p-2.5 text-[#5A5A58] hover:bg-[#F0EFED] hover:text-[#141414] transition-colors cursor-pointer text-left uppercase"
          >
            <span className="material-symbols-outlined text-base">account_circle</span>
            <span>05 // Profile</span>
          </button>

          <div className="pt-3 border-t border-[#141414]/15 mt-2">
            <button
              onClick={onOpenUpload}
              className="w-full py-2.5 bg-[#2A5CFF] hover:bg-[#1742DB] text-white border border-[#141414] text-xs font-bold font-mono-tech flex items-center justify-center gap-1.5 cursor-pointer uppercase tracking-wider shadow-[2px_2px_0px_#141414] active:translate-x-0.5 active:translate-y-0.5"
            >
              <span className="material-symbols-outlined text-base">upload_file</span>
              + Upload Document
            </button>
          </div>
        </nav>
      </aside>

      {/* Main Content Area */}
      <div className="md:col-span-9 flex flex-col gap-6">
        {/* Page Header & Actions */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#141414]">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="tech-tag bg-white">RECORDS_VAULT</span>
              <span className="font-mono-tech text-[10px] text-[#5A5A58]">ENCRYPTED_AES_256</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-[#141414] uppercase tracking-tight">
              Medical Records Vault
            </h1>
          </div>

          <div className="flex items-center gap-3 self-start sm:self-auto font-mono-tech text-xs">
            <button
              onClick={onOpenUpload}
              className="md:hidden px-3.5 py-2 bg-[#2A5CFF] text-white border border-[#141414] font-bold flex items-center gap-1.5 shadow-[2px_2px_0px_#141414]"
            >
              <span className="material-symbols-outlined text-base">upload_file</span>
              Upload
            </button>

            <div className="flex items-center gap-2 bg-white px-3 py-2 border border-[#141414]">
              <span className="text-[#5A5A58] uppercase text-[11px]">Provider Access:</span>
              <button
                type="button"
                onClick={() => setShareWithDoctor(!shareWithDoctor)}
                className={`px-2 py-0.5 border text-[10px] font-bold uppercase transition-colors cursor-pointer ${
                  shareWithDoctor
                    ? 'bg-[#141414] text-white border-[#141414]'
                    : 'bg-[#F0EFED] text-[#5A5A58] border-[#141414]/30'
                }`}
              >
                {shareWithDoctor ? 'SHARED' : 'PRIVATE'}
              </button>
            </div>
          </div>
        </div>

        {/* AI Summary / Longitudinal Stats Grid (Matching theme stat-grid) */}
        <section className="bg-white border border-[#141414] overflow-hidden">
          <div className="p-4 border-b border-[#141414] bg-[#F0EFED] flex justify-between items-center">
            <div className="flex items-center gap-2">
              <span className="font-mono-tech text-xs font-bold uppercase text-[#141414]">
                Longitudinal Biomarker Analysis
              </span>
              <span className="tech-tag-accent text-[9px] py-0 px-1.5">AI_SYNTHESIS</span>
            </div>
            <span className="font-mono-tech text-[10px] text-[#5A5A58] uppercase">RANGE: 24_MONTHS</span>
          </div>

          <div className="p-4 space-y-3">
            <p className="text-xs text-[#5A5A58] font-mono-tech">
              Med Sarthi multi-document ingestion summary across recent visits & laboratory panels:
            </p>

            {/* Stat Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 bg-[#141414] border border-[#141414] p-[1px]">
              <div className="bg-white p-3.5">
                <div className="flex justify-between items-start mb-1">
                  <span className="font-mono-tech text-[10px] text-[#5A5A58] uppercase">CARDIOVASCULAR</span>
                  <span className="tech-tag bg-[#F0EFED] text-[#079455]">STABLE_6M</span>
                </div>
                <div className="font-mono-tech text-lg font-bold text-[#141414]">120/80 mmHg</div>
                <div className="text-[11px] text-[#5A5A58]">Hypertension parameters well-controlled under current therapy.</div>
              </div>

              <div className="bg-white p-3.5">
                <div className="flex justify-between items-start mb-1">
                  <span className="font-mono-tech text-[10px] text-[#5A5A58] uppercase">METABOLIC / GLYCEMIC</span>
                  <span className="tech-tag bg-[#FEE4E2] text-[#D92D20]">ATTENTION</span>
                </div>
                <div className="font-mono-tech text-lg font-bold text-[#141414]">HbA1c: 6.2%</div>
                <div className="text-[11px] text-[#5A5A58]">Borderline pre-diabetic elevation. Routine follow-up scheduled.</div>
              </div>
            </div>
          </div>
        </section>

        {/* Category Filter Tabs */}
        <div className="flex gap-1 overflow-x-auto pb-1 hide-scrollbar">
          {(['All Records', 'Lab Reports', 'Prescriptions', 'Vaccinations'] as const).map((tab) => {
            const isActive = activeCategory === tab;
            return (
              <button
                key={tab}
                onClick={() => setActiveCategory(tab)}
                className={`px-3.5 py-1.5 font-mono-tech text-xs uppercase tracking-wider border cursor-pointer transition-colors ${
                  isActive
                    ? 'bg-[#141414] text-white border-[#141414] font-bold'
                    : 'bg-white text-[#141414] border-[#141414] hover:bg-[#F0EFED]'
                }`}
              >
                {tab}
              </button>
            );
          })}
        </div>

        {/* Records Data Table Rows */}
        <div className="bg-white border border-[#141414] divide-y divide-[#141414]/15">
          {filteredRecords.map((record) => {
            const isOutdated = record.badgeType === 'outdated';
            const isAi = record.badgeType === 'ai-summarized';

            return (
              <div
                key={record.id}
                className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-[#F0EFED] transition-colors"
              >
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 border border-[#141414] bg-[#F0EFED] flex items-center justify-center font-mono-tech text-xs font-bold text-[#141414] shrink-0">
                    {record.category === 'Prescriptions' ? 'RX' : 'DOC'}
                  </div>

                  <div>
                    <div className="flex flex-wrap items-center gap-2 mb-0.5">
                      <h4 className="text-sm font-bold text-[#141414] uppercase">{record.title}</h4>
                      {record.statusBadge && (
                        <span
                          className={`tech-tag text-[9px] ${
                            isOutdated
                              ? 'bg-[#FEE4E2] text-[#D92D20]'
                              : isAi
                              ? 'bg-[#2A5CFF] text-white'
                              : 'bg-[#F0EFED]'
                          }`}
                        >
                          {record.statusBadge}
                        </span>
                      )}
                    </div>

                    <p className="font-mono-tech text-xs text-[#5A5A58]">
                      {record.doctorName ? `${record.doctorName} // ${record.facility}` : record.facility}
                    </p>

                    <p className="font-mono-tech text-[10px] text-[#5A5A58] mt-0.5">
                      UPLOADED: {record.uploadDate} // SIZE: {record.fileSize || '1.8 MB'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end md:self-auto">
                  <button
                    onClick={() => onViewRecord(record)}
                    className="px-4 py-1.5 bg-white border border-[#141414] text-[#141414] font-mono-tech text-xs font-bold hover:bg-[#141414] hover:text-white transition-colors cursor-pointer uppercase tracking-wider shadow-[1px_1px_0px_#141414]"
                  >
                    View Details &gt;
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </main>
  );
};
