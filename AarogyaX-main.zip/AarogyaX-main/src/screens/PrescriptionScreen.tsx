import React, { useState } from 'react';
import {
  FileText,
  Volume2,
  VolumeX,
  Download,
  Share2,
  Pill,
  CheckCircle2,
  ShieldCheck,
  Building2,
  Calendar,
  Clock,
  QrCode,
  Languages,
  Plus,
} from 'lucide-react';
import { DigitalPrescription, MainView } from '../types';

interface PrescriptionScreenProps {
  prescription: DigitalPrescription;
  onNavigate: (view: MainView) => void;
  onAddAllToReminders: () => void;
}

export const PrescriptionScreen: React.FC<PrescriptionScreenProps> = ({
  prescription,
  onNavigate,
  onAddAllToReminders,
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState<'English' | 'Hindi' | 'Tamil' | 'Telugu'>('English');
  const [isAddedToast, setIsAddedToast] = useState(false);

  const toggleAudio = () => {
    setIsPlayingAudio(!isPlayingAudio);
    if (!isPlayingAudio) {
      setTimeout(() => setIsPlayingAudio(false), 6000);
    }
  };

  const handleAddToReminders = () => {
    onAddAllToReminders();
    setIsAddedToast(true);
    setTimeout(() => setIsAddedToast(false), 3000);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6 font-sans">
      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Digital Prescription
            </h1>
            <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold rounded-md">
              VALID & SIGNED
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Prescription #{prescription.id} • Issued by {prescription.doctorName}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Language Selector for Audio */}
          <div className="flex items-center gap-1.5 bg-white border border-slate-200 px-2.5 py-1.5 rounded-xl text-xs">
            <Languages className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedLanguage}
              onChange={(e: any) => setSelectedLanguage(e.target.value)}
              className="bg-transparent text-slate-700 font-semibold focus:outline-none cursor-pointer"
            >
              <option value="English">English</option>
              <option value="Hindi">Hindi (हिंदी)</option>
              <option value="Tamil">Tamil (தமிழ்)</option>
              <option value="Telugu">Telugu (తెలుగు)</option>
            </select>
          </div>

          <button
            onClick={toggleAudio}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              isPlayingAudio
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 hover:bg-slate-50 text-slate-700'
            }`}
          >
            {isPlayingAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-blue-600" />}
            <span>{isPlayingAudio ? `Speaking in ${selectedLanguage}...` : 'Audio Read-Aloud'}</span>
          </button>

          <button
            onClick={() => alert('Downloading official stamped Rx PDF...')}
            className="p-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl cursor-pointer"
            title="Download PDF"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {isAddedToast && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-2 text-xs font-bold text-emerald-800 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>All 3 medicines added to your active daily reminder schedule!</span>
        </div>
      )}

      {/* Main Prescription Paper Layout */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-10 space-y-8 relative">
        {/* Hospital Letterhead Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-6 border-b-2 border-slate-900 gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-blue-600" />
              <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
                {prescription.hospitalName}
              </h2>
            </div>
            <p className="text-xs font-bold text-slate-700">{prescription.doctorName} ({prescription.doctorQualifications})</p>
            <p className="text-[11px] text-slate-500 font-mono">Reg #{prescription.doctorRegNumber} • Department of Gastroenterology</p>
          </div>

          <div className="text-left sm:text-right space-y-1 text-xs text-slate-500">
            <p className="font-mono font-bold text-slate-800">Rx ID: {prescription.id}</p>
            <p className="flex items-center sm:justify-end gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Date: {prescription.date}</span>
            </p>
          </div>
        </div>

        {/* Patient Demographics & Diagnosis */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase">Patient Name</span>
            <p className="font-bold text-slate-900 text-sm mt-0.5">{prescription.patientName}</p>
            <p className="text-slate-500 text-[11px]">{prescription.patientAge} Yrs / {prescription.patientGender}</p>
          </div>

          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase">Medical ID / ABHA</span>
            <p className="font-bold text-slate-900 font-mono mt-0.5">{prescription.patientId}</p>
          </div>

          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase">Clinical Diagnosis</span>
            <p className="font-bold text-blue-700 mt-0.5">{prescription.diagnosis}</p>
          </div>
        </div>

        {/* Prescribed Medications Table */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm uppercase tracking-wider">
            <Pill className="w-4 h-4 text-blue-600" />
            <span>Prescribed Medications (Rx)</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100 text-slate-700 text-[10px] font-bold uppercase border-y border-slate-200">
                <tr>
                  <th className="py-3 px-3">Medicine & Strength</th>
                  <th className="py-3 px-3">Dosage / Pattern</th>
                  <th className="py-3 px-3">Food Timing</th>
                  <th className="py-3 px-3">Duration</th>
                  <th className="py-3 px-3">Instructions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {prescription.medications.map((med, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="py-3.5 px-3">
                      <p className="font-bold text-slate-900">{med.name}</p>
                      <p className="text-[11px] text-slate-500">{med.dosage}</p>
                    </td>
                    <td className="py-3.5 px-3 font-mono font-bold text-blue-700">
                      {med.frequency}
                    </td>
                    <td className="py-3.5 px-3">
                      <span className="px-2 py-0.5 bg-amber-50 border border-amber-200 text-amber-800 rounded font-semibold text-[10px]">
                        {med.timing}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 font-semibold text-slate-700">{med.duration}</td>
                    <td className="py-3.5 px-3 text-slate-600 text-[11px]">{med.instructions}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Doctor Advice & Follow-Up Strip */}
        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
          <h4 className="font-bold text-slate-900 uppercase text-[10px] tracking-wider">
            Dietary & Lifestyle Advice
          </h4>
          <p className="text-slate-700 leading-relaxed">{prescription.doctorNotes}</p>
          {prescription.followUpDate && (
            <p className="text-blue-700 font-bold pt-1">
              Follow-up Review: {prescription.followUpDate}
            </p>
          )}
        </div>

        {/* Digital Signature & QR Verification */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pt-6 border-t border-slate-200 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 bg-slate-100 border border-slate-300 rounded-xl flex items-center justify-center p-1.5">
              <QrCode className="w-10 h-10 text-slate-700" />
            </div>
            <div className="text-[11px] text-slate-500">
              <p className="font-bold text-slate-800">Scan to Verify Authentic Rx</p>
              <p>National Health ABHA Gateway Verified</p>
            </div>
          </div>

          <div className="text-left sm:text-right space-y-1">
            <p className="font-serif italic text-base text-slate-800 font-bold">Dr. Sarah Jenkins</p>
            <div className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              <ShieldCheck className="w-3 h-3" />
              <span>Digitally Authenticated</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons Below Paper */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <button
          onClick={handleAddToReminders}
          className="w-full sm:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-101 cursor-pointer flex items-center justify-center gap-2"
        >
          <Plus className="w-4 h-4" />
          <span>Add All Medicines to My Daily Reminders</span>
        </button>

        <button
          onClick={() => onNavigate('medicine-reminders')}
          className="w-full sm:w-auto px-6 py-3 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer text-center"
        >
          View Daily Reminder Timeline →
        </button>
      </div>
    </div>
  );
};
