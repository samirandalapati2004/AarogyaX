export type UserRole = 'patient' | 'doctor' | 'hospital';

export type MainView =
  | 'landing'
  | 'auth'
  | 'home'
  | 'patient-dashboard'
  | 'med-sarthi'
  | 'specialties'
  | 'doctor-discovery'
  | 'doctor-profile'
  | 'appointment-booking'
  | 'pre-consultation'
  | 'medical-records'
  | 'report-viewer'
  | 'prescriptions'
  | 'medicine-reminders'
  | 'vaccinations'
  | 'consent-management'
  | 'audit-log'
  | 'notifications'
  | 'patient-profile'
  | 'doctor-dashboard'
  | 'doctor-patient-view'
  | 'doctor-consultation'
  | 'doctor-rx-builder'
  | 'hospital-dashboard'
  | 'hospital-analytics';

export type NavigationTab = 'home' | 'sarthi' | 'schedule' | 'records' | 'profile';

export interface PatientProfile {
  id: string;
  name: string;
  medicalId: string;
  avatarUrl: string;
  age: number;
  gender: string;
  bloodGroup: string;
  phone: string;
  email: string;
  address: string;
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  chronicConditions: string[];
  allergies: string[];
  currentMedications: string[];
  pastSurgeries?: string[];
  previousDiseases?: string[];
  insuranceProvider?: string;
  insurancePolicyNumber?: string;
  policyNumber?: string;
  height?: string;
  weight?: string;
  bmi?: string;
  vitals: {
    bloodPressure: string;
    heartRate: string;
    glucose: string;
    spo2: string;
    weight?: string;
    height?: string;
    bmi?: string;
  };
}

export interface Doctor {
  id: string;
  name: string;
  title?: string;
  specialty: string;
  qualifications?: string;
  qualification?: string;
  hospitalName?: string;
  hospital?: string;
  experienceYears: number;
  rating: number;
  reviewCount: number;
  distanceKm?: number;
  consultationFee: number;
  avatarUrl: string;
  nextSlot: string;
  badge?: string;
  about: string;
  languages: string[];
  availableDays: string[];
  timeSlots: string[];
  education?: string[];
  reviews?: {
    patientName: string;
    rating: number;
    date: string;
    comment: string;
  }[];
}

export interface Appointment {
  id?: string;
  doctorId?: string;
  doctorName: string;
  doctorAvatar?: string;
  doctorSpecialty?: string;
  specialty?: string;
  doctorHospital?: string;
  hospitalName?: string;
  doctorAvatarUrl?: string;
  patientName?: string;
  patientMedicalId?: string;
  date: string;
  time: string;
  status: 'Confirmed' | 'Waiting' | 'In Consultation' | 'Completed' | 'Cancelled' | 'confirmed' | 'pending';
  type: string;
  meetLink?: string;
  notes?: string;
  tokenNumber?: number;
  chiefComplaint?: string;
}

export interface Medicine {
  id: string;
  name: string;
  dosage: string;
  instructions: string;
  timePeriod?: 'Morning' | 'Afternoon' | 'Evening' | 'Night';
  scheduledTime: string;
  taken: boolean;
  missed?: boolean;
  colorType?: 'teal' | 'gray' | 'purple' | 'blue';
  frequency?: string;
  duration?: string;
  refillDaysRemaining?: number;
}

export interface MedicalRecord {
  id: string;
  title: string;
  category: 'Consultations' | 'Prescriptions' | 'Lab Reports' | 'Scans' | 'Scans & Imaging' | 'Vaccinations' | 'Discharge Summaries' | 'Other Documents';
  facility: string;
  doctorName?: string;
  uploadDate: string;
  statusBadge?: string;
  badgeType?: 'recent' | 'ai-summarized' | 'outdated' | 'verified' | 'neutral';
  isAiSummarized?: boolean;
  aiSummaryText?: string;
  aiSummary?: {
    summary: string;
    keyFindings: string[];
    biomarkers: { name: string; value: string; referenceRange: string; status: 'normal' | 'low' | 'high' }[];
    recommendations: string;
  };
  fileSize?: string;
  fileType?: string;
  fileUrl?: string;
  keyFindings?: any[];
  pdfUrl?: string;
  isFlaggedForReview?: boolean;
}

export interface PrescribedMedication {
  name: string;
  dosage: string;
  frequency: string;
  timing: string;
  duration: string;
  instructions: string;
}

export interface PrescriptionItem extends PrescribedMedication {
  id?: string;
  medicineName?: string;
  strength?: string;
  dose?: string;
  foodInstructions?: 'Before food' | 'After food' | 'With food' | 'Empty stomach';
  specialNotes?: string;
}

export interface DigitalPrescription {
  id: string;
  prescriptionId?: string;
  doctorName: string;
  doctorQualifications?: string;
  doctorSpecialty?: string;
  doctorRegNumber?: string;
  hospitalName?: string;
  doctorHospital?: string;
  hospitalLogo?: string;
  patientName: string;
  patientAge: number;
  patientGender: string;
  patientId?: string;
  patientMedicalId?: string;
  date: string;
  diagnosis: string;
  medications: PrescribedMedication[];
  medicines?: PrescriptionItem[];
  doctorNotes?: string;
  advice?: string[];
  followUpDate?: string;
  doctorSignatureUrl?: string;
}

export interface VaccineRecord {
  id: string;
  name?: string;
  vaccineName?: string;
  targetDisease?: string;
  dose?: string;
  doseNumber?: string;
  totalDoses?: string;
  dateAdministered?: string;
  administeredDate?: string;
  nextDueDate?: string;
  status: 'Completed' | 'Upcoming' | 'Missed' | 'Overdue' | 'completed' | 'upcoming' | 'overdue';
  facility?: string;
  administeredBy?: string;
  batchNumber?: string;
  certificateId?: string;
  certificateUrl?: string;
}

export interface ConsentRequest {
  id: string;
  requesterName: string;
  requesterType?: 'doctor' | 'hospital' | 'lab';
  requesterRole?: string;
  requesterOrg?: string;
  requesterHospital?: string;
  scope: string[];
  requestedScope?: string[];
  purpose?: string;
  requestedDate: string;
  status: 'Pending' | 'Active' | 'Denied' | 'Expired' | 'pending' | 'approved' | 'denied' | 'revoked';
  expiry?: string;
  expiryDate?: string;
  reason?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  accessorName?: string;
  userName?: string;
  role?: string;
  userRole?: string;
  action: string;
  recordName?: string;
  recordType?: string;
  organization?: string;
  facility?: string;
  status: 'Authorized' | 'Revoked' | 'Flagged' | 'success' | 'revoked' | 'flagged';
  ipAddress?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type?: 'appointment' | 'medicine' | 'consent' | 'report' | 'system';
  category?: 'Appointments' | 'Medicines' | 'Vaccinations' | 'Follow-ups' | 'Medical records';
  timestamp: string;
  isRead?: boolean;
  read?: boolean;
  actionUrl?: string;
  actionLabel?: string;
  severity?: 'info' | 'success' | 'warning' | 'alert';
}

export interface ChatMessage {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: string;
  bulletPoints?: string[];
  isEmergencyAlert?: boolean;
  structuredData?: {
    symptomSummary?: {
      symptom: string;
      duration: string;
      severity: string;
      location: string;
      associatedSymptoms: string[];
      currentMedications: string[];
      allergies: string[];
      relevantHistory: string;
      recommendedSpecialty: string;
    };
  };
}

export interface ReportedSymptom {
  name: string;
  duration: string;
  severity: 'Mild' | 'Moderate' | 'Severe' | string;
  location?: string;
  status: 'verified' | 'pending';
}

export interface SpecialtyItem {
  id: string;
  name: string;
  icon: string;
  description: string;
  doctorCount: number;
  commonSymptoms: string[];
  colorTheme: string;
}

export type SpecialtyInfo = SpecialtyItem;

export interface PreConsultationData {
  step: number;
  basicInfo: {
    age: number;
    weight: string;
    height: string;
    primaryConcern: string;
  };
  symptoms: {
    primarySymptom: string;
    duration: string;
    severityScore: number;
    triggers: string[];
    painType: string;
  };
  medicalHistory: {
    hasDiabetes: boolean;
    hasHypertension: boolean;
    hasCardiacHistory: boolean;
    hasAsthma: boolean;
    previousSurgeries: string;
  };
  medications: {
    currentMeds: string;
    knownAllergies: string;
    recentAntibiotics: boolean;
  };
}
